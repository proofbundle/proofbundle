#!/bin/sh
cd /home/claude/work
python3 -m http.server 8765 --bind 127.0.0.1 > http.log 2>&1 &
SRV=$!
sleep 2
rm -rf scratch
timeout 2400 python3 harness.py http://127.0.0.1:8765/orig.html http://127.0.0.1:8765/patched.html /home/claude/work/scratch > harness.log 2>&1
echo "HARNESS-EXIT $?" >> harness.log
kill $SRV
