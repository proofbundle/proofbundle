const fs = require("fs");
const text = fs.readFileSync(process.argv[2], "utf8");
const x = JSON.parse(text);
const y = JSON.parse(JSON.stringify(x));
const byteRoundTrip = JSON.stringify(x) === text;
const leaves = [];
(function walk(a, b, path) {
  if (a !== null && typeof a === "object") {
    const ka = Object.keys(a), kb = Object.keys(b);
    if (ka.join() !== kb.join()) leaves.push([path + " keys", false]);
    const sorted = [...ka].sort();
    if (!Array.isArray(a) && ka.join() !== sorted.join()) leaves.push([path + " key order", false]);
    for (const k of ka) walk(a[k], b[k], path + "." + k);
  } else leaves.push([path, a === b]);
})(x, y, "$");
const expectedTop = "atRest,corrections,isolated,noStaticFields,noThermalRadiation,periods,species,sublevels,transition";
const expectedCorr = "effect,shift,uncertainty", expectedTr = "levelA,levelB";
const noExtraKeys = Object.keys(x).join() === expectedTop
  && x.corrections.every(c => Object.keys(c).join() === expectedCorr)
  && Object.keys(x.transition).join() === expectedTr;
const ascii = /^[\x20-\x7e]*$/.test(text);
console.log(`JSON.stringify(JSON.parse(B)) === B: ${byteRoundTrip}`);
console.log(`leaf fields compared: ${leaves.length}; all === after parse(stringify(x)): ${leaves.every(l => l[1])}`);
console.log(`keys exactly the Realization fields, no extras: ${noExtraKeys}`);
console.log(`keys in sorted order at every object: ${!leaves.some(l => l[0].endsWith("key order"))}`);
console.log(`printable ASCII only, no whitespace outside strings: ${ascii && !/\s/.test(text)}`);
