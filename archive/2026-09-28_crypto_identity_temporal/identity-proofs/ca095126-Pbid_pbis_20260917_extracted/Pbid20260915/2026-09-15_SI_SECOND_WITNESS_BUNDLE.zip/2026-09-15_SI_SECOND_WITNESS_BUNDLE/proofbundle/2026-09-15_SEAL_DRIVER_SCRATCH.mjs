// Scratch driver (not a deliverable). Boots proofbundle.html exactly as cli/proofbundle-cli.mjs
// bootEngine does, then uses only the page's own functions to hash, seal, serialize, and check.
import { JSDOM, VirtualConsole } from 'jsdom';
import { readFileSync, writeFileSync } from 'node:fs';
import { webcrypto } from 'node:crypto';
const ENGINE_PATH = '/tmp/pb/proofbundle.html';
const html = readFileSync(ENGINE_PATH, 'utf-8');
const vc = new VirtualConsole();
const engineErrors = [];
vc.on('jsdomError', (e) => { if (!/canvas|clearRect/i.test(e.message)) engineErrors.push(e.message); });
const dom = new JSDOM(html, {
  url: 'https://localhost/', runScripts: 'dangerously', pretendToBeVisual: true, virtualConsole: vc,
  beforeParse(window) {
    const PageU8 = window.Uint8Array;
    const ne = new TextEncoder(), nd = new TextDecoder();
    if (!window.TextEncoder) window.TextEncoder = class { encode(s) { const b = ne.encode(s); const o = new PageU8(b.length); o.set(b); return o; } };
    if (!window.TextDecoder) window.TextDecoder = class { decode(b) { return nd.decode(b); } };
    const grv = (a) => { const t = new Uint8Array(a.length); webcrypto.getRandomValues(t); a.set(t); return a; };
    try { Object.defineProperty(window, 'crypto', { configurable: true, value: { getRandomValues: grv, subtle: webcrypto.subtle, randomUUID: () => webcrypto.randomUUID() } }); } catch {}
    if (!window.matchMedia) window.matchMedia = () => ({ matches: false, media: '', addEventListener() {}, removeEventListener() {}, addListener() {}, removeListener() {} });
    window.HTMLCanvasElement.prototype.getContext = () => null;
    if (!window.CryptoKey) window.CryptoKey = globalThis.CryptoKey;
  }
});
await new Promise((r) => dom.window.addEventListener('load', r));
const win = dom.window;
const shims = [];
if (typeof win.Blob.prototype.arrayBuffer !== 'function') {
  shims.push('Blob.prototype.arrayBuffer via FileReader');
  win.Blob.prototype.arrayBuffer = function () {
    return new Promise((res, rej) => { const fr = new win.FileReader(); fr.onload = () => res(fr.result); fr.onerror = rej; fr.readAsArrayBuffer(this); });
  };
}
const bytes = readFileSync('/home/claude/build/witness.json');
const file = new win.File([new win.Uint8Array(bytes)], 'witness.json', { type: 'application/json' });
win.addFiles([file]);
let status = null;
for (let i = 0; i < 200; i++) { status = win.eval('FILES[0] && FILES[0].status'); if (status === 'ready' || /^error/.test(status || '')) break; await new Promise(r => setTimeout(r, 100)); }
console.log('page hashing status:', status);
await win.eval('sealFilesIndividually()');
const hasBundle = win.eval('FILES_LAST_BUNDLE !== null');
console.log('page produced a sealed bundle:', hasBundle);
if (!hasBundle) { console.log('engine errors:', engineErrors.slice(0, 5)); process.exit(1); }
const text = win.eval('JSON.stringify(FILES_LAST_BUNDLE, null, 2)');
writeFileSync('/home/claude/build/witness.pb.json', text);
const b = JSON.parse(text);
console.log('hdr:', JSON.stringify(b.hdr));
console.log('artifact:', JSON.stringify(b.payload.artifacts[0]));
console.log('top-level keys:', Object.keys(b).join(','));
console.log('seal fields:', b.seal ? Object.keys(b.seal).join(',') : '(none)', '| sig_alg:', b.seal && b.seal.sig_alg);
await win.eval('verifyFilesAgainstBundle()');
await new Promise(r => setTimeout(r, 500));
const vr = win.document.getElementById('files-verify-result');
console.log('page file-vs-receipt check:', vr ? vr.textContent.replace(/\s+/g, ' ').trim().slice(0, 300) : '(no result element)');
console.log('environment shims beyond the CLI boot:', shims.length ? shims.join('; ') : 'none');
console.log('engine errors (non-canvas):', engineErrors.length ? engineErrors.slice(0, 3).join(' | ') : 'none');
process.exit(0);
