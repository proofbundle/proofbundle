import Std
import ECDSAP256

namespace ProofBundle.Crypto.ECDSAP256

def priv_rfc6979_style_sample : Nat := 0x1

/-- Vector `rfc6979_style_sample` — message (ground truth, hex in the JSON). -/
def msg_rfc6979_style_sample : ByteArray := ByteArray.mk #[0x73, 0x61, 0x6d, 0x70, 0x6c, 0x65]

/-- Vector `rfc6979_style_sample` — RFC 6979 section 3.2 deterministic nonce recovery:
`rfc6979K priv msg` reproduces the ground-truth `k`. -/
theorem kat_rfc6979_style_sample_nonce :
    rfc6979K priv_rfc6979_style_sample msg_rfc6979_style_sample = 0xf23d7a2ba580b716ff2a03d43e26b3148eea2eb3a1fc6e7abf7cef3877b35be := by native_decide

/-- Vector `rfc6979_style_sample` — FIPS 186-5 section 6.4.1 signature generation:
`ecdsaSign priv msg = (r, s)` with `r = 0x466341174d59e93eb984c2a7c923a80ab99a9e91555bc73ebd8073d4c722121`
and `s = 0x998f2b7bb63082e976215e6ae46344d66d2d4edea67d65d91595f21311df5030`. -/
theorem kat_rfc6979_style_sample_sign :
    ecdsaSign priv_rfc6979_style_sample msg_rfc6979_style_sample = (0x466341174d59e93eb984c2a7c923a80ab99a9e91555bc73ebd8073d4c722121, 0x998f2b7bb63082e976215e6ae46344d66d2d4edea67d65d91595f21311df5030) := by native_decide

/-- Vector `rfc6979_style_sample` — FIPS 186-5 section 6.4.4 verification accepts the
fresh signature under the ground-truth public key. -/
theorem kat_rfc6979_style_sample_verify :
    ecdsaVerify (Point.affine 0x6b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c296 0x4fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5) msg_rfc6979_style_sample
      0x466341174d59e93eb984c2a7c923a80ab99a9e91555bc73ebd8073d4c722121 0x998f2b7bb63082e976215e6ae46344d66d2d4edea67d65d91595f21311df5030 = true := by native_decide

/-- Vector `rfc6979_style_sample` — public-key derivation: `priv·G` is the ground-truth
public key 0x6b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c296 / 0x4fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5. -/
theorem kat_rfc6979_style_sample_pubkey :
    pointMul basePoint priv_rfc6979_style_sample =
      Point.affine 0x6b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c296 0x4fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5 := by native_decide

/-- Vector `rfc6979_style_sample` — the ground-truth public key passes the FIPS 186-5
section 5.6.2.3 full validation procedure, and the full pipeline
accepts the signature. -/
theorem kat_rfc6979_style_sample_verify_full :
    ecdsaVerifyFull (Point.affine 0x6b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c296 0x4fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5) msg_rfc6979_style_sample
      0x466341174d59e93eb984c2a7c923a80ab99a9e91555bc73ebd8073d4c722121 0x998f2b7bb63082e976215e6ae46344d66d2d4edea67d65d91595f21311df5030 = true := by native_decide


end ProofBundle.Crypto.ECDSAP256
