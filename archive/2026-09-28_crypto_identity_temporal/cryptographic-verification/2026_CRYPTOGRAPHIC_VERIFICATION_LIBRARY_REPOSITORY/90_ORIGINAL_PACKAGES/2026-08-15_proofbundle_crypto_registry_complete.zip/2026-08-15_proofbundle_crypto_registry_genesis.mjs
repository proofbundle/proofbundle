// ProofBundle cryptographic registry — genesis population
// Generated as a deterministic snapshot. Do not mutate entries in-place.
// Append registry events and rebuild a new snapshot.
//
// implementationStatus=UNVERIFIED_IN_PB is deliberate: this file does not
// claim a backend exists until PB probes it and validates required vectors.

export const PB_CRYPTO_REGISTRY = Object.freeze({
  "meta": {
    "schema": "proofbundle.crypto.registry/0.1",
    "snapshotDate": "2026-08-15",
    "snapshotType": "GENESIS_POPULATION",
    "semantics": {
      "implementationStatus": "UNVERIFIED_IN_PB means this artifact does not claim the current PB codebase implements the entry; runtime/backend probing and verified vectors must promote it.",
      "generationPolicy": {
        "allow": "eligible for generation after backend/vector/policy validation",
        "compat": "interoperability support; not necessarily PB default",
        "verify-only": "parse/verify historical objects; do not generate",
        "decrypt-only": "legacy decryption only under explicit policy",
        "deny-new-use": "recognized but forbidden for new cryptographic use",
        "deny-generate": "generation prohibited",
        "deny": "recognized hazardous/broken/non-cryptographic use; never select",
        "experimental": "requires explicit experimental profile",
        "research": "metadata/research only unless separately admitted",
        "metadata-only": "recognize/classify; no execution implied",
        "restricted": "execution requires special state/operational controls",
        "analysis-only": "cryptanalysis/modeling, not a cryptographic primitive"
      }
    },
    "sourceSnapshots": [
      {
        "name": "NIST PQC",
        "asOf": "2026-08-15",
        "notes": "FIPS 203 ML-KEM, FIPS 204 ML-DSA, FIPS 205 SLH-DSA finalized; FN-DSA/FALCON and HQC tracked separately as selected/not-final."
      },
      {
        "name": "NIST Lightweight Cryptography",
        "asOf": "2026-08-15",
        "notes": "SP 800-232 final: Ascon-AEAD128, Ascon-Hash256, Ascon-XOF128, Ascon-CXOF128."
      },
      {
        "name": "IANA COSE",
        "lastUpdated": "2026-08-11",
        "notes": "Protocol namespace snapshot represented where relevant; source registry remains authoritative for numeric assignments."
      },
      {
        "name": "IANA HPKE",
        "lastUpdated": "2026-04-16",
        "notes": "KEM/KDF/AEAD assignments copied for current registered values represented here."
      },
      {
        "name": "IANA JOSE",
        "asOf": "2026-08-15",
        "notes": "Current JOSE algorithm namespace represented, including Ed25519, Ed448, and ML-DSA-87 registrations observed in the live registry."
      },
      {
        "name": "IANA TLS Parameters",
        "asOf": "2026-08-15",
        "notes": "Core modern and major legacy TLS suites/signature schemes represented; raw IANA registry ingestion should remain a separate append source."
      }
    ],
    "coverageBoundary": {
      "claim": "Comprehensive within this turn across major standardized, deployed, historical, deprecated, broken, dangerous, PQC, quantum-native, cryptanalytic, protocol-registered, and research families. It is not a logically exhaustive enumeration of every cryptographic paper, proprietary construction, private-use code point, or unpublished algorithm ever created.",
      "unknownHandling": "Unknown identifiers must remain UNKNOWN/UNREGISTERED for verification and CANDIDATE for ingestion; never guess equivalence."
    }
  },
  "algorithms": [
    {
      "id": "pb:aead:aes-ccm:aes-128-ccm",
      "name": "AES-128-CCM",
      "kind": "aead",
      "family": "AES-CCM",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-if-nonce-unique",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-38C",
      "references": [
        "NIST SP 800-38C"
      ],
      "parameters": {
        "keyBits": 128
      }
    },
    {
      "id": "pb:aead:aes-ccm:aes-192-ccm",
      "name": "AES-192-CCM",
      "kind": "aead",
      "family": "AES-CCM",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-if-nonce-unique",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-38C",
      "references": [
        "NIST SP 800-38C"
      ],
      "parameters": {
        "keyBits": 192
      }
    },
    {
      "id": "pb:aead:aes-ccm:aes-256-ccm",
      "name": "AES-256-CCM",
      "kind": "aead",
      "family": "AES-CCM",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-if-nonce-unique",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-38C",
      "references": [
        "NIST SP 800-38C"
      ],
      "parameters": {
        "keyBits": 256
      }
    },
    {
      "id": "pb:aead:aes-gcm:aes-128-gcm",
      "name": "AES-128-GCM",
      "kind": "aead",
      "family": "AES-GCM",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-if-nonce-unique",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-38D",
      "references": [
        "NIST SP 800-38D"
      ],
      "parameters": {
        "keyBits": 128,
        "typicalNonceBits": 96
      }
    },
    {
      "id": "pb:aead:aes-gcm:aes-192-gcm",
      "name": "AES-192-GCM",
      "kind": "aead",
      "family": "AES-GCM",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-if-nonce-unique",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-38D",
      "references": [
        "NIST SP 800-38D"
      ],
      "parameters": {
        "keyBits": 192,
        "typicalNonceBits": 96
      }
    },
    {
      "id": "pb:aead:aes-gcm:aes-256-gcm",
      "name": "AES-256-GCM",
      "kind": "aead",
      "family": "AES-GCM",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-if-nonce-unique",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-38D",
      "references": [
        "NIST SP 800-38D"
      ],
      "parameters": {
        "keyBits": 256,
        "typicalNonceBits": 96
      }
    },
    {
      "id": "pb:aead-or-mode:aes:aes-gcm-siv",
      "name": "AES-GCM-SIV",
      "kind": "aead-or-mode",
      "family": "AES",
      "specificationStatus": "standardized-RFC",
      "securityStatus": "nonce-misuse-resistant",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "RFC 8452"
      ]
    },
    {
      "id": "pb:aead-or-mode:aes:aes-siv",
      "name": "AES-SIV",
      "kind": "aead-or-mode",
      "family": "AES",
      "specificationStatus": "standardized-RFC",
      "securityStatus": "misuse-resistant",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "RFC 5297"
      ]
    },
    {
      "id": "pb:aead-or-mode:ccm:ccm",
      "name": "CCM*",
      "kind": "aead-or-mode",
      "family": "CCM*",
      "specificationStatus": "specialized-standard",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:aead-or-mode:eax:eax",
      "name": "EAX",
      "kind": "aead-or-mode",
      "family": "EAX",
      "specificationStatus": "published",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:aead-or-mode:gcm:gcm-siv",
      "name": "GCM-SIV",
      "kind": "aead-or-mode",
      "family": "GCM",
      "specificationStatus": "standardized-RFC",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "RFC 8452"
      ]
    },
    {
      "id": "pb:aead-or-mode:ocb3:ocb3",
      "name": "OCB3",
      "kind": "aead-or-mode",
      "family": "OCB3",
      "specificationStatus": "standardized-RFC",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "RFC 7253"
      ]
    },
    {
      "id": "pb:algebraic-hash:mimc:mimc",
      "name": "MiMC",
      "kind": "algebraic-hash",
      "family": "MiMC",
      "specificationStatus": "specialized/research/deployed",
      "securityStatus": "proof-system-context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:algebraic-hash:pedersen-hash:pedersen-hash",
      "name": "Pedersen hash",
      "kind": "algebraic-hash",
      "family": "Pedersen hash",
      "specificationStatus": "specialized/research/deployed",
      "securityStatus": "proof-system-context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:algebraic-hash:poseidon:poseidon",
      "name": "Poseidon",
      "kind": "algebraic-hash",
      "family": "Poseidon",
      "specificationStatus": "specialized/research/deployed",
      "securityStatus": "proof-system-context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:algebraic-hash:poseidon2:poseidon2",
      "name": "Poseidon2",
      "kind": "algebraic-hash",
      "family": "Poseidon2",
      "specificationStatus": "specialized/research/deployed",
      "securityStatus": "proof-system-context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:algebraic-hash:rescue:rescue",
      "name": "Rescue",
      "kind": "algebraic-hash",
      "family": "Rescue",
      "specificationStatus": "specialized/research/deployed",
      "securityStatus": "proof-system-context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:algebraic-hash:rescue-prime:rescue-prime",
      "name": "Rescue-Prime",
      "kind": "algebraic-hash",
      "family": "Rescue-Prime",
      "specificationStatus": "specialized/research/deployed",
      "securityStatus": "proof-system-context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:append-only-commitment:merkle-mountain-range:merkle-mountain-range",
      "name": "Merkle Mountain Range",
      "kind": "append-only-commitment",
      "family": "Merkle Mountain Range",
      "specificationStatus": "published/deployed",
      "securityStatus": "assumption-and-instantiation-dependent",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:block-cipher:2:2-key-tdea",
      "name": "2-key TDEA",
      "kind": "block-cipher",
      "family": "2",
      "specificationStatus": "deprecated",
      "securityStatus": "obsolete",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "keyBits": 112,
        "blockBits": 64
      }
    },
    {
      "id": "pb:block-cipher:3:3-key-tdea",
      "name": "3-key TDEA",
      "kind": "block-cipher",
      "family": "3",
      "specificationStatus": "deprecated",
      "securityStatus": "deprecated",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "keyBits": 168,
        "blockBits": 64
      }
    },
    {
      "id": "pb:block-cipher:aes:aes-128",
      "name": "AES-128",
      "kind": "block-cipher",
      "family": "AES",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 197",
      "references": [
        "FIPS 197"
      ],
      "parameters": {
        "keyBits": 128,
        "blockBits": 128
      }
    },
    {
      "id": "pb:block-cipher:aes:aes-192",
      "name": "AES-192",
      "kind": "block-cipher",
      "family": "AES",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 197",
      "references": [
        "FIPS 197"
      ],
      "parameters": {
        "keyBits": 192,
        "blockBits": 128
      }
    },
    {
      "id": "pb:block-cipher:aes:aes-256",
      "name": "AES-256",
      "kind": "block-cipher",
      "family": "AES",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 197",
      "references": [
        "FIPS 197"
      ],
      "parameters": {
        "keyBits": 256,
        "blockBits": 128
      }
    },
    {
      "id": "pb:block-cipher:aria:aria-128",
      "name": "ARIA-128",
      "kind": "block-cipher",
      "family": "ARIA",
      "specificationStatus": "national-standard/RFC",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "keyBits": 128,
        "blockBits": 128
      }
    },
    {
      "id": "pb:block-cipher:aria:aria-192",
      "name": "ARIA-192",
      "kind": "block-cipher",
      "family": "ARIA",
      "specificationStatus": "national-standard/RFC",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "keyBits": 192,
        "blockBits": 128
      }
    },
    {
      "id": "pb:block-cipher:aria:aria-256",
      "name": "ARIA-256",
      "kind": "block-cipher",
      "family": "ARIA",
      "specificationStatus": "national-standard/RFC",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "keyBits": 256,
        "blockBits": 128
      }
    },
    {
      "id": "pb:block-cipher:anubis:anubis",
      "name": "Anubis",
      "kind": "block-cipher",
      "family": "Anubis",
      "specificationStatus": "historical-or-specialized",
      "securityStatus": "not-primary-modern-choice",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:block-cipher:blowfish:blowfish",
      "name": "Blowfish",
      "kind": "block-cipher",
      "family": "Blowfish",
      "specificationStatus": "legacy",
      "securityStatus": "legacy",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "blockBits": 64
      }
    },
    {
      "id": "pb:block-cipher:cast5:cast5",
      "name": "CAST5",
      "kind": "block-cipher",
      "family": "CAST5",
      "specificationStatus": "legacy",
      "securityStatus": "legacy",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "blockBits": 64
      }
    },
    {
      "id": "pb:block-cipher:cast6:cast6",
      "name": "CAST6",
      "kind": "block-cipher",
      "family": "CAST6",
      "specificationStatus": "published",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "blockBits": 128
      }
    },
    {
      "id": "pb:block-cipher:clefia:clefia-128",
      "name": "CLEFIA-128",
      "kind": "block-cipher",
      "family": "CLEFIA",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "keyBits": 128,
        "blockBits": 128
      }
    },
    {
      "id": "pb:block-cipher:clefia:clefia-192",
      "name": "CLEFIA-192",
      "kind": "block-cipher",
      "family": "CLEFIA",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "keyBits": 192,
        "blockBits": 128
      }
    },
    {
      "id": "pb:block-cipher:clefia:clefia-256",
      "name": "CLEFIA-256",
      "kind": "block-cipher",
      "family": "CLEFIA",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "keyBits": 256,
        "blockBits": 128
      }
    },
    {
      "id": "pb:block-cipher:camellia:camellia-128",
      "name": "Camellia-128",
      "kind": "block-cipher",
      "family": "Camellia",
      "specificationStatus": "standardized-RFC",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "keyBits": 128,
        "blockBits": 128
      }
    },
    {
      "id": "pb:block-cipher:camellia:camellia-192",
      "name": "Camellia-192",
      "kind": "block-cipher",
      "family": "Camellia",
      "specificationStatus": "standardized-RFC",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "keyBits": 192,
        "blockBits": 128
      }
    },
    {
      "id": "pb:block-cipher:camellia:camellia-256",
      "name": "Camellia-256",
      "kind": "block-cipher",
      "family": "Camellia",
      "specificationStatus": "standardized-RFC",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "keyBits": 256,
        "blockBits": 128
      }
    },
    {
      "id": "pb:block-cipher:des:des",
      "name": "DES",
      "kind": "block-cipher",
      "family": "DES",
      "specificationStatus": "obsolete",
      "securityStatus": "obsolete",
      "quantumClass": "classical",
      "generationPolicy": "deny-generate",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "keyBits": 56,
        "blockBits": 64
      }
    },
    {
      "id": "pb:block-cipher:gost-28147:gost-28147-89",
      "name": "GOST 28147-89",
      "kind": "block-cipher",
      "family": "GOST 28147",
      "specificationStatus": "legacy-national-standard",
      "securityStatus": "legacy",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "keyBits": 256,
        "blockBits": 64
      }
    },
    {
      "id": "pb:block-cipher:gost-grasshopper:gost-grasshopper",
      "name": "GOST Grasshopper",
      "kind": "block-cipher",
      "family": "GOST Grasshopper",
      "specificationStatus": "historical-or-specialized",
      "securityStatus": "not-primary-modern-choice",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:block-cipher:hight:hight",
      "name": "HIGHT",
      "kind": "block-cipher",
      "family": "HIGHT",
      "specificationStatus": "lightweight-standard",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "keyBits": 128,
        "blockBits": 64
      }
    },
    {
      "id": "pb:block-cipher:idea:idea",
      "name": "IDEA",
      "kind": "block-cipher",
      "family": "IDEA",
      "specificationStatus": "legacy",
      "securityStatus": "legacy",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "keyBits": 128,
        "blockBits": 64
      }
    },
    {
      "id": "pb:block-cipher:kasumi:kasumi",
      "name": "KASUMI",
      "kind": "block-cipher",
      "family": "KASUMI",
      "specificationStatus": "historical-or-specialized",
      "securityStatus": "not-primary-modern-choice",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:block-cipher:khazad:khazad",
      "name": "Khazad",
      "kind": "block-cipher",
      "family": "Khazad",
      "specificationStatus": "historical-or-specialized",
      "securityStatus": "not-primary-modern-choice",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:block-cipher:kuznyechik:kuznyechik",
      "name": "Kuznyechik",
      "kind": "block-cipher",
      "family": "Kuznyechik",
      "specificationStatus": "national-standard/RFC",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "keyBits": 256,
        "blockBits": 128
      }
    },
    {
      "id": "pb:block-cipher:lea:lea-128",
      "name": "LEA-128",
      "kind": "block-cipher",
      "family": "LEA",
      "specificationStatus": "national-standard",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "keyBits": 128,
        "blockBits": 128
      }
    },
    {
      "id": "pb:block-cipher:lea:lea-192",
      "name": "LEA-192",
      "kind": "block-cipher",
      "family": "LEA",
      "specificationStatus": "national-standard",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "keyBits": 192,
        "blockBits": 128
      }
    },
    {
      "id": "pb:block-cipher:lea:lea-256",
      "name": "LEA-256",
      "kind": "block-cipher",
      "family": "LEA",
      "specificationStatus": "national-standard",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "keyBits": 256,
        "blockBits": 128
      }
    },
    {
      "id": "pb:block-cipher:loki97:loki97",
      "name": "LOKI97",
      "kind": "block-cipher",
      "family": "LOKI97",
      "specificationStatus": "historical-or-specialized",
      "securityStatus": "not-primary-modern-choice",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:block-cipher:mars:mars",
      "name": "MARS",
      "kind": "block-cipher",
      "family": "MARS",
      "specificationStatus": "historical-or-specialized",
      "securityStatus": "not-primary-modern-choice",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:block-cipher:misty1:misty1",
      "name": "MISTY1",
      "kind": "block-cipher",
      "family": "MISTY1",
      "specificationStatus": "historical-or-specialized",
      "securityStatus": "not-primary-modern-choice",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:block-cipher:magma:magma",
      "name": "Magma",
      "kind": "block-cipher",
      "family": "Magma",
      "specificationStatus": "national-standard/RFC",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "keyBits": 256,
        "blockBits": 64
      }
    },
    {
      "id": "pb:block-cipher:noekeon:noekeon",
      "name": "Noekeon",
      "kind": "block-cipher",
      "family": "Noekeon",
      "specificationStatus": "published",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "keyBits": 128,
        "blockBits": 128
      }
    },
    {
      "id": "pb:block-cipher:present:present-128",
      "name": "PRESENT-128",
      "kind": "block-cipher",
      "family": "PRESENT",
      "specificationStatus": "lightweight-standard",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "keyBits": 128,
        "blockBits": 64
      }
    },
    {
      "id": "pb:block-cipher:present:present-80",
      "name": "PRESENT-80",
      "kind": "block-cipher",
      "family": "PRESENT",
      "specificationStatus": "lightweight-standard",
      "securityStatus": "limited-security-margin",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "keyBits": 80,
        "blockBits": 64
      }
    },
    {
      "id": "pb:block-cipher:rc2:rc2",
      "name": "RC2",
      "kind": "block-cipher",
      "family": "RC2",
      "specificationStatus": "obsolete",
      "securityStatus": "weak",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "blockBits": 64
      }
    },
    {
      "id": "pb:block-cipher:rc5:rc5",
      "name": "RC5",
      "kind": "block-cipher",
      "family": "RC5",
      "specificationStatus": "legacy",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:block-cipher:rc6:rc6",
      "name": "RC6",
      "kind": "block-cipher",
      "family": "RC6",
      "specificationStatus": "published",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "blockBits": 128
      }
    },
    {
      "id": "pb:block-cipher:safer-k-64:safer-k-64",
      "name": "SAFER K-64",
      "kind": "block-cipher",
      "family": "SAFER K-64",
      "specificationStatus": "historical-or-specialized",
      "securityStatus": "not-primary-modern-choice",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:block-cipher:safer-sk-128:safer-sk-128",
      "name": "SAFER SK-128",
      "kind": "block-cipher",
      "family": "SAFER SK-128",
      "specificationStatus": "historical-or-specialized",
      "securityStatus": "not-primary-modern-choice",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:block-cipher:seed:seed",
      "name": "SEED",
      "kind": "block-cipher",
      "family": "SEED",
      "specificationStatus": "national-standard",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "keyBits": 128,
        "blockBits": 128
      }
    },
    {
      "id": "pb:block-cipher:shacal-1:shacal-1",
      "name": "SHACAL-1",
      "kind": "block-cipher",
      "family": "SHACAL-1",
      "specificationStatus": "historical-or-specialized",
      "securityStatus": "not-primary-modern-choice",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:block-cipher:shacal-2:shacal-2",
      "name": "SHACAL-2",
      "kind": "block-cipher",
      "family": "SHACAL-2",
      "specificationStatus": "historical-or-specialized",
      "securityStatus": "not-primary-modern-choice",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:block-cipher:sm4:sm4",
      "name": "SM4",
      "kind": "block-cipher",
      "family": "SM4",
      "specificationStatus": "national-standard",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "keyBits": 128,
        "blockBits": 128
      }
    },
    {
      "id": "pb:block-cipher:serpent:serpent",
      "name": "Serpent",
      "kind": "block-cipher",
      "family": "Serpent",
      "specificationStatus": "published",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "blockBits": 128
      }
    },
    {
      "id": "pb:block-cipher:skipjack:skipjack",
      "name": "Skipjack",
      "kind": "block-cipher",
      "family": "Skipjack",
      "specificationStatus": "obsolete",
      "securityStatus": "obsolete",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "keyBits": 80,
        "blockBits": 64
      }
    },
    {
      "id": "pb:block-cipher:square:square",
      "name": "Square",
      "kind": "block-cipher",
      "family": "Square",
      "specificationStatus": "historical-or-specialized",
      "securityStatus": "not-primary-modern-choice",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:block-cipher:tea:tea",
      "name": "TEA",
      "kind": "block-cipher",
      "family": "TEA",
      "specificationStatus": "obsolete/research",
      "securityStatus": "weak",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "keyBits": 128,
        "blockBits": 64
      }
    },
    {
      "id": "pb:block-cipher:twofish:twofish",
      "name": "Twofish",
      "kind": "block-cipher",
      "family": "Twofish",
      "specificationStatus": "published",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "blockBits": 128
      }
    },
    {
      "id": "pb:block-cipher:xtea:xtea",
      "name": "XTEA",
      "kind": "block-cipher",
      "family": "XTEA",
      "specificationStatus": "legacy",
      "securityStatus": "legacy",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "keyBits": 128,
        "blockBits": 64
      }
    },
    {
      "id": "pb:block-cipher:xxtea:xxtea",
      "name": "XXTEA",
      "kind": "block-cipher",
      "family": "XXTEA",
      "specificationStatus": "legacy",
      "securityStatus": "legacy",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "keyBits": 128
      }
    },
    {
      "id": "pb:checksum-or-noncrypto-hash:adler:adler-32",
      "name": "Adler-32",
      "kind": "checksum-or-noncrypto-hash",
      "family": "Adler",
      "specificationStatus": "deployed",
      "securityStatus": "NOT_CRYPTOGRAPHIC",
      "quantumClass": "classical",
      "generationPolicy": "deny-cryptographic-use",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous-if-misclassified"
      ]
    },
    {
      "id": "pb:checksum-or-noncrypto-hash:crc:crc-16",
      "name": "CRC-16",
      "kind": "checksum-or-noncrypto-hash",
      "family": "CRC",
      "specificationStatus": "deployed",
      "securityStatus": "NOT_CRYPTOGRAPHIC",
      "quantumClass": "classical",
      "generationPolicy": "deny-cryptographic-use",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous-if-misclassified"
      ]
    },
    {
      "id": "pb:checksum-or-noncrypto-hash:crc:crc-32",
      "name": "CRC-32",
      "kind": "checksum-or-noncrypto-hash",
      "family": "CRC",
      "specificationStatus": "deployed",
      "securityStatus": "NOT_CRYPTOGRAPHIC",
      "quantumClass": "classical",
      "generationPolicy": "deny-cryptographic-use",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous-if-misclassified"
      ]
    },
    {
      "id": "pb:checksum-or-noncrypto-hash:crc:crc-32c",
      "name": "CRC-32C",
      "kind": "checksum-or-noncrypto-hash",
      "family": "CRC",
      "specificationStatus": "deployed",
      "securityStatus": "NOT_CRYPTOGRAPHIC",
      "quantumClass": "classical",
      "generationPolicy": "deny-cryptographic-use",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous-if-misclassified"
      ]
    },
    {
      "id": "pb:checksum-or-noncrypto-hash:crc:crc-64",
      "name": "CRC-64",
      "kind": "checksum-or-noncrypto-hash",
      "family": "CRC",
      "specificationStatus": "deployed",
      "securityStatus": "NOT_CRYPTOGRAPHIC",
      "quantumClass": "classical",
      "generationPolicy": "deny-cryptographic-use",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous-if-misclassified"
      ]
    },
    {
      "id": "pb:checksum-or-noncrypto-hash:cityhash:cityhash",
      "name": "CityHash",
      "kind": "checksum-or-noncrypto-hash",
      "family": "CityHash",
      "specificationStatus": "deployed",
      "securityStatus": "NOT_CRYPTOGRAPHIC",
      "quantumClass": "classical",
      "generationPolicy": "deny-cryptographic-use",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous-if-misclassified"
      ]
    },
    {
      "id": "pb:checksum-or-noncrypto-hash:farmhash:farmhash",
      "name": "FarmHash",
      "kind": "checksum-or-noncrypto-hash",
      "family": "FarmHash",
      "specificationStatus": "deployed",
      "securityStatus": "NOT_CRYPTOGRAPHIC",
      "quantumClass": "classical",
      "generationPolicy": "deny-cryptographic-use",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous-if-misclassified"
      ]
    },
    {
      "id": "pb:checksum-or-noncrypto-hash:fletcher:fletcher-16",
      "name": "Fletcher-16",
      "kind": "checksum-or-noncrypto-hash",
      "family": "Fletcher",
      "specificationStatus": "deployed",
      "securityStatus": "NOT_CRYPTOGRAPHIC",
      "quantumClass": "classical",
      "generationPolicy": "deny-cryptographic-use",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous-if-misclassified"
      ]
    },
    {
      "id": "pb:checksum-or-noncrypto-hash:fletcher:fletcher-32",
      "name": "Fletcher-32",
      "kind": "checksum-or-noncrypto-hash",
      "family": "Fletcher",
      "specificationStatus": "deployed",
      "securityStatus": "NOT_CRYPTOGRAPHIC",
      "quantumClass": "classical",
      "generationPolicy": "deny-cryptographic-use",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous-if-misclassified"
      ]
    },
    {
      "id": "pb:checksum-or-noncrypto-hash:murmurhash3:murmurhash3",
      "name": "MurmurHash3",
      "kind": "checksum-or-noncrypto-hash",
      "family": "MurmurHash3",
      "specificationStatus": "deployed",
      "securityStatus": "NOT_CRYPTOGRAPHIC",
      "quantumClass": "classical",
      "generationPolicy": "deny-cryptographic-use",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous-if-misclassified"
      ]
    },
    {
      "id": "pb:checksum-or-noncrypto-hash:xxhash3:xxhash3",
      "name": "xxHash3",
      "kind": "checksum-or-noncrypto-hash",
      "family": "xxHash3",
      "specificationStatus": "deployed",
      "securityStatus": "NOT_CRYPTOGRAPHIC",
      "quantumClass": "classical",
      "generationPolicy": "deny-cryptographic-use",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous-if-misclassified"
      ]
    },
    {
      "id": "pb:checksum-or-noncrypto-hash:xxhash32:xxhash32",
      "name": "xxHash32",
      "kind": "checksum-or-noncrypto-hash",
      "family": "xxHash32",
      "specificationStatus": "deployed",
      "securityStatus": "NOT_CRYPTOGRAPHIC",
      "quantumClass": "classical",
      "generationPolicy": "deny-cryptographic-use",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous-if-misclassified"
      ]
    },
    {
      "id": "pb:checksum-or-noncrypto-hash:xxhash64:xxhash64",
      "name": "xxHash64",
      "kind": "checksum-or-noncrypto-hash",
      "family": "xxHash64",
      "specificationStatus": "deployed",
      "securityStatus": "NOT_CRYPTOGRAPHIC",
      "quantumClass": "classical",
      "generationPolicy": "deny-cryptographic-use",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous-if-misclassified"
      ]
    },
    {
      "id": "pb:cipher-mode:aes-cbc:aes-128-cbc",
      "name": "AES-128-CBC",
      "kind": "cipher-mode",
      "family": "AES-CBC",
      "specificationStatus": "standardized",
      "securityStatus": "requires-independent-authentication-and-correct-IV",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-38A",
      "references": [
        "NIST SP 800-38A"
      ],
      "parameters": {
        "keyBits": 128
      }
    },
    {
      "id": "pb:cipher-mode:aes-cbc:aes-192-cbc",
      "name": "AES-192-CBC",
      "kind": "cipher-mode",
      "family": "AES-CBC",
      "specificationStatus": "standardized",
      "securityStatus": "requires-independent-authentication-and-correct-IV",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-38A",
      "references": [
        "NIST SP 800-38A"
      ],
      "parameters": {
        "keyBits": 192
      }
    },
    {
      "id": "pb:cipher-mode:aes-cbc:aes-256-cbc",
      "name": "AES-256-CBC",
      "kind": "cipher-mode",
      "family": "AES-CBC",
      "specificationStatus": "standardized",
      "securityStatus": "requires-independent-authentication-and-correct-IV",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-38A",
      "references": [
        "NIST SP 800-38A"
      ],
      "parameters": {
        "keyBits": 256
      }
    },
    {
      "id": "pb:cipher-mode:aes-cfb:aes-128-cfb",
      "name": "AES-128-CFB",
      "kind": "cipher-mode",
      "family": "AES-CFB",
      "specificationStatus": "standardized",
      "securityStatus": "requires-independent-authentication-and-correct-IV",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-38A",
      "references": [
        "NIST SP 800-38A"
      ],
      "parameters": {
        "keyBits": 128
      }
    },
    {
      "id": "pb:cipher-mode:aes-cfb:aes-192-cfb",
      "name": "AES-192-CFB",
      "kind": "cipher-mode",
      "family": "AES-CFB",
      "specificationStatus": "standardized",
      "securityStatus": "requires-independent-authentication-and-correct-IV",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-38A",
      "references": [
        "NIST SP 800-38A"
      ],
      "parameters": {
        "keyBits": 192
      }
    },
    {
      "id": "pb:cipher-mode:aes-cfb:aes-256-cfb",
      "name": "AES-256-CFB",
      "kind": "cipher-mode",
      "family": "AES-CFB",
      "specificationStatus": "standardized",
      "securityStatus": "requires-independent-authentication-and-correct-IV",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-38A",
      "references": [
        "NIST SP 800-38A"
      ],
      "parameters": {
        "keyBits": 256
      }
    },
    {
      "id": "pb:cipher-mode:aes-ctr:aes-128-ctr",
      "name": "AES-128-CTR",
      "kind": "cipher-mode",
      "family": "AES-CTR",
      "specificationStatus": "standardized",
      "securityStatus": "requires-independent-authentication-and-correct-IV",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-38A",
      "references": [
        "NIST SP 800-38A"
      ],
      "parameters": {
        "keyBits": 128
      }
    },
    {
      "id": "pb:cipher-mode:aes-ctr:aes-192-ctr",
      "name": "AES-192-CTR",
      "kind": "cipher-mode",
      "family": "AES-CTR",
      "specificationStatus": "standardized",
      "securityStatus": "requires-independent-authentication-and-correct-IV",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-38A",
      "references": [
        "NIST SP 800-38A"
      ],
      "parameters": {
        "keyBits": 192
      }
    },
    {
      "id": "pb:cipher-mode:aes-ctr:aes-256-ctr",
      "name": "AES-256-CTR",
      "kind": "cipher-mode",
      "family": "AES-CTR",
      "specificationStatus": "standardized",
      "securityStatus": "requires-independent-authentication-and-correct-IV",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-38A",
      "references": [
        "NIST SP 800-38A"
      ],
      "parameters": {
        "keyBits": 256
      }
    },
    {
      "id": "pb:cipher-mode:aes-ecb:aes-128-ecb",
      "name": "AES-128-ECB",
      "kind": "cipher-mode",
      "family": "AES-ECB",
      "specificationStatus": "standardized",
      "securityStatus": "unsafe-for-general-purpose-confidentiality",
      "quantumClass": "classical",
      "generationPolicy": "deny-new-use",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-38A",
      "references": [
        "NIST SP 800-38A"
      ],
      "parameters": {
        "keyBits": 128
      }
    },
    {
      "id": "pb:cipher-mode:aes-ecb:aes-192-ecb",
      "name": "AES-192-ECB",
      "kind": "cipher-mode",
      "family": "AES-ECB",
      "specificationStatus": "standardized",
      "securityStatus": "unsafe-for-general-purpose-confidentiality",
      "quantumClass": "classical",
      "generationPolicy": "deny-new-use",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-38A",
      "references": [
        "NIST SP 800-38A"
      ],
      "parameters": {
        "keyBits": 192
      }
    },
    {
      "id": "pb:cipher-mode:aes-ecb:aes-256-ecb",
      "name": "AES-256-ECB",
      "kind": "cipher-mode",
      "family": "AES-ECB",
      "specificationStatus": "standardized",
      "securityStatus": "unsafe-for-general-purpose-confidentiality",
      "quantumClass": "classical",
      "generationPolicy": "deny-new-use",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-38A",
      "references": [
        "NIST SP 800-38A"
      ],
      "parameters": {
        "keyBits": 256
      }
    },
    {
      "id": "pb:cipher-mode:aes-ofb:aes-128-ofb",
      "name": "AES-128-OFB",
      "kind": "cipher-mode",
      "family": "AES-OFB",
      "specificationStatus": "standardized",
      "securityStatus": "requires-independent-authentication-and-correct-IV",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-38A",
      "references": [
        "NIST SP 800-38A"
      ],
      "parameters": {
        "keyBits": 128
      }
    },
    {
      "id": "pb:cipher-mode:aes-ofb:aes-192-ofb",
      "name": "AES-192-OFB",
      "kind": "cipher-mode",
      "family": "AES-OFB",
      "specificationStatus": "standardized",
      "securityStatus": "requires-independent-authentication-and-correct-IV",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-38A",
      "references": [
        "NIST SP 800-38A"
      ],
      "parameters": {
        "keyBits": 192
      }
    },
    {
      "id": "pb:cipher-mode:aes-ofb:aes-256-ofb",
      "name": "AES-256-OFB",
      "kind": "cipher-mode",
      "family": "AES-OFB",
      "specificationStatus": "standardized",
      "securityStatus": "requires-independent-authentication-and-correct-IV",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-38A",
      "references": [
        "NIST SP 800-38A"
      ],
      "parameters": {
        "keyBits": 256
      }
    },
    {
      "id": "pb:code-based:qc-mdpc:qc-mdpc",
      "name": "QC-MDPC",
      "kind": "code-based",
      "family": "QC-MDPC",
      "specificationStatus": "research-foundation",
      "securityStatus": "assumption-or-family-not-standalone-algorithm",
      "quantumClass": "post_quantum",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:code-based-PKE:mceliece:mceliece",
      "name": "McEliece",
      "kind": "code-based-PKE",
      "family": "McEliece",
      "specificationStatus": "research-foundation",
      "securityStatus": "assumption-or-family-not-standalone-algorithm",
      "quantumClass": "post_quantum",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:code-based-PKE:niederreiter:niederreiter",
      "name": "Niederreiter",
      "kind": "code-based-PKE",
      "family": "Niederreiter",
      "specificationStatus": "research-foundation",
      "securityStatus": "assumption-or-family-not-standalone-algorithm",
      "quantumClass": "post_quantum",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:commitment:hash-commitment:hash-commitment",
      "name": "Hash commitment",
      "kind": "commitment",
      "family": "Hash commitment",
      "specificationStatus": "generic-construction",
      "securityStatus": "assumption-and-instantiation-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:commitment:pedersen-commitment:pedersen-commitment",
      "name": "Pedersen commitment",
      "kind": "commitment",
      "family": "Pedersen commitment",
      "specificationStatus": "published",
      "securityStatus": "assumption-and-instantiation-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:commitment-structure:merkle-tree:merkle-tree",
      "name": "Merkle tree",
      "kind": "commitment-structure",
      "family": "Merkle tree",
      "specificationStatus": "published/deployed",
      "securityStatus": "assumption-and-instantiation-dependent",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:cose-algorithm:cose:a128cbc",
      "name": "A128CBC",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "AES-CBC 128"
      ],
      "parameters": {
        "coseValue": -65531,
        "ianaRecommended": "Deprecated"
      }
    },
    {
      "id": "pb:cose-algorithm:cose:a128ctr",
      "name": "A128CTR",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "AES-CTR 128"
      ],
      "parameters": {
        "coseValue": -65534,
        "ianaRecommended": "Deprecated"
      }
    },
    {
      "id": "pb:cose-algorithm:cose:a128gcm",
      "name": "A128GCM",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "AES-128-GCM"
      ],
      "parameters": {
        "coseValue": 1,
        "ianaRecommended": "Yes"
      }
    },
    {
      "id": "pb:cose-algorithm:cose:a128kw",
      "name": "A128KW",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "AES-128-KW"
      ],
      "parameters": {
        "coseValue": -3,
        "ianaRecommended": "Yes"
      }
    },
    {
      "id": "pb:cose-algorithm:cose:a192cbc",
      "name": "A192CBC",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "AES-CBC 192"
      ],
      "parameters": {
        "coseValue": -65530,
        "ianaRecommended": "Deprecated"
      }
    },
    {
      "id": "pb:cose-algorithm:cose:a192ctr",
      "name": "A192CTR",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "AES-CTR 192"
      ],
      "parameters": {
        "coseValue": -65533,
        "ianaRecommended": "Deprecated"
      }
    },
    {
      "id": "pb:cose-algorithm:cose:a192gcm",
      "name": "A192GCM",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "AES-192-GCM"
      ],
      "parameters": {
        "coseValue": 2,
        "ianaRecommended": "No"
      }
    },
    {
      "id": "pb:cose-algorithm:cose:a192kw",
      "name": "A192KW",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "AES-192-KW"
      ],
      "parameters": {
        "coseValue": -4,
        "ianaRecommended": "No"
      }
    },
    {
      "id": "pb:cose-algorithm:cose:a256cbc",
      "name": "A256CBC",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "AES-CBC 256"
      ],
      "parameters": {
        "coseValue": -65529,
        "ianaRecommended": "Deprecated"
      }
    },
    {
      "id": "pb:cose-algorithm:cose:a256ctr",
      "name": "A256CTR",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "AES-CTR 256"
      ],
      "parameters": {
        "coseValue": -65532,
        "ianaRecommended": "Deprecated"
      }
    },
    {
      "id": "pb:cose-algorithm:cose:a256gcm",
      "name": "A256GCM",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "AES-256-GCM"
      ],
      "parameters": {
        "coseValue": 3,
        "ianaRecommended": "Yes"
      }
    },
    {
      "id": "pb:cose-algorithm:cose:a256kw",
      "name": "A256KW",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "AES-256-KW"
      ],
      "parameters": {
        "coseValue": -5,
        "ianaRecommended": "Yes"
      }
    },
    {
      "id": "pb:cose-algorithm:cose:chacha20-poly1305",
      "name": "ChaCha20/Poly1305",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "ChaCha20-Poly1305"
      ],
      "parameters": {
        "coseValue": 24,
        "ianaRecommended": "Yes"
      }
    },
    {
      "id": "pb:cose-algorithm:cose:es256",
      "name": "ES256",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "ECDSA P-256 SHA-256"
      ],
      "parameters": {
        "coseValue": -7,
        "ianaRecommended": "Yes"
      }
    },
    {
      "id": "pb:cose-algorithm:cose:es256k",
      "name": "ES256K",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "ECDSA secp256k1 SHA-256"
      ],
      "parameters": {
        "coseValue": -47,
        "ianaRecommended": "No"
      }
    },
    {
      "id": "pb:cose-algorithm:cose:esb256",
      "name": "ESB256",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "ECDSA BrainpoolP256r1 SHA-256"
      ],
      "parameters": {
        "coseValue": -265,
        "ianaRecommended": "No"
      }
    },
    {
      "id": "pb:cose-algorithm:cose:esb320",
      "name": "ESB320",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "ECDSA BrainpoolP320r1 SHA-384"
      ],
      "parameters": {
        "coseValue": -266,
        "ianaRecommended": "No"
      }
    },
    {
      "id": "pb:cose-algorithm:cose:esb384",
      "name": "ESB384",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "ECDSA BrainpoolP384r1 SHA-384"
      ],
      "parameters": {
        "coseValue": -267,
        "ianaRecommended": "No"
      }
    },
    {
      "id": "pb:cose-algorithm:cose:esb512",
      "name": "ESB512",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "ECDSA BrainpoolP512r1 SHA-512"
      ],
      "parameters": {
        "coseValue": -268,
        "ianaRecommended": "No"
      }
    },
    {
      "id": "pb:cose-algorithm:cose:esp384",
      "name": "ESP384",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "ECDSA P-384 SHA-384"
      ],
      "parameters": {
        "coseValue": -51,
        "ianaRecommended": "Yes"
      }
    },
    {
      "id": "pb:cose-algorithm:cose:esp512",
      "name": "ESP512",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "ECDSA P-521 SHA-512"
      ],
      "parameters": {
        "coseValue": -52,
        "ianaRecommended": "Yes"
      }
    },
    {
      "id": "pb:cose-algorithm:cose:ed448",
      "name": "Ed448",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "Ed448"
      ],
      "parameters": {
        "coseValue": -53,
        "ianaRecommended": "Yes"
      }
    },
    {
      "id": "pb:cose-algorithm:cose:eddsa",
      "name": "EdDSA",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "EdDSA legacy COSE name"
      ],
      "parameters": {
        "coseValue": -8,
        "ianaRecommended": "Deprecated/transition"
      }
    },
    {
      "id": "pb:cose-algorithm:cose:hss-lms",
      "name": "HSS-LMS",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "HSS/LMS"
      ],
      "parameters": {
        "coseValue": -46,
        "ianaRecommended": "Yes"
      }
    },
    {
      "id": "pb:cose-algorithm:cose:kt128",
      "name": "KT128",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "KangarooTwelve/KT128 XOF profile"
      ],
      "parameters": {
        "coseValue": -263,
        "ianaRecommended": "No"
      }
    },
    {
      "id": "pb:cose-algorithm:cose:kt256",
      "name": "KT256",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "KangarooTwelve/KT256 XOF profile"
      ],
      "parameters": {
        "coseValue": -264,
        "ianaRecommended": "No"
      }
    },
    {
      "id": "pb:cose-algorithm:cose:ml-dsa-44",
      "name": "ML-DSA-44",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "ML-DSA-44"
      ],
      "parameters": {
        "coseValue": -48,
        "ianaRecommended": "Yes"
      }
    },
    {
      "id": "pb:cose-algorithm:cose:ml-dsa-65",
      "name": "ML-DSA-65",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "ML-DSA-65"
      ],
      "parameters": {
        "coseValue": -49,
        "ianaRecommended": "Yes"
      }
    },
    {
      "id": "pb:cose-algorithm:cose:ml-dsa-87",
      "name": "ML-DSA-87",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "ML-DSA-87"
      ],
      "parameters": {
        "coseValue": -50,
        "ianaRecommended": "Yes"
      }
    },
    {
      "id": "pb:cose-algorithm:cose:rs1",
      "name": "RS1",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "RSASSA-PKCS1-v1_5 using SHA-1"
      ],
      "parameters": {
        "coseValue": -65535,
        "ianaRecommended": "Deprecated"
      }
    },
    {
      "id": "pb:cose-algorithm:cose:rs256",
      "name": "RS256",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "RSASSA-PKCS1-v1_5 SHA-256"
      ],
      "parameters": {
        "coseValue": -257,
        "ianaRecommended": "No"
      }
    },
    {
      "id": "pb:cose-algorithm:cose:rs384",
      "name": "RS384",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "RSASSA-PKCS1-v1_5 SHA-384"
      ],
      "parameters": {
        "coseValue": -258,
        "ianaRecommended": "No"
      }
    },
    {
      "id": "pb:cose-algorithm:cose:rs512",
      "name": "RS512",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "RSASSA-PKCS1-v1_5 SHA-512"
      ],
      "parameters": {
        "coseValue": -259,
        "ianaRecommended": "No"
      }
    },
    {
      "id": "pb:cose-algorithm:cose:turboshake128",
      "name": "TurboSHAKE128",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "TurboSHAKE128"
      ],
      "parameters": {
        "coseValue": -261,
        "ianaRecommended": "No"
      }
    },
    {
      "id": "pb:cose-algorithm:cose:turboshake256",
      "name": "TurboSHAKE256",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "TurboSHAKE256"
      ],
      "parameters": {
        "coseValue": -262,
        "ianaRecommended": "No"
      }
    },
    {
      "id": "pb:cose-algorithm:cose:walnutdsa",
      "name": "WalnutDSA",
      "kind": "cose-algorithm",
      "family": "COSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA COSE Algorithms",
      "references": [
        "IANA COSE registry"
      ],
      "aliases": [
        "WalnutDSA"
      ],
      "parameters": {
        "coseValue": -260,
        "ianaRecommended": "No"
      }
    },
    {
      "id": "pb:curve-or-group:binary-elliptic-curves:sect163k1",
      "name": "sect163k1",
      "kind": "curve-or-group",
      "family": "binary-elliptic-curves",
      "specificationStatus": "legacy",
      "securityStatus": "legacy",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:curve-or-group:binary-elliptic-curves:sect163r1",
      "name": "sect163r1",
      "kind": "curve-or-group",
      "family": "binary-elliptic-curves",
      "specificationStatus": "legacy",
      "securityStatus": "legacy",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:curve-or-group:binary-elliptic-curves:sect163r2",
      "name": "sect163r2",
      "kind": "curve-or-group",
      "family": "binary-elliptic-curves",
      "specificationStatus": "legacy",
      "securityStatus": "legacy",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:curve-or-group:binary-elliptic-curves:sect233k1",
      "name": "sect233k1",
      "kind": "curve-or-group",
      "family": "binary-elliptic-curves",
      "specificationStatus": "legacy",
      "securityStatus": "legacy",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:curve-or-group:binary-elliptic-curves:sect233r1",
      "name": "sect233r1",
      "kind": "curve-or-group",
      "family": "binary-elliptic-curves",
      "specificationStatus": "legacy",
      "securityStatus": "legacy",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:curve-or-group:binary-elliptic-curves:sect283k1",
      "name": "sect283k1",
      "kind": "curve-or-group",
      "family": "binary-elliptic-curves",
      "specificationStatus": "legacy",
      "securityStatus": "legacy",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:curve-or-group:binary-elliptic-curves:sect283r1",
      "name": "sect283r1",
      "kind": "curve-or-group",
      "family": "binary-elliptic-curves",
      "specificationStatus": "legacy",
      "securityStatus": "legacy",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:curve-or-group:binary-elliptic-curves:sect409k1",
      "name": "sect409k1",
      "kind": "curve-or-group",
      "family": "binary-elliptic-curves",
      "specificationStatus": "legacy",
      "securityStatus": "legacy",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:curve-or-group:binary-elliptic-curves:sect409r1",
      "name": "sect409r1",
      "kind": "curve-or-group",
      "family": "binary-elliptic-curves",
      "specificationStatus": "legacy",
      "securityStatus": "legacy",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:curve-or-group:binary-elliptic-curves:sect571k1",
      "name": "sect571k1",
      "kind": "curve-or-group",
      "family": "binary-elliptic-curves",
      "specificationStatus": "legacy",
      "securityStatus": "legacy",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:curve-or-group:binary-elliptic-curves:sect571r1",
      "name": "sect571r1",
      "kind": "curve-or-group",
      "family": "binary-elliptic-curves",
      "specificationStatus": "legacy",
      "securityStatus": "legacy",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:curve-or-group:elliptic-curves:curve25519",
      "name": "Curve25519",
      "kind": "curve-or-group",
      "family": "elliptic-curves",
      "specificationStatus": "RFC-standardized",
      "securityStatus": "accepted-or-legacy",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "fieldBitsApprox": 255
      }
    },
    {
      "id": "pb:curve-or-group:elliptic-curves:curve448",
      "name": "Curve448",
      "kind": "curve-or-group",
      "family": "elliptic-curves",
      "specificationStatus": "RFC-standardized",
      "securityStatus": "accepted-or-legacy",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "fieldBitsApprox": 448
      }
    },
    {
      "id": "pb:curve-or-group:elliptic-curves:edwards25519",
      "name": "Edwards25519",
      "kind": "curve-or-group",
      "family": "elliptic-curves",
      "specificationStatus": "RFC-standardized",
      "securityStatus": "accepted-or-legacy",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "fieldBitsApprox": 255
      }
    },
    {
      "id": "pb:curve-or-group:elliptic-curves:edwards448",
      "name": "Edwards448",
      "kind": "curve-or-group",
      "family": "elliptic-curves",
      "specificationStatus": "RFC-standardized",
      "securityStatus": "accepted-or-legacy",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "fieldBitsApprox": 448
      }
    },
    {
      "id": "pb:curve-or-group:elliptic-curves:p-192",
      "name": "P-192",
      "kind": "curve-or-group",
      "family": "elliptic-curves",
      "specificationStatus": "legacy",
      "securityStatus": "accepted-or-legacy",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "fieldBitsApprox": 192
      }
    },
    {
      "id": "pb:curve-or-group:elliptic-curves:p-224",
      "name": "P-224",
      "kind": "curve-or-group",
      "family": "elliptic-curves",
      "specificationStatus": "legacy",
      "securityStatus": "accepted-or-legacy",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "fieldBitsApprox": 224
      }
    },
    {
      "id": "pb:curve-or-group:elliptic-curves:p-256",
      "name": "P-256",
      "kind": "curve-or-group",
      "family": "elliptic-curves",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-or-legacy",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "fieldBitsApprox": 256
      }
    },
    {
      "id": "pb:curve-or-group:elliptic-curves:p-384",
      "name": "P-384",
      "kind": "curve-or-group",
      "family": "elliptic-curves",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-or-legacy",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "fieldBitsApprox": 384
      }
    },
    {
      "id": "pb:curve-or-group:elliptic-curves:p-521",
      "name": "P-521",
      "kind": "curve-or-group",
      "family": "elliptic-curves",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-or-legacy",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "fieldBitsApprox": 521
      }
    },
    {
      "id": "pb:curve-or-group:elliptic-curves:sm2p256v1",
      "name": "SM2P256V1",
      "kind": "curve-or-group",
      "family": "elliptic-curves",
      "specificationStatus": "national-standard",
      "securityStatus": "accepted-or-legacy",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "fieldBitsApprox": 256
      }
    },
    {
      "id": "pb:curve-or-group:elliptic-curves:brainpoolp256r1",
      "name": "brainpoolP256r1",
      "kind": "curve-or-group",
      "family": "elliptic-curves",
      "specificationStatus": "RFC/standardized",
      "securityStatus": "accepted-or-legacy",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "fieldBitsApprox": 256
      }
    },
    {
      "id": "pb:curve-or-group:elliptic-curves:brainpoolp320r1",
      "name": "brainpoolP320r1",
      "kind": "curve-or-group",
      "family": "elliptic-curves",
      "specificationStatus": "RFC/standardized",
      "securityStatus": "accepted-or-legacy",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "fieldBitsApprox": 320
      }
    },
    {
      "id": "pb:curve-or-group:elliptic-curves:brainpoolp384r1",
      "name": "brainpoolP384r1",
      "kind": "curve-or-group",
      "family": "elliptic-curves",
      "specificationStatus": "RFC/standardized",
      "securityStatus": "accepted-or-legacy",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "fieldBitsApprox": 384
      }
    },
    {
      "id": "pb:curve-or-group:elliptic-curves:brainpoolp512r1",
      "name": "brainpoolP512r1",
      "kind": "curve-or-group",
      "family": "elliptic-curves",
      "specificationStatus": "RFC/standardized",
      "securityStatus": "accepted-or-legacy",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "fieldBitsApprox": 512
      }
    },
    {
      "id": "pb:curve-or-group:elliptic-curves:secp256k1",
      "name": "secp256k1",
      "kind": "curve-or-group",
      "family": "elliptic-curves",
      "specificationStatus": "deployed/SECG",
      "securityStatus": "accepted-or-legacy",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "fieldBitsApprox": 256
      }
    },
    {
      "id": "pb:drbg-or-csprng:ctr-drbg:ctr-drbg",
      "name": "CTR_DRBG",
      "kind": "drbg-or-csprng",
      "family": "CTR_DRBG",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-90A"
    },
    {
      "id": "pb:drbg-or-csprng:chacha20-drbg:chacha20-drbg",
      "name": "ChaCha20 DRBG",
      "kind": "drbg-or-csprng",
      "family": "ChaCha20 DRBG",
      "specificationStatus": "context-dependent",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "deployed"
    },
    {
      "id": "pb:drbg-or-csprng:dual-ec-drbg:dual-ec-drbg",
      "name": "Dual_EC_DRBG",
      "kind": "drbg-or-csprng",
      "family": "Dual_EC_DRBG",
      "specificationStatus": "withdrawn",
      "securityStatus": "known-backdoor-concern",
      "quantumClass": "classical",
      "generationPolicy": "deny",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-90A historical"
    },
    {
      "id": "pb:drbg-or-csprng:fortuna:fortuna",
      "name": "Fortuna",
      "kind": "drbg-or-csprng",
      "family": "Fortuna",
      "specificationStatus": "accepted",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "published"
    },
    {
      "id": "pb:drbg-or-csprng:hmac-drbg:hmac-drbg",
      "name": "HMAC_DRBG",
      "kind": "drbg-or-csprng",
      "family": "HMAC_DRBG",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-90A"
    },
    {
      "id": "pb:drbg-or-csprng:hash-drbg:hash-drbg",
      "name": "Hash_DRBG",
      "kind": "drbg-or-csprng",
      "family": "Hash_DRBG",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-90A"
    },
    {
      "id": "pb:drbg-or-csprng:isaac:isaac",
      "name": "ISAAC",
      "kind": "drbg-or-csprng",
      "family": "ISAAC",
      "specificationStatus": "legacy",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "published"
    },
    {
      "id": "pb:drbg-or-csprng:rc4-prng:rc4-prng",
      "name": "RC4 PRNG",
      "kind": "drbg-or-csprng",
      "family": "RC4 PRNG",
      "specificationStatus": "unsafe",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "deny",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "legacy"
    },
    {
      "id": "pb:drbg-or-csprng:yarrow:yarrow",
      "name": "Yarrow",
      "kind": "drbg-or-csprng",
      "family": "Yarrow",
      "specificationStatus": "legacy",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "published"
    },
    {
      "id": "pb:encoding-or-container:asn-1-der:asn-1-der",
      "name": "ASN.1 DER",
      "kind": "encoding-or-container",
      "family": "ASN.1 DER",
      "specificationStatus": "standardized/deployed",
      "securityStatus": "not-a-primitive",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "notes": "Registered to prevent container/algorithm conflation."
    },
    {
      "id": "pb:encoding-or-container:cms:cms",
      "name": "CMS",
      "kind": "encoding-or-container",
      "family": "CMS",
      "specificationStatus": "standardized/deployed",
      "securityStatus": "not-a-primitive",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "notes": "Registered to prevent container/algorithm conflation."
    },
    {
      "id": "pb:encoding-or-container:cose-key:cose-key",
      "name": "COSE_Key",
      "kind": "encoding-or-container",
      "family": "COSE_Key",
      "specificationStatus": "standardized/deployed",
      "securityStatus": "not-a-primitive",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "notes": "Registered to prevent container/algorithm conflation."
    },
    {
      "id": "pb:encoding-or-container:cose-sign1:cose-sign1",
      "name": "COSE_Sign1",
      "kind": "encoding-or-container",
      "family": "COSE_Sign1",
      "specificationStatus": "standardized/deployed",
      "securityStatus": "not-a-primitive",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "notes": "Registered to prevent container/algorithm conflation."
    },
    {
      "id": "pb:encoding-or-container:jwe:jwe",
      "name": "JWE",
      "kind": "encoding-or-container",
      "family": "JWE",
      "specificationStatus": "standardized/deployed",
      "securityStatus": "not-a-primitive",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "notes": "Registered to prevent container/algorithm conflation."
    },
    {
      "id": "pb:encoding-or-container:jwk:jwk",
      "name": "JWK",
      "kind": "encoding-or-container",
      "family": "JWK",
      "specificationStatus": "standardized/deployed",
      "securityStatus": "not-a-primitive",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "notes": "Registered to prevent container/algorithm conflation."
    },
    {
      "id": "pb:encoding-or-container:jws:jws",
      "name": "JWS",
      "kind": "encoding-or-container",
      "family": "JWS",
      "specificationStatus": "standardized/deployed",
      "securityStatus": "not-a-primitive",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "notes": "Registered to prevent container/algorithm conflation."
    },
    {
      "id": "pb:encoding-or-container:openpgp-packet-format:openpgp-packet-format",
      "name": "OpenPGP packet format",
      "kind": "encoding-or-container",
      "family": "OpenPGP packet format",
      "specificationStatus": "standardized/deployed",
      "securityStatus": "not-a-primitive",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "notes": "Registered to prevent container/algorithm conflation."
    },
    {
      "id": "pb:encoding-or-container:pem:pem",
      "name": "PEM",
      "kind": "encoding-or-container",
      "family": "PEM",
      "specificationStatus": "standardized/deployed",
      "securityStatus": "not-a-primitive",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "notes": "Registered to prevent container/algorithm conflation."
    },
    {
      "id": "pb:encoding-or-container:pkcs-1:pkcs-1",
      "name": "PKCS#1",
      "kind": "encoding-or-container",
      "family": "PKCS#1",
      "specificationStatus": "standardized/deployed",
      "securityStatus": "not-a-primitive",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "notes": "Registered to prevent container/algorithm conflation."
    },
    {
      "id": "pb:encoding-or-container:pkcs-8:pkcs-8",
      "name": "PKCS#8",
      "kind": "encoding-or-container",
      "family": "PKCS#8",
      "specificationStatus": "standardized/deployed",
      "securityStatus": "not-a-primitive",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "notes": "Registered to prevent container/algorithm conflation."
    },
    {
      "id": "pb:encoding-or-container:spki:spki",
      "name": "SPKI",
      "kind": "encoding-or-container",
      "family": "SPKI",
      "specificationStatus": "standardized/deployed",
      "securityStatus": "not-a-primitive",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "notes": "Registered to prevent container/algorithm conflation."
    },
    {
      "id": "pb:encoding-or-container:ssh-public-key-format:ssh-public-key-format",
      "name": "SSH public key format",
      "kind": "encoding-or-container",
      "family": "SSH public key format",
      "specificationStatus": "standardized/deployed",
      "securityStatus": "not-a-primitive",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "notes": "Registered to prevent container/algorithm conflation."
    },
    {
      "id": "pb:encoding-or-container:x-509:x-509",
      "name": "X.509",
      "kind": "encoding-or-container",
      "family": "X.509",
      "specificationStatus": "standardized/deployed",
      "securityStatus": "not-a-primitive",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "notes": "Registered to prevent container/algorithm conflation."
    },
    {
      "id": "pb:entropy-interface:rdrand:rdrand",
      "name": "RDRAND",
      "kind": "entropy-interface",
      "family": "RDRAND",
      "specificationStatus": "platform-interface",
      "securityStatus": "implementation-and-platform-dependent",
      "quantumClass": "classical",
      "generationPolicy": "allow-with-health-tests",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:entropy-interface:rdseed:rdseed",
      "name": "RDSEED",
      "kind": "entropy-interface",
      "family": "RDSEED",
      "specificationStatus": "platform-interface",
      "securityStatus": "implementation-and-platform-dependent",
      "quantumClass": "classical",
      "generationPolicy": "allow-with-health-tests",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:entropy-interface:tpm-rng:tpm-rng",
      "name": "TPM RNG",
      "kind": "entropy-interface",
      "family": "TPM RNG",
      "specificationStatus": "platform-interface",
      "securityStatus": "implementation-and-platform-dependent",
      "quantumClass": "classical",
      "generationPolicy": "allow-with-health-tests",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:entropy-interface:webcrypto-getrandomvalues:webcrypto-getrandomvalues",
      "name": "WebCrypto getRandomValues",
      "kind": "entropy-interface",
      "family": "WebCrypto getRandomValues",
      "specificationStatus": "platform-interface",
      "securityStatus": "implementation-and-platform-dependent",
      "quantumClass": "classical",
      "generationPolicy": "allow-with-health-tests",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:entropy-interface:getrandom-os-csprng:getrandom-os-csprng",
      "name": "getrandom()/OS CSPRNG",
      "kind": "entropy-interface",
      "family": "getrandom()/OS CSPRNG",
      "specificationStatus": "platform-interface",
      "securityStatus": "implementation-and-platform-dependent",
      "quantumClass": "classical",
      "generationPolicy": "allow-with-health-tests",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:finite-field-group:ffdhe:ffdhe2048",
      "name": "ffdhe2048",
      "kind": "finite-field-group",
      "family": "FFDHE",
      "specificationStatus": "standardized-RFC",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 7919",
      "references": [
        "RFC 7919"
      ],
      "parameters": {
        "modulusBits": 2048
      }
    },
    {
      "id": "pb:finite-field-group:ffdhe:ffdhe3072",
      "name": "ffdhe3072",
      "kind": "finite-field-group",
      "family": "FFDHE",
      "specificationStatus": "standardized-RFC",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 7919",
      "references": [
        "RFC 7919"
      ],
      "parameters": {
        "modulusBits": 3072
      }
    },
    {
      "id": "pb:finite-field-group:ffdhe:ffdhe4096",
      "name": "ffdhe4096",
      "kind": "finite-field-group",
      "family": "FFDHE",
      "specificationStatus": "standardized-RFC",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 7919",
      "references": [
        "RFC 7919"
      ],
      "parameters": {
        "modulusBits": 4096
      }
    },
    {
      "id": "pb:finite-field-group:ffdhe:ffdhe6144",
      "name": "ffdhe6144",
      "kind": "finite-field-group",
      "family": "FFDHE",
      "specificationStatus": "standardized-RFC",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 7919",
      "references": [
        "RFC 7919"
      ],
      "parameters": {
        "modulusBits": 6144
      }
    },
    {
      "id": "pb:finite-field-group:ffdhe:ffdhe8192",
      "name": "ffdhe8192",
      "kind": "finite-field-group",
      "family": "FFDHE",
      "specificationStatus": "standardized-RFC",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 7919",
      "references": [
        "RFC 7919"
      ],
      "parameters": {
        "modulusBits": 8192
      }
    },
    {
      "id": "pb:format-preserving-encryption:ff3:ff3",
      "name": "FF3",
      "kind": "format-preserving-encryption",
      "family": "FF3",
      "specificationStatus": "superseded",
      "securityStatus": "restricted/obsolete-version",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "NIST SP 800-38G"
      ]
    },
    {
      "id": "pb:hardness-assumption:learning-with-errors-lwe:learning-with-errors-lwe",
      "name": "Learning With Errors (LWE)",
      "kind": "hardness-assumption",
      "family": "Learning With Errors (LWE)",
      "specificationStatus": "research-foundation",
      "securityStatus": "assumption-or-family-not-standalone-algorithm",
      "quantumClass": "post_quantum",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hardness-assumption:learning-with-rounding-lwr:learning-with-rounding-lwr",
      "name": "Learning With Rounding (LWR)",
      "kind": "hardness-assumption",
      "family": "Learning With Rounding (LWR)",
      "specificationStatus": "research-foundation",
      "securityStatus": "assumption-or-family-not-standalone-algorithm",
      "quantumClass": "post_quantum",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hardness-assumption:module-lwe:module-lwe",
      "name": "Module-LWE",
      "kind": "hardness-assumption",
      "family": "Module-LWE",
      "specificationStatus": "research-foundation",
      "securityStatus": "assumption-or-family-not-standalone-algorithm",
      "quantumClass": "post_quantum",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hardness-assumption:module-lwr:module-lwr",
      "name": "Module-LWR",
      "kind": "hardness-assumption",
      "family": "Module-LWR",
      "specificationStatus": "research-foundation",
      "securityStatus": "assumption-or-family-not-standalone-algorithm",
      "quantumClass": "post_quantum",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hardness-assumption:module-sis:module-sis",
      "name": "Module-SIS",
      "kind": "hardness-assumption",
      "family": "Module-SIS",
      "specificationStatus": "research-foundation",
      "securityStatus": "assumption-or-family-not-standalone-algorithm",
      "quantumClass": "post_quantum",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hardness-assumption:multivariate-quadratic-mq:multivariate-quadratic-mq",
      "name": "Multivariate Quadratic (MQ)",
      "kind": "hardness-assumption",
      "family": "Multivariate Quadratic (MQ)",
      "specificationStatus": "research-foundation",
      "securityStatus": "assumption-or-family-not-standalone-algorithm",
      "quantumClass": "post_quantum",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hardness-assumption:ntru-lattice-problem:ntru-lattice-problem",
      "name": "NTRU lattice problem",
      "kind": "hardness-assumption",
      "family": "NTRU lattice problem",
      "specificationStatus": "research-foundation",
      "securityStatus": "assumption-or-family-not-standalone-algorithm",
      "quantumClass": "post_quantum",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hardness-assumption:ring-lwe:ring-lwe",
      "name": "Ring-LWE",
      "kind": "hardness-assumption",
      "family": "Ring-LWE",
      "specificationStatus": "research-foundation",
      "securityStatus": "assumption-or-family-not-standalone-algorithm",
      "quantumClass": "post_quantum",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hardness-assumption:sis:sis",
      "name": "SIS",
      "kind": "hardness-assumption",
      "family": "SIS",
      "specificationStatus": "research-foundation",
      "securityStatus": "assumption-or-family-not-standalone-algorithm",
      "quantumClass": "post_quantum",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hardness-family:isogeny-based-cryptography:isogeny-based-cryptography",
      "name": "Isogeny-based cryptography",
      "kind": "hardness-family",
      "family": "Isogeny-based cryptography",
      "specificationStatus": "research-foundation",
      "securityStatus": "assumption-or-family-not-standalone-algorithm",
      "quantumClass": "post_quantum",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hash:ascon:ascon-hash256",
      "name": "Ascon-Hash256",
      "kind": "hash",
      "family": "Ascon",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-232",
      "references": [
        "NIST SP 800-232"
      ],
      "parameters": {
        "digestBits": 256
      }
    },
    {
      "id": "pb:hash:blake:blake-224",
      "name": "BLAKE-224",
      "kind": "hash",
      "family": "BLAKE",
      "specificationStatus": "legacy-finalist",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "digestBits": 224
      }
    },
    {
      "id": "pb:hash:blake:blake-256",
      "name": "BLAKE-256",
      "kind": "hash",
      "family": "BLAKE",
      "specificationStatus": "legacy-finalist",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "digestBits": 256
      }
    },
    {
      "id": "pb:hash:blake:blake-384",
      "name": "BLAKE-384",
      "kind": "hash",
      "family": "BLAKE",
      "specificationStatus": "legacy-finalist",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "digestBits": 384
      }
    },
    {
      "id": "pb:hash:blake:blake-512",
      "name": "BLAKE-512",
      "kind": "hash",
      "family": "BLAKE",
      "specificationStatus": "legacy-finalist",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "digestBits": 512
      }
    },
    {
      "id": "pb:hash:blake2:blake2b-512",
      "name": "BLAKE2b-512",
      "kind": "hash",
      "family": "BLAKE2",
      "specificationStatus": "standardized-RFC",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 7693",
      "references": [
        "RFC 7693"
      ],
      "parameters": {
        "digestBits": 512
      }
    },
    {
      "id": "pb:hash:blake2:blake2s-256",
      "name": "BLAKE2s-256",
      "kind": "hash",
      "family": "BLAKE2",
      "specificationStatus": "standardized-RFC",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 7693",
      "references": [
        "RFC 7693"
      ],
      "parameters": {
        "digestBits": 256
      }
    },
    {
      "id": "pb:hash:bmw:bmw-256",
      "name": "BMW-256",
      "kind": "hash",
      "family": "BMW",
      "specificationStatus": "research-or-historical",
      "securityStatus": "not-currently-primary-standard",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hash:bmw:bmw-512",
      "name": "BMW-512",
      "kind": "hash",
      "family": "BMW",
      "specificationStatus": "research-or-historical",
      "securityStatus": "not-currently-primary-standard",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hash:cubehash:cubehash-256",
      "name": "CubeHash-256",
      "kind": "hash",
      "family": "CubeHash",
      "specificationStatus": "research-or-historical",
      "securityStatus": "not-currently-primary-standard",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hash:cubehash:cubehash-512",
      "name": "CubeHash-512",
      "kind": "hash",
      "family": "CubeHash",
      "specificationStatus": "research-or-historical",
      "securityStatus": "not-currently-primary-standard",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hash:echo:echo-256",
      "name": "Echo-256",
      "kind": "hash",
      "family": "Echo",
      "specificationStatus": "research-or-historical",
      "securityStatus": "not-currently-primary-standard",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hash:echo:echo-512",
      "name": "Echo-512",
      "kind": "hash",
      "family": "Echo",
      "specificationStatus": "research-or-historical",
      "securityStatus": "not-currently-primary-standard",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hash:fugue:fugue-256",
      "name": "Fugue-256",
      "kind": "hash",
      "family": "Fugue",
      "specificationStatus": "research-or-historical",
      "securityStatus": "not-currently-primary-standard",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hash:fugue:fugue-512",
      "name": "Fugue-512",
      "kind": "hash",
      "family": "Fugue",
      "specificationStatus": "research-or-historical",
      "securityStatus": "not-currently-primary-standard",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hash:gost-r-34-11-2012:streebog-256",
      "name": "Streebog-256",
      "kind": "hash",
      "family": "GOST R 34.11-2012",
      "specificationStatus": "national-standard",
      "securityStatus": "accepted-or-legacy",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "digestBits": 256
      }
    },
    {
      "id": "pb:hash:gost-r-34-11-2012:streebog-512",
      "name": "Streebog-512",
      "kind": "hash",
      "family": "GOST R 34.11-2012",
      "specificationStatus": "national-standard",
      "securityStatus": "accepted-or-legacy",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "digestBits": 512
      }
    },
    {
      "id": "pb:hash:groestl:groestl-256",
      "name": "Groestl-256",
      "kind": "hash",
      "family": "Groestl",
      "specificationStatus": "research-or-historical",
      "securityStatus": "not-currently-primary-standard",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hash:groestl:groestl-512",
      "name": "Groestl-512",
      "kind": "hash",
      "family": "Groestl",
      "specificationStatus": "research-or-historical",
      "securityStatus": "not-currently-primary-standard",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hash:has-160:has-160",
      "name": "HAS-160",
      "kind": "hash",
      "family": "HAS-160",
      "specificationStatus": "legacy",
      "securityStatus": "accepted-or-legacy",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "digestBits": 160
      }
    },
    {
      "id": "pb:hash:haval:haval-128",
      "name": "HAVAL-128",
      "kind": "hash",
      "family": "HAVAL",
      "specificationStatus": "research-or-historical",
      "securityStatus": "not-currently-primary-standard",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hash:haval:haval-160",
      "name": "HAVAL-160",
      "kind": "hash",
      "family": "HAVAL",
      "specificationStatus": "research-or-historical",
      "securityStatus": "not-currently-primary-standard",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hash:haval:haval-192",
      "name": "HAVAL-192",
      "kind": "hash",
      "family": "HAVAL",
      "specificationStatus": "research-or-historical",
      "securityStatus": "not-currently-primary-standard",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hash:haval:haval-224",
      "name": "HAVAL-224",
      "kind": "hash",
      "family": "HAVAL",
      "specificationStatus": "research-or-historical",
      "securityStatus": "not-currently-primary-standard",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hash:haval:haval-256",
      "name": "HAVAL-256",
      "kind": "hash",
      "family": "HAVAL",
      "specificationStatus": "research-or-historical",
      "securityStatus": "not-currently-primary-standard",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hash:hamsi:hamsi-256",
      "name": "Hamsi-256",
      "kind": "hash",
      "family": "Hamsi",
      "specificationStatus": "research-or-historical",
      "securityStatus": "not-currently-primary-standard",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hash:hamsi:hamsi-512",
      "name": "Hamsi-512",
      "kind": "hash",
      "family": "Hamsi",
      "specificationStatus": "research-or-historical",
      "securityStatus": "not-currently-primary-standard",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hash:jh:jh-256",
      "name": "JH-256",
      "kind": "hash",
      "family": "JH",
      "specificationStatus": "research-or-historical",
      "securityStatus": "not-currently-primary-standard",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hash:jh:jh-512",
      "name": "JH-512",
      "kind": "hash",
      "family": "JH",
      "specificationStatus": "research-or-historical",
      "securityStatus": "not-currently-primary-standard",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hash:keccak:keccak-256",
      "name": "Keccak-256",
      "kind": "hash",
      "family": "Keccak",
      "specificationStatus": "deployed-non-FIPS-variant",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "notes": "Distinct padding/domain separation from standardized SHA3."
    },
    {
      "id": "pb:hash:keccak:keccak-512",
      "name": "Keccak-512",
      "kind": "hash",
      "family": "Keccak",
      "specificationStatus": "deployed-non-FIPS-variant",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "notes": "Distinct padding/domain separation from standardized SHA3."
    },
    {
      "id": "pb:hash:luffa:luffa-256",
      "name": "Luffa-256",
      "kind": "hash",
      "family": "Luffa",
      "specificationStatus": "research-or-historical",
      "securityStatus": "not-currently-primary-standard",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hash:luffa:luffa-512",
      "name": "Luffa-512",
      "kind": "hash",
      "family": "Luffa",
      "specificationStatus": "research-or-historical",
      "securityStatus": "not-currently-primary-standard",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hash:md:md2",
      "name": "MD2",
      "kind": "hash",
      "family": "MD",
      "specificationStatus": "obsolete",
      "securityStatus": "broken",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "digestBits": 128
      },
      "tags": [
        "legacy",
        "dangerous"
      ]
    },
    {
      "id": "pb:hash:md:md4",
      "name": "MD4",
      "kind": "hash",
      "family": "MD",
      "specificationStatus": "obsolete",
      "securityStatus": "broken",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "digestBits": 128
      },
      "tags": [
        "legacy",
        "dangerous"
      ]
    },
    {
      "id": "pb:hash:md:md5",
      "name": "MD5",
      "kind": "hash",
      "family": "MD",
      "specificationStatus": "obsolete",
      "securityStatus": "broken",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "digestBits": 128
      },
      "tags": [
        "legacy",
        "dangerous"
      ]
    },
    {
      "id": "pb:hash:panama:panama",
      "name": "Panama",
      "kind": "hash",
      "family": "Panama",
      "specificationStatus": "research-or-historical",
      "securityStatus": "not-currently-primary-standard",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hash:ripemd:ripemd-128",
      "name": "RIPEMD-128",
      "kind": "hash",
      "family": "RIPEMD",
      "specificationStatus": "legacy",
      "securityStatus": "weak",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "digestBits": 128
      }
    },
    {
      "id": "pb:hash:ripemd:ripemd-160",
      "name": "RIPEMD-160",
      "kind": "hash",
      "family": "RIPEMD",
      "specificationStatus": "legacy",
      "securityStatus": "legacy",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "digestBits": 160
      }
    },
    {
      "id": "pb:hash:ripemd:ripemd-256",
      "name": "RIPEMD-256",
      "kind": "hash",
      "family": "RIPEMD",
      "specificationStatus": "legacy",
      "securityStatus": "legacy",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "digestBits": 256
      }
    },
    {
      "id": "pb:hash:ripemd:ripemd-320",
      "name": "RIPEMD-320",
      "kind": "hash",
      "family": "RIPEMD",
      "specificationStatus": "legacy",
      "securityStatus": "legacy",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "digestBits": 320
      }
    },
    {
      "id": "pb:hash:radiogat-n:radiogat-n-32",
      "name": "RadioGatún-32",
      "kind": "hash",
      "family": "RadioGatún",
      "specificationStatus": "research-or-historical",
      "securityStatus": "not-currently-primary-standard",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hash:radiogat-n:radiogat-n-64",
      "name": "RadioGatún-64",
      "kind": "hash",
      "family": "RadioGatún",
      "specificationStatus": "research-or-historical",
      "securityStatus": "not-currently-primary-standard",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hash:sha-0:sha-0",
      "name": "SHA-0",
      "kind": "hash",
      "family": "SHA-0",
      "specificationStatus": "withdrawn",
      "securityStatus": "broken",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "digestBits": 160
      }
    },
    {
      "id": "pb:hash:sha-1:sha-1",
      "name": "SHA-1",
      "kind": "hash",
      "family": "SHA-1",
      "specificationStatus": "deprecated",
      "securityStatus": "collision-broken",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 180",
      "references": [
        "FIPS 180-4"
      ],
      "parameters": {
        "digestBits": 160
      }
    },
    {
      "id": "pb:hash:sha-2:sha-224",
      "name": "SHA-224",
      "kind": "hash",
      "family": "SHA-2",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 180-4",
      "references": [
        "FIPS 180-4"
      ],
      "parameters": {
        "digestBits": 224
      }
    },
    {
      "id": "pb:hash:sha-2:sha-256",
      "name": "SHA-256",
      "kind": "hash",
      "family": "SHA-2",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 180-4",
      "references": [
        "FIPS 180-4"
      ],
      "parameters": {
        "digestBits": 256
      }
    },
    {
      "id": "pb:hash:sha-2:sha-384",
      "name": "SHA-384",
      "kind": "hash",
      "family": "SHA-2",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 180-4",
      "references": [
        "FIPS 180-4"
      ],
      "parameters": {
        "digestBits": 384
      }
    },
    {
      "id": "pb:hash:sha-2:sha-512",
      "name": "SHA-512",
      "kind": "hash",
      "family": "SHA-2",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 180-4",
      "references": [
        "FIPS 180-4"
      ],
      "parameters": {
        "digestBits": 512
      }
    },
    {
      "id": "pb:hash:sha-2:sha-512-224",
      "name": "SHA-512/224",
      "kind": "hash",
      "family": "SHA-2",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 180-4",
      "references": [
        "FIPS 180-4"
      ],
      "parameters": {
        "digestBits": 224
      }
    },
    {
      "id": "pb:hash:sha-2:sha-512-256",
      "name": "SHA-512/256",
      "kind": "hash",
      "family": "SHA-2",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 180-4",
      "references": [
        "FIPS 180-4"
      ],
      "parameters": {
        "digestBits": 256
      }
    },
    {
      "id": "pb:hash:sha-3:sha3-224",
      "name": "SHA3-224",
      "kind": "hash",
      "family": "SHA-3",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 202",
      "references": [
        "FIPS 202"
      ],
      "parameters": {
        "digestBits": 224
      }
    },
    {
      "id": "pb:hash:sha-3:sha3-256",
      "name": "SHA3-256",
      "kind": "hash",
      "family": "SHA-3",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 202",
      "references": [
        "FIPS 202"
      ],
      "parameters": {
        "digestBits": 256
      }
    },
    {
      "id": "pb:hash:sha-3:sha3-384",
      "name": "SHA3-384",
      "kind": "hash",
      "family": "SHA-3",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 202",
      "references": [
        "FIPS 202"
      ],
      "parameters": {
        "digestBits": 384
      }
    },
    {
      "id": "pb:hash:sha-3:sha3-512",
      "name": "SHA3-512",
      "kind": "hash",
      "family": "SHA-3",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 202",
      "references": [
        "FIPS 202"
      ],
      "parameters": {
        "digestBits": 512
      }
    },
    {
      "id": "pb:hash:shavite:shavite-3-256",
      "name": "SHAvite-3-256",
      "kind": "hash",
      "family": "SHAvite",
      "specificationStatus": "research-or-historical",
      "securityStatus": "not-currently-primary-standard",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hash:shavite:shavite-3-512",
      "name": "SHAvite-3-512",
      "kind": "hash",
      "family": "SHAvite",
      "specificationStatus": "research-or-historical",
      "securityStatus": "not-currently-primary-standard",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hash:simd:simd-256",
      "name": "SIMD-256",
      "kind": "hash",
      "family": "SIMD",
      "specificationStatus": "research-or-historical",
      "securityStatus": "not-currently-primary-standard",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hash:simd:simd-512",
      "name": "SIMD-512",
      "kind": "hash",
      "family": "SIMD",
      "specificationStatus": "research-or-historical",
      "securityStatus": "not-currently-primary-standard",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hash:sm3:sm3",
      "name": "SM3",
      "kind": "hash",
      "family": "SM3",
      "specificationStatus": "national-standard",
      "securityStatus": "accepted-or-legacy",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "digestBits": 256
      }
    },
    {
      "id": "pb:hash:skein:skein-1024",
      "name": "Skein-1024",
      "kind": "hash",
      "family": "Skein",
      "specificationStatus": "research-or-historical",
      "securityStatus": "not-currently-primary-standard",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hash:skein:skein-256",
      "name": "Skein-256",
      "kind": "hash",
      "family": "Skein",
      "specificationStatus": "research-or-historical",
      "securityStatus": "not-currently-primary-standard",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hash:skein:skein-512",
      "name": "Skein-512",
      "kind": "hash",
      "family": "Skein",
      "specificationStatus": "research-or-historical",
      "securityStatus": "not-currently-primary-standard",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:hash:tiger:tiger",
      "name": "Tiger",
      "kind": "hash",
      "family": "Tiger",
      "specificationStatus": "legacy",
      "securityStatus": "accepted-or-legacy",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "digestBits": 192
      }
    },
    {
      "id": "pb:hash:tiger2:tiger2",
      "name": "Tiger2",
      "kind": "hash",
      "family": "Tiger2",
      "specificationStatus": "legacy",
      "securityStatus": "accepted-or-legacy",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "digestBits": 192
      }
    },
    {
      "id": "pb:hash:whirlpool:whirlpool",
      "name": "Whirlpool",
      "kind": "hash",
      "family": "Whirlpool",
      "specificationStatus": "legacy",
      "securityStatus": "accepted-or-legacy",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "digestBits": 512
      }
    },
    {
      "id": "pb:hash-or-xof:blake3:blake3",
      "name": "BLAKE3",
      "kind": "hash-or-xof",
      "family": "BLAKE3",
      "specificationStatus": "published",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "defaultDigestBits": 256
      }
    },
    {
      "id": "pb:hash-or-xof:sp800-185:parallelhash128",
      "name": "ParallelHash128",
      "kind": "hash-or-xof",
      "family": "SP800-185",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-185",
      "references": [
        "NIST SP 800-185"
      ],
      "parameters": {
        "securityStrengthBits": 128
      }
    },
    {
      "id": "pb:hash-or-xof:sp800-185:parallelhash256",
      "name": "ParallelHash256",
      "kind": "hash-or-xof",
      "family": "SP800-185",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-185",
      "references": [
        "NIST SP 800-185"
      ],
      "parameters": {
        "securityStrengthBits": 256
      }
    },
    {
      "id": "pb:hash-or-xof:sp800-185:tuplehash128",
      "name": "TupleHash128",
      "kind": "hash-or-xof",
      "family": "SP800-185",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-185",
      "references": [
        "NIST SP 800-185"
      ],
      "parameters": {
        "securityStrengthBits": 128
      }
    },
    {
      "id": "pb:hash-or-xof:sp800-185:tuplehash256",
      "name": "TupleHash256",
      "kind": "hash-or-xof",
      "family": "SP800-185",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-185",
      "references": [
        "NIST SP 800-185"
      ],
      "parameters": {
        "securityStrengthBits": 256
      }
    },
    {
      "id": "pb:hash-or-xof:sp800-185:cshake128",
      "name": "cSHAKE128",
      "kind": "hash-or-xof",
      "family": "SP800-185",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-185",
      "references": [
        "NIST SP 800-185"
      ],
      "parameters": {
        "securityStrengthBits": 128
      }
    },
    {
      "id": "pb:hash-or-xof:sp800-185:cshake256",
      "name": "cSHAKE256",
      "kind": "hash-or-xof",
      "family": "SP800-185",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-185",
      "references": [
        "NIST SP 800-185"
      ],
      "parameters": {
        "securityStrengthBits": 256
      }
    },
    {
      "id": "pb:hazard:cryptographic-misuse:aes-gcm-nonce-reuse",
      "name": "AES-GCM nonce reuse",
      "kind": "hazard",
      "family": "cryptographic-misuse",
      "specificationStatus": "known-hazard",
      "securityStatus": "catastrophic-authentication/confidentiality-failure",
      "quantumClass": "classical",
      "generationPolicy": "deny",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous",
        "negative-test-required"
      ]
    },
    {
      "id": "pb:hazard:cryptographic-misuse:algorithm-identifier-key-type-confusion",
      "name": "Algorithm identifier/key-type confusion",
      "kind": "hazard",
      "family": "cryptographic-misuse",
      "specificationStatus": "known-hazard",
      "securityStatus": "cross-algorithm-substitution-risk",
      "quantumClass": "classical",
      "generationPolicy": "deny",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous",
        "negative-test-required"
      ]
    },
    {
      "id": "pb:hazard:cryptographic-misuse:cbc-without-authentication",
      "name": "CBC without authentication",
      "kind": "hazard",
      "family": "cryptographic-misuse",
      "specificationStatus": "known-hazard",
      "securityStatus": "malleability/padding-oracle-risk",
      "quantumClass": "classical",
      "generationPolicy": "deny",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous",
        "negative-test-required"
      ]
    },
    {
      "id": "pb:hazard:cryptographic-misuse:crc-used-as-integrity-mac",
      "name": "CRC used as integrity MAC",
      "kind": "hazard",
      "family": "cryptographic-misuse",
      "specificationStatus": "known-hazard",
      "securityStatus": "forgery-trivial",
      "quantumClass": "classical",
      "generationPolicy": "deny",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous",
        "negative-test-required"
      ]
    },
    {
      "id": "pb:hazard:cryptographic-misuse:ctr-nonce-counter-reuse",
      "name": "CTR nonce/counter reuse",
      "kind": "hazard",
      "family": "cryptographic-misuse",
      "specificationStatus": "known-hazard",
      "securityStatus": "two-time-pad",
      "quantumClass": "classical",
      "generationPolicy": "deny",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous",
        "negative-test-required"
      ]
    },
    {
      "id": "pb:hazard:cryptographic-misuse:chacha20-poly1305-nonce-reuse",
      "name": "ChaCha20-Poly1305 nonce reuse",
      "kind": "hazard",
      "family": "cryptographic-misuse",
      "specificationStatus": "known-hazard",
      "securityStatus": "catastrophic-two-time-pad/authentication-risk",
      "quantumClass": "classical",
      "generationPolicy": "deny",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous",
        "negative-test-required"
      ]
    },
    {
      "id": "pb:hazard:cryptographic-misuse:dsa-nonce-reuse",
      "name": "DSA nonce reuse",
      "kind": "hazard",
      "family": "cryptographic-misuse",
      "specificationStatus": "known-hazard",
      "securityStatus": "private-key-recovery",
      "quantumClass": "classical",
      "generationPolicy": "deny",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous",
        "negative-test-required"
      ]
    },
    {
      "id": "pb:hazard:cryptographic-misuse:ecb-for-structured-data",
      "name": "ECB for structured data",
      "kind": "hazard",
      "family": "cryptographic-misuse",
      "specificationStatus": "known-hazard",
      "securityStatus": "pattern-leakage",
      "quantumClass": "classical",
      "generationPolicy": "deny",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous",
        "negative-test-required"
      ]
    },
    {
      "id": "pb:hazard:cryptographic-misuse:ecdsa-nonce-reuse",
      "name": "ECDSA nonce reuse",
      "kind": "hazard",
      "family": "cryptographic-misuse",
      "specificationStatus": "known-hazard",
      "securityStatus": "private-key-recovery",
      "quantumClass": "classical",
      "generationPolicy": "deny",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous",
        "negative-test-required"
      ]
    },
    {
      "id": "pb:hazard:cryptographic-misuse:ed25519-non-canonical-variant-confusion",
      "name": "Ed25519 non-canonical/variant confusion",
      "kind": "hazard",
      "family": "cryptographic-misuse",
      "specificationStatus": "known-hazard",
      "securityStatus": "interoperability/signature-validation-risk",
      "quantumClass": "classical",
      "generationPolicy": "deny",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous",
        "negative-test-required"
      ]
    },
    {
      "id": "pb:hazard:cryptographic-misuse:kem-decapsulation-without-implicit-rejection-where-required",
      "name": "KEM decapsulation without implicit rejection where required",
      "kind": "hazard",
      "family": "cryptographic-misuse",
      "specificationStatus": "known-hazard",
      "securityStatus": "CCA/security-risk",
      "quantumClass": "classical",
      "generationPolicy": "deny",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous",
        "negative-test-required"
      ]
    },
    {
      "id": "pb:hazard:cryptographic-misuse:password-hash-without-salt",
      "name": "Password hash without salt",
      "kind": "hazard",
      "family": "cryptographic-misuse",
      "specificationStatus": "known-hazard",
      "securityStatus": "precomputation-risk",
      "quantumClass": "classical",
      "generationPolicy": "deny",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous",
        "negative-test-required"
      ]
    },
    {
      "id": "pb:hazard:cryptographic-misuse:rsa-pkcs-1-v1-5-decryption-oracle",
      "name": "RSA PKCS#1 v1.5 decryption oracle",
      "kind": "hazard",
      "family": "cryptographic-misuse",
      "specificationStatus": "known-hazard",
      "securityStatus": "Bleichenbacher-class-risk",
      "quantumClass": "classical",
      "generationPolicy": "deny",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous",
        "negative-test-required"
      ]
    },
    {
      "id": "pb:hazard:cryptographic-misuse:raw-hash-as-password-kdf",
      "name": "Raw hash as password KDF",
      "kind": "hazard",
      "family": "cryptographic-misuse",
      "specificationStatus": "known-hazard",
      "securityStatus": "offline-cracking-risk",
      "quantumClass": "classical",
      "generationPolicy": "deny",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous",
        "negative-test-required"
      ]
    },
    {
      "id": "pb:hazard:cryptographic-misuse:unauthenticated-key-agreement",
      "name": "Unauthenticated key agreement",
      "kind": "hazard",
      "family": "cryptographic-misuse",
      "specificationStatus": "known-hazard",
      "securityStatus": "MITM-risk",
      "quantumClass": "classical",
      "generationPolicy": "deny",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous",
        "negative-test-required"
      ]
    },
    {
      "id": "pb:hazard:cryptographic-misuse:unkeyed-hash-used-as-authentication",
      "name": "Unkeyed hash used as authentication",
      "kind": "hazard",
      "family": "cryptographic-misuse",
      "specificationStatus": "known-hazard",
      "securityStatus": "forgery/no-authentication",
      "quantumClass": "classical",
      "generationPolicy": "deny",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous",
        "negative-test-required"
      ]
    },
    {
      "id": "pb:hpke-aead:hpke:aes-128-gcm",
      "name": "AES-128-GCM",
      "kind": "hpke-aead",
      "family": "HPKE",
      "specificationStatus": "registered",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA HPKE registry",
      "references": [
        "IANA HPKE registry",
        "RFC 9180"
      ],
      "parameters": {
        "ianaValue": "0x0001",
        "Nk": 16,
        "Nn": 12,
        "Nt": 16
      }
    },
    {
      "id": "pb:hpke-aead:hpke:aes-256-gcm",
      "name": "AES-256-GCM",
      "kind": "hpke-aead",
      "family": "HPKE",
      "specificationStatus": "registered",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA HPKE registry",
      "references": [
        "IANA HPKE registry",
        "RFC 9180"
      ],
      "parameters": {
        "ianaValue": "0x0002",
        "Nk": 32,
        "Nn": 12,
        "Nt": 16
      }
    },
    {
      "id": "pb:hpke-aead:hpke:chacha20poly1305",
      "name": "ChaCha20Poly1305",
      "kind": "hpke-aead",
      "family": "HPKE",
      "specificationStatus": "registered",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA HPKE registry",
      "references": [
        "IANA HPKE registry",
        "RFC 9180"
      ],
      "parameters": {
        "ianaValue": "0x0003",
        "Nk": 32,
        "Nn": 12,
        "Nt": 16
      }
    },
    {
      "id": "pb:hpke-aead:hpke:export-only",
      "name": "Export-only",
      "kind": "hpke-aead",
      "family": "HPKE",
      "specificationStatus": "registered",
      "securityStatus": "not-an-AEAD",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA HPKE registry",
      "references": [
        "IANA HPKE registry",
        "RFC 9180"
      ],
      "parameters": {
        "ianaValue": "0xFFFF",
        "Nk": null,
        "Nn": null,
        "Nt": null
      }
    },
    {
      "id": "pb:hpke-kdf:hpke:hkdf-sha256",
      "name": "HKDF-SHA256",
      "kind": "hpke-kdf",
      "family": "HPKE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-primitive",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA HPKE registry",
      "references": [
        "IANA HPKE registry"
      ],
      "parameters": {
        "ianaValue": "0x0001",
        "Nh": 32
      }
    },
    {
      "id": "pb:hpke-kdf:hpke:hkdf-sha384",
      "name": "HKDF-SHA384",
      "kind": "hpke-kdf",
      "family": "HPKE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-primitive",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA HPKE registry",
      "references": [
        "IANA HPKE registry"
      ],
      "parameters": {
        "ianaValue": "0x0002",
        "Nh": 48
      }
    },
    {
      "id": "pb:hpke-kdf:hpke:hkdf-sha512",
      "name": "HKDF-SHA512",
      "kind": "hpke-kdf",
      "family": "HPKE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-primitive",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA HPKE registry",
      "references": [
        "IANA HPKE registry"
      ],
      "parameters": {
        "ianaValue": "0x0003",
        "Nh": 64
      }
    },
    {
      "id": "pb:hpke-kdf:hpke:shake128",
      "name": "SHAKE128",
      "kind": "hpke-kdf",
      "family": "HPKE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-primitive",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA HPKE registry",
      "references": [
        "IANA HPKE registry"
      ],
      "parameters": {
        "ianaValue": "0x0010",
        "Nh": 32
      }
    },
    {
      "id": "pb:hpke-kdf:hpke:shake256",
      "name": "SHAKE256",
      "kind": "hpke-kdf",
      "family": "HPKE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-primitive",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA HPKE registry",
      "references": [
        "IANA HPKE registry"
      ],
      "parameters": {
        "ianaValue": "0x0011",
        "Nh": 64
      }
    },
    {
      "id": "pb:hpke-kdf:hpke:turboshake128",
      "name": "TurboSHAKE128",
      "kind": "hpke-kdf",
      "family": "HPKE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-primitive",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA HPKE registry",
      "references": [
        "IANA HPKE registry"
      ],
      "parameters": {
        "ianaValue": "0x0012",
        "Nh": 32
      }
    },
    {
      "id": "pb:hpke-kdf:hpke:turboshake256",
      "name": "TurboSHAKE256",
      "kind": "hpke-kdf",
      "family": "HPKE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-primitive",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA HPKE registry",
      "references": [
        "IANA HPKE registry"
      ],
      "parameters": {
        "ianaValue": "0x0013",
        "Nh": 64
      }
    },
    {
      "id": "pb:hpke-kem:hpke:dhkem-cp-256-hkdf-sha256",
      "name": "DHKEM(CP-256, HKDF-SHA256)",
      "kind": "hpke-kem",
      "family": "HPKE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-components-and-profile",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA HPKE registry",
      "references": [
        "IANA HPKE registry",
        "RFC 9180"
      ],
      "parameters": {
        "ianaValue": "0x0013",
        "Nsecret": 32,
        "Nenc": 32,
        "Npk": 32,
        "Nsk": 32,
        "authenticatedMode": true
      }
    },
    {
      "id": "pb:hpke-kem:hpke:dhkem-cp-384-hkdf-sha384",
      "name": "DHKEM(CP-384, HKDF-SHA384)",
      "kind": "hpke-kem",
      "family": "HPKE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-components-and-profile",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA HPKE registry",
      "references": [
        "IANA HPKE registry",
        "RFC 9180"
      ],
      "parameters": {
        "ianaValue": "0x0014",
        "Nsecret": 48,
        "Nenc": 48,
        "Npk": 48,
        "Nsk": 48,
        "authenticatedMode": true
      }
    },
    {
      "id": "pb:hpke-kem:hpke:dhkem-cp-521-hkdf-sha512",
      "name": "DHKEM(CP-521, HKDF-SHA512)",
      "kind": "hpke-kem",
      "family": "HPKE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-components-and-profile",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA HPKE registry",
      "references": [
        "IANA HPKE registry",
        "RFC 9180"
      ],
      "parameters": {
        "ianaValue": "0x0015",
        "Nsecret": 64,
        "Nenc": 66,
        "Npk": 66,
        "Nsk": 66,
        "authenticatedMode": true
      }
    },
    {
      "id": "pb:hpke-kem:hpke:dhkem-p-256-hkdf-sha256",
      "name": "DHKEM(P-256, HKDF-SHA256)",
      "kind": "hpke-kem",
      "family": "HPKE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-components-and-profile",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA HPKE registry",
      "references": [
        "IANA HPKE registry",
        "RFC 9180"
      ],
      "parameters": {
        "ianaValue": "0x0010",
        "Nsecret": 32,
        "Nenc": 65,
        "Npk": 65,
        "Nsk": 32,
        "authenticatedMode": true
      }
    },
    {
      "id": "pb:hpke-kem:hpke:dhkem-p-384-hkdf-sha384",
      "name": "DHKEM(P-384, HKDF-SHA384)",
      "kind": "hpke-kem",
      "family": "HPKE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-components-and-profile",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA HPKE registry",
      "references": [
        "IANA HPKE registry",
        "RFC 9180"
      ],
      "parameters": {
        "ianaValue": "0x0011",
        "Nsecret": 48,
        "Nenc": 97,
        "Npk": 97,
        "Nsk": 48,
        "authenticatedMode": true
      }
    },
    {
      "id": "pb:hpke-kem:hpke:dhkem-p-521-hkdf-sha512",
      "name": "DHKEM(P-521, HKDF-SHA512)",
      "kind": "hpke-kem",
      "family": "HPKE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-components-and-profile",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA HPKE registry",
      "references": [
        "IANA HPKE registry",
        "RFC 9180"
      ],
      "parameters": {
        "ianaValue": "0x0012",
        "Nsecret": 64,
        "Nenc": 133,
        "Npk": 133,
        "Nsk": 66,
        "authenticatedMode": true
      }
    },
    {
      "id": "pb:hpke-kem:hpke:dhkem-x25519-elligator-hkdf-sha256",
      "name": "DHKEM(X25519+Elligator, HKDF-SHA256)",
      "kind": "hpke-kem",
      "family": "HPKE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-components-and-profile",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA HPKE registry",
      "references": [
        "IANA HPKE registry",
        "RFC 9180"
      ],
      "parameters": {
        "ianaValue": "0x0022",
        "Nsecret": 32,
        "Nenc": 32,
        "Npk": 32,
        "Nsk": 32,
        "authenticatedMode": true
      }
    },
    {
      "id": "pb:hpke-kem:hpke:dhkem-x25519-hkdf-sha256",
      "name": "DHKEM(X25519, HKDF-SHA256)",
      "kind": "hpke-kem",
      "family": "HPKE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-components-and-profile",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA HPKE registry",
      "references": [
        "IANA HPKE registry",
        "RFC 9180"
      ],
      "parameters": {
        "ianaValue": "0x0020",
        "Nsecret": 32,
        "Nenc": 32,
        "Npk": 32,
        "Nsk": 32,
        "authenticatedMode": true
      }
    },
    {
      "id": "pb:hpke-kem:hpke:dhkem-x448-hkdf-sha512",
      "name": "DHKEM(X448, HKDF-SHA512)",
      "kind": "hpke-kem",
      "family": "HPKE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-components-and-profile",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA HPKE registry",
      "references": [
        "IANA HPKE registry",
        "RFC 9180"
      ],
      "parameters": {
        "ianaValue": "0x0021",
        "Nsecret": 64,
        "Nenc": 56,
        "Npk": 56,
        "Nsk": 56,
        "authenticatedMode": true
      }
    },
    {
      "id": "pb:hpke-kem:hpke:dhkem-secp256k1-hkdf-sha256",
      "name": "DHKEM(secp256k1, HKDF-SHA256)",
      "kind": "hpke-kem",
      "family": "HPKE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-components-and-profile",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA HPKE registry",
      "references": [
        "IANA HPKE registry",
        "RFC 9180"
      ],
      "parameters": {
        "ianaValue": "0x0016",
        "Nsecret": 32,
        "Nenc": 65,
        "Npk": 65,
        "Nsk": 32,
        "authenticatedMode": true
      }
    },
    {
      "id": "pb:hpke-kem:hpke:ml-kem-1024",
      "name": "ML-KEM-1024",
      "kind": "hpke-kem",
      "family": "HPKE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-components-and-profile",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA HPKE registry",
      "references": [
        "IANA HPKE registry",
        "RFC 9180"
      ],
      "parameters": {
        "ianaValue": "0x0042",
        "Nsecret": 32,
        "Nenc": 1568,
        "Npk": 1568,
        "Nsk": 64,
        "authenticatedMode": false
      }
    },
    {
      "id": "pb:hpke-kem:hpke:ml-kem-512",
      "name": "ML-KEM-512",
      "kind": "hpke-kem",
      "family": "HPKE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-components-and-profile",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA HPKE registry",
      "references": [
        "IANA HPKE registry",
        "RFC 9180"
      ],
      "parameters": {
        "ianaValue": "0x0040",
        "Nsecret": 32,
        "Nenc": 768,
        "Npk": 800,
        "Nsk": 64,
        "authenticatedMode": false
      }
    },
    {
      "id": "pb:hpke-kem:hpke:ml-kem-768",
      "name": "ML-KEM-768",
      "kind": "hpke-kem",
      "family": "HPKE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-components-and-profile",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA HPKE registry",
      "references": [
        "IANA HPKE registry",
        "RFC 9180"
      ],
      "parameters": {
        "ianaValue": "0x0041",
        "Nsecret": 32,
        "Nenc": 1088,
        "Npk": 1184,
        "Nsk": 64,
        "authenticatedMode": false
      }
    },
    {
      "id": "pb:hpke-kem:hpke:mlkem1024-p384",
      "name": "MLKEM1024-P384",
      "kind": "hpke-kem",
      "family": "HPKE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-components-and-profile",
      "quantumClass": "hybrid",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA HPKE registry",
      "references": [
        "IANA HPKE registry",
        "RFC 9180"
      ],
      "parameters": {
        "ianaValue": "0x0051",
        "Nsecret": 32,
        "Nenc": 1665,
        "Npk": 1665,
        "Nsk": 32,
        "authenticatedMode": false
      }
    },
    {
      "id": "pb:hpke-kem:hpke:mlkem768-p256",
      "name": "MLKEM768-P256",
      "kind": "hpke-kem",
      "family": "HPKE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-components-and-profile",
      "quantumClass": "hybrid",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA HPKE registry",
      "references": [
        "IANA HPKE registry",
        "RFC 9180"
      ],
      "parameters": {
        "ianaValue": "0x0050",
        "Nsecret": 32,
        "Nenc": 1153,
        "Npk": 1249,
        "Nsk": 32,
        "authenticatedMode": false
      }
    },
    {
      "id": "pb:hpke-kem:hpke:x-wing",
      "name": "X-Wing",
      "kind": "hpke-kem",
      "family": "HPKE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-components-and-profile",
      "quantumClass": "hybrid",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA HPKE registry",
      "references": [
        "IANA HPKE registry",
        "RFC 9180"
      ],
      "parameters": {
        "ianaValue": "0x647A",
        "Nsecret": 32,
        "Nenc": 1120,
        "Npk": 1216,
        "Nsk": 32,
        "authenticatedMode": false
      }
    },
    {
      "id": "pb:hpke-kem:hpke:x25519kyber768draft00",
      "name": "X25519Kyber768Draft00",
      "kind": "hpke-kem",
      "family": "HPKE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-components-and-profile",
      "quantumClass": "hybrid",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA HPKE registry",
      "references": [
        "IANA HPKE registry",
        "RFC 9180"
      ],
      "parameters": {
        "ianaValue": "0x0030",
        "Nsecret": 64,
        "Nenc": 1120,
        "Npk": 1216,
        "Nsk": 2432,
        "authenticatedMode": false
      }
    },
    {
      "id": "pb:hybrid-profile:pb-hybrid:ed25519-ml-dsa-65",
      "name": "Ed25519+ML-DSA-65",
      "kind": "hybrid-profile",
      "family": "PB-hybrid",
      "specificationStatus": "PB-profile-candidate",
      "securityStatus": "depends-on-combiner-proof-and-component-binding",
      "quantumClass": "hybrid",
      "generationPolicy": "experimental",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "notes": "PB-local profile until bound to a specific published combiner/specification."
    },
    {
      "id": "pb:hybrid-profile:pb-hybrid:ed25519-slh-dsa-shake-128f",
      "name": "Ed25519+SLH-DSA-SHAKE-128f",
      "kind": "hybrid-profile",
      "family": "PB-hybrid",
      "specificationStatus": "PB-profile-candidate",
      "securityStatus": "depends-on-combiner-proof-and-component-binding",
      "quantumClass": "hybrid",
      "generationPolicy": "experimental",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "notes": "PB-local profile until bound to a specific published combiner/specification."
    },
    {
      "id": "pb:hybrid-profile:pb-hybrid:p-256-ml-kem-768",
      "name": "P-256+ML-KEM-768",
      "kind": "hybrid-profile",
      "family": "PB-hybrid",
      "specificationStatus": "PB-profile-candidate",
      "securityStatus": "depends-on-combiner-proof-and-component-binding",
      "quantumClass": "hybrid",
      "generationPolicy": "experimental",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "notes": "PB-local profile until bound to a specific published combiner/specification."
    },
    {
      "id": "pb:hybrid-profile:pb-hybrid:p-256-ecdsa-ml-dsa-65",
      "name": "P-256-ECDSA+ML-DSA-65",
      "kind": "hybrid-profile",
      "family": "PB-hybrid",
      "specificationStatus": "PB-profile-candidate",
      "securityStatus": "depends-on-combiner-proof-and-component-binding",
      "quantumClass": "hybrid",
      "generationPolicy": "experimental",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "notes": "PB-local profile until bound to a specific published combiner/specification."
    },
    {
      "id": "pb:hybrid-profile:pb-hybrid:x25519-ml-kem-1024",
      "name": "X25519+ML-KEM-1024",
      "kind": "hybrid-profile",
      "family": "PB-hybrid",
      "specificationStatus": "PB-profile-candidate",
      "securityStatus": "depends-on-combiner-proof-and-component-binding",
      "quantumClass": "hybrid",
      "generationPolicy": "experimental",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "notes": "PB-local profile until bound to a specific published combiner/specification."
    },
    {
      "id": "pb:hybrid-profile:pb-hybrid:x25519-ml-kem-768",
      "name": "X25519+ML-KEM-768",
      "kind": "hybrid-profile",
      "family": "PB-hybrid",
      "specificationStatus": "PB-profile-candidate",
      "securityStatus": "depends-on-combiner-proof-and-component-binding",
      "quantumClass": "hybrid",
      "generationPolicy": "experimental",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "notes": "PB-local profile until bound to a specific published combiner/specification."
    },
    {
      "id": "pb:jose-content-encryption:jose:a128cbc-hs256",
      "name": "A128CBC-HS256",
      "kind": "jose-content-encryption",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Required",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "AES-128-CBC+HMAC-SHA256"
      ],
      "parameters": {
        "joseImplementationRequirement": "Required"
      }
    },
    {
      "id": "pb:jose-content-encryption:jose:a128gcm",
      "name": "A128GCM",
      "kind": "jose-content-encryption",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Recommended",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "AES-128-GCM"
      ],
      "parameters": {
        "joseImplementationRequirement": "Recommended"
      }
    },
    {
      "id": "pb:jose-content-encryption:jose:a192cbc-hs384",
      "name": "A192CBC-HS384",
      "kind": "jose-content-encryption",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Optional",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "AES-192-CBC+HMAC-SHA384"
      ],
      "parameters": {
        "joseImplementationRequirement": "Optional"
      }
    },
    {
      "id": "pb:jose-content-encryption:jose:a192gcm",
      "name": "A192GCM",
      "kind": "jose-content-encryption",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Optional",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "AES-192-GCM"
      ],
      "parameters": {
        "joseImplementationRequirement": "Optional"
      }
    },
    {
      "id": "pb:jose-content-encryption:jose:a256cbc-hs512",
      "name": "A256CBC-HS512",
      "kind": "jose-content-encryption",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Required",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "AES-256-CBC+HMAC-SHA512"
      ],
      "parameters": {
        "joseImplementationRequirement": "Required"
      }
    },
    {
      "id": "pb:jose-content-encryption:jose:a256gcm",
      "name": "A256GCM",
      "kind": "jose-content-encryption",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Recommended",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "AES-256-GCM"
      ],
      "parameters": {
        "joseImplementationRequirement": "Recommended"
      }
    },
    {
      "id": "pb:jose-key-management:jose:a128gcmkw",
      "name": "A128GCMKW",
      "kind": "jose-key-management",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Optional",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "AES-128-GCM key-wrap profile"
      ],
      "parameters": {
        "joseImplementationRequirement": "Optional"
      }
    },
    {
      "id": "pb:jose-key-management:jose:a128kw",
      "name": "A128KW",
      "kind": "jose-key-management",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Recommended",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "AES-128-KW"
      ],
      "parameters": {
        "joseImplementationRequirement": "Recommended"
      }
    },
    {
      "id": "pb:jose-key-management:jose:a192gcmkw",
      "name": "A192GCMKW",
      "kind": "jose-key-management",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Optional",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "AES-192-GCM key-wrap profile"
      ],
      "parameters": {
        "joseImplementationRequirement": "Optional"
      }
    },
    {
      "id": "pb:jose-key-management:jose:a192kw",
      "name": "A192KW",
      "kind": "jose-key-management",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Optional",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "AES-192-KW"
      ],
      "parameters": {
        "joseImplementationRequirement": "Optional"
      }
    },
    {
      "id": "pb:jose-key-management:jose:a256gcmkw",
      "name": "A256GCMKW",
      "kind": "jose-key-management",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Optional",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "AES-256-GCM key-wrap profile"
      ],
      "parameters": {
        "joseImplementationRequirement": "Optional"
      }
    },
    {
      "id": "pb:jose-key-management:jose:a256kw",
      "name": "A256KW",
      "kind": "jose-key-management",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Recommended",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "AES-256-KW"
      ],
      "parameters": {
        "joseImplementationRequirement": "Recommended"
      }
    },
    {
      "id": "pb:jose-key-management:jose:ecdh-es",
      "name": "ECDH-ES",
      "kind": "jose-key-management",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Recommended+",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "ECDH-ES+ConcatKDF"
      ],
      "parameters": {
        "joseImplementationRequirement": "Recommended+"
      }
    },
    {
      "id": "pb:jose-key-management:jose:ecdh-es-a128kw",
      "name": "ECDH-ES+A128KW",
      "kind": "jose-key-management",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Recommended",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "ECDH-ES+ConcatKDF+AES128KW"
      ],
      "parameters": {
        "joseImplementationRequirement": "Recommended"
      }
    },
    {
      "id": "pb:jose-key-management:jose:ecdh-es-a192kw",
      "name": "ECDH-ES+A192KW",
      "kind": "jose-key-management",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Optional",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "ECDH-ES+ConcatKDF+AES192KW"
      ],
      "parameters": {
        "joseImplementationRequirement": "Optional"
      }
    },
    {
      "id": "pb:jose-key-management:jose:ecdh-es-a256kw",
      "name": "ECDH-ES+A256KW",
      "kind": "jose-key-management",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Recommended",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "ECDH-ES+ConcatKDF+AES256KW"
      ],
      "parameters": {
        "joseImplementationRequirement": "Recommended"
      }
    },
    {
      "id": "pb:jose-key-management:jose:rsa-oaep",
      "name": "RSA-OAEP",
      "kind": "jose-key-management",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Recommended+",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "RSAES-OAEP-SHA1"
      ],
      "parameters": {
        "joseImplementationRequirement": "Recommended+"
      }
    },
    {
      "id": "pb:jose-key-management:jose:rsa-oaep-256",
      "name": "RSA-OAEP-256",
      "kind": "jose-key-management",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Optional",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "RSAES-OAEP-SHA256"
      ],
      "parameters": {
        "joseImplementationRequirement": "Optional"
      }
    },
    {
      "id": "pb:jose-key-management:jose:rsa-oaep-384",
      "name": "RSA-OAEP-384",
      "kind": "jose-key-management",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Optional",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "RSAES-OAEP-SHA384"
      ],
      "parameters": {
        "joseImplementationRequirement": "Optional"
      }
    },
    {
      "id": "pb:jose-key-management:jose:rsa1-5",
      "name": "RSA1_5",
      "kind": "jose-key-management",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Recommended-",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "RSAES-PKCS1-v1_5"
      ],
      "parameters": {
        "joseImplementationRequirement": "Recommended-"
      }
    },
    {
      "id": "pb:jose-key-management:jose:dir",
      "name": "dir",
      "kind": "jose-key-management",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Recommended",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "Direct symmetric key"
      ],
      "parameters": {
        "joseImplementationRequirement": "Recommended"
      }
    },
    {
      "id": "pb:jose-null-algorithm:jose:none",
      "name": "none",
      "kind": "jose-null-algorithm",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Optional",
      "quantumClass": "classical",
      "generationPolicy": "deny",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "none"
      ],
      "parameters": {
        "joseImplementationRequirement": "Optional"
      }
    },
    {
      "id": "pb:jose-signature:jose:es256",
      "name": "ES256",
      "kind": "jose-signature",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Recommended+",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "ECDSA-P256-SHA256"
      ],
      "parameters": {
        "joseImplementationRequirement": "Recommended+"
      }
    },
    {
      "id": "pb:jose-signature:jose:es384",
      "name": "ES384",
      "kind": "jose-signature",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Optional",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "ECDSA-P384-SHA384"
      ],
      "parameters": {
        "joseImplementationRequirement": "Optional"
      }
    },
    {
      "id": "pb:jose-signature:jose:es512",
      "name": "ES512",
      "kind": "jose-signature",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Optional",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "ECDSA-P521-SHA512"
      ],
      "parameters": {
        "joseImplementationRequirement": "Optional"
      }
    },
    {
      "id": "pb:jose-signature:jose:ed25519",
      "name": "Ed25519",
      "kind": "jose-signature",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Optional",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "Ed25519"
      ],
      "parameters": {
        "joseImplementationRequirement": "Optional"
      }
    },
    {
      "id": "pb:jose-signature:jose:ed448",
      "name": "Ed448",
      "kind": "jose-signature",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Optional",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "Ed448"
      ],
      "parameters": {
        "joseImplementationRequirement": "Optional"
      }
    },
    {
      "id": "pb:jose-signature:jose:ml-dsa-87",
      "name": "ML-DSA-87",
      "kind": "jose-signature",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Optional",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "ML-DSA-87"
      ],
      "parameters": {
        "joseImplementationRequirement": "Optional"
      }
    },
    {
      "id": "pb:jose-signature:jose:ps256",
      "name": "PS256",
      "kind": "jose-signature",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Optional",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "RSASSA-PSS-SHA256"
      ],
      "parameters": {
        "joseImplementationRequirement": "Optional"
      }
    },
    {
      "id": "pb:jose-signature:jose:ps384",
      "name": "PS384",
      "kind": "jose-signature",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Optional",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "RSASSA-PSS-SHA384"
      ],
      "parameters": {
        "joseImplementationRequirement": "Optional"
      }
    },
    {
      "id": "pb:jose-signature:jose:ps512",
      "name": "PS512",
      "kind": "jose-signature",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Optional",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "RSASSA-PSS-SHA512"
      ],
      "parameters": {
        "joseImplementationRequirement": "Optional"
      }
    },
    {
      "id": "pb:jose-signature:jose:rs1",
      "name": "RS1",
      "kind": "jose-signature",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Prohibited",
      "quantumClass": "classical",
      "generationPolicy": "deny",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "RSASSA-PKCS1-v1_5-SHA1"
      ],
      "parameters": {
        "joseImplementationRequirement": "Prohibited"
      }
    },
    {
      "id": "pb:jose-signature:jose:rs256",
      "name": "RS256",
      "kind": "jose-signature",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Recommended",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "RSASSA-PKCS1-v1_5-SHA256"
      ],
      "parameters": {
        "joseImplementationRequirement": "Recommended"
      }
    },
    {
      "id": "pb:jose-signature:jose:rs384",
      "name": "RS384",
      "kind": "jose-signature",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Optional",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "RSASSA-PKCS1-v1_5-SHA384"
      ],
      "parameters": {
        "joseImplementationRequirement": "Optional"
      }
    },
    {
      "id": "pb:jose-signature:jose:rs512",
      "name": "RS512",
      "kind": "jose-signature",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Optional",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "RSASSA-PKCS1-v1_5-SHA512"
      ],
      "parameters": {
        "joseImplementationRequirement": "Optional"
      }
    },
    {
      "id": "pb:jose-signature-or-mac:jose:hs256",
      "name": "HS256",
      "kind": "jose-signature-or-mac",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Required",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "HMAC-SHA-256"
      ],
      "parameters": {
        "joseImplementationRequirement": "Required"
      }
    },
    {
      "id": "pb:jose-signature-or-mac:jose:hs384",
      "name": "HS384",
      "kind": "jose-signature-or-mac",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Optional",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "HMAC-SHA-384"
      ],
      "parameters": {
        "joseImplementationRequirement": "Optional"
      }
    },
    {
      "id": "pb:jose-signature-or-mac:jose:hs512",
      "name": "HS512",
      "kind": "jose-signature-or-mac",
      "family": "JOSE",
      "specificationStatus": "registered",
      "securityStatus": "inherits-target; registry-requirement=Optional",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA JOSE registry",
      "references": [
        "IANA JOSE registry"
      ],
      "aliases": [
        "HMAC-SHA-512"
      ],
      "parameters": {
        "joseImplementationRequirement": "Optional"
      }
    },
    {
      "id": "pb:kdf:concat-kdf:concat-kdf",
      "name": "Concat KDF",
      "kind": "kdf",
      "family": "Concat KDF",
      "specificationStatus": "standardized-or-protocol-defined",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:kdf:hkdf:hkdf-sha-1",
      "name": "HKDF-SHA-1",
      "kind": "kdf",
      "family": "HKDF",
      "specificationStatus": "standardized-RFC",
      "securityStatus": "legacy-hash",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 5869",
      "references": [
        "RFC 5869"
      ]
    },
    {
      "id": "pb:kdf:hkdf:hkdf-sha-256",
      "name": "HKDF-SHA-256",
      "kind": "kdf",
      "family": "HKDF",
      "specificationStatus": "standardized-RFC",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 5869",
      "references": [
        "RFC 5869"
      ]
    },
    {
      "id": "pb:kdf:hkdf:hkdf-sha-384",
      "name": "HKDF-SHA-384",
      "kind": "kdf",
      "family": "HKDF",
      "specificationStatus": "standardized-RFC",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 5869",
      "references": [
        "RFC 5869"
      ]
    },
    {
      "id": "pb:kdf:hkdf:hkdf-sha-512",
      "name": "HKDF-SHA-512",
      "kind": "kdf",
      "family": "HKDF",
      "specificationStatus": "standardized-RFC",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 5869",
      "references": [
        "RFC 5869"
      ]
    },
    {
      "id": "pb:kdf:ikev2-prf:ikev2-prf",
      "name": "IKEv2 prf+",
      "kind": "kdf",
      "family": "IKEv2 prf+",
      "specificationStatus": "standardized-or-protocol-defined",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:kdf:sp800-108-counter-kdf:sp800-108-counter-kdf",
      "name": "SP800-108 Counter KDF",
      "kind": "kdf",
      "family": "SP800-108 Counter KDF",
      "specificationStatus": "standardized-or-protocol-defined",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:kdf:sp800-108-double-pipeline-kdf:sp800-108-double-pipeline-kdf",
      "name": "SP800-108 Double-Pipeline KDF",
      "kind": "kdf",
      "family": "SP800-108 Double-Pipeline KDF",
      "specificationStatus": "standardized-or-protocol-defined",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:kdf:sp800-108-feedback-kdf:sp800-108-feedback-kdf",
      "name": "SP800-108 Feedback KDF",
      "kind": "kdf",
      "family": "SP800-108 Feedback KDF",
      "specificationStatus": "standardized-or-protocol-defined",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:kdf:ssh-kdf:ssh-kdf",
      "name": "SSH KDF",
      "kind": "kdf",
      "family": "SSH KDF",
      "specificationStatus": "standardized-or-protocol-defined",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:kdf:tls-1-2-prf:tls-1-2-prf",
      "name": "TLS 1.2 PRF",
      "kind": "kdf",
      "family": "TLS 1.2 PRF",
      "specificationStatus": "standardized-or-protocol-defined",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:kdf:tls-1-3-hkdf-expand-label:tls-1-3-hkdf-expand-label",
      "name": "TLS 1.3 HKDF-Expand-Label",
      "kind": "kdf",
      "family": "TLS 1.3 HKDF-Expand-Label",
      "specificationStatus": "standardized-or-protocol-defined",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:kdf:x9-63-kdf:x9-63-kdf",
      "name": "X9.63 KDF",
      "kind": "kdf",
      "family": "X9.63 KDF",
      "specificationStatus": "standardized-or-protocol-defined",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:kem:bike:bike",
      "name": "BIKE",
      "kind": "kem",
      "family": "BIKE",
      "specificationStatus": "NIST-round4-candidate",
      "securityStatus": "candidate",
      "quantumClass": "post_quantum",
      "generationPolicy": "experimental",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:kem:crystals-kyber:crystals-kyber",
      "name": "CRYSTALS-Kyber",
      "kind": "kem",
      "family": "CRYSTALS-Kyber",
      "specificationStatus": "superseded-by-ML-KEM",
      "securityStatus": "pre-standard lineage",
      "quantumClass": "post_quantum",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:kem:classic:classic-mceliece",
      "name": "Classic McEliece",
      "kind": "kem",
      "family": "Classic",
      "specificationStatus": "NIST-round4-candidate",
      "securityStatus": "candidate",
      "quantumClass": "post_quantum",
      "generationPolicy": "experimental",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:kem:frodokem:frodokem",
      "name": "FrodoKEM",
      "kind": "kem",
      "family": "FrodoKEM",
      "specificationStatus": "research/deployed",
      "securityStatus": "conservative-lattice-candidate",
      "quantumClass": "post_quantum",
      "generationPolicy": "experimental",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:kem:hila5:hila5",
      "name": "HILA5",
      "kind": "kem",
      "family": "HILA5",
      "specificationStatus": "historical-PQC",
      "securityStatus": "not-current",
      "quantumClass": "post_quantum",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:kem:hqc:hqc",
      "name": "HQC",
      "kind": "kem",
      "family": "HQC",
      "specificationStatus": "selected-not-final",
      "securityStatus": "candidate-under-standardization",
      "quantumClass": "post_quantum",
      "generationPolicy": "experimental",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "NIST PQC project"
      ],
      "notes": "NIST selected HQC for standardization as an additional KEM."
    },
    {
      "id": "pb:kem:kcl:kcl",
      "name": "KCL",
      "kind": "kem",
      "family": "KCL",
      "specificationStatus": "historical-PQC",
      "securityStatus": "not-current",
      "quantumClass": "post_quantum",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:kem:kindi:kindi",
      "name": "KINDI",
      "kind": "kem",
      "family": "KINDI",
      "specificationStatus": "historical-PQC",
      "securityStatus": "not-current",
      "quantumClass": "post_quantum",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:kem:lac:lac",
      "name": "LAC",
      "kind": "kem",
      "family": "LAC",
      "specificationStatus": "historical-PQC",
      "securityStatus": "candidate-not-current",
      "quantumClass": "post_quantum",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:kem:ledacrypt:ledacrypt",
      "name": "LEDAcrypt",
      "kind": "kem",
      "family": "LEDAcrypt",
      "specificationStatus": "historical-PQC",
      "securityStatus": "candidate-not-current",
      "quantumClass": "post_quantum",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:kem:lima:lima",
      "name": "LIMA",
      "kind": "kem",
      "family": "LIMA",
      "specificationStatus": "historical-PQC",
      "securityStatus": "not-current",
      "quantumClass": "post_quantum",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:kem:lotus:lotus",
      "name": "LOTUS",
      "kind": "kem",
      "family": "LOTUS",
      "specificationStatus": "historical-PQC",
      "securityStatus": "not-current",
      "quantumClass": "post_quantum",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:kem:ml-kem:ml-kem-1024",
      "name": "ML-KEM-1024",
      "kind": "kem",
      "family": "ML-KEM",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-current-standard",
      "quantumClass": "post_quantum",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 203",
      "references": [
        "FIPS 203"
      ],
      "parameters": {
        "nistCategory": 5,
        "publicKeyBytes": 1568,
        "ciphertextBytes": 1568,
        "privateKeyBytesCanonical": 3168
      },
      "notes": "Private-key encodings differ across APIs/formats; parameter records must bind encoding."
    },
    {
      "id": "pb:kem:ml-kem:ml-kem-512",
      "name": "ML-KEM-512",
      "kind": "kem",
      "family": "ML-KEM",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-current-standard",
      "quantumClass": "post_quantum",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 203",
      "references": [
        "FIPS 203"
      ],
      "parameters": {
        "nistCategory": 1,
        "publicKeyBytes": 800,
        "ciphertextBytes": 768,
        "privateKeyBytesCanonical": 1632
      },
      "notes": "Private-key encodings differ across APIs/formats; parameter records must bind encoding."
    },
    {
      "id": "pb:kem:ml-kem:ml-kem-768",
      "name": "ML-KEM-768",
      "kind": "kem",
      "family": "ML-KEM",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-current-standard",
      "quantumClass": "post_quantum",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 203",
      "references": [
        "FIPS 203"
      ],
      "parameters": {
        "nistCategory": 3,
        "publicKeyBytes": 1184,
        "ciphertextBytes": 1088,
        "privateKeyBytesCanonical": 2400
      },
      "notes": "Private-key encodings differ across APIs/formats; parameter records must bind encoding."
    },
    {
      "id": "pb:kem:ntru:ntru",
      "name": "NTRU",
      "kind": "kem",
      "family": "NTRU",
      "specificationStatus": "NIST-candidate",
      "securityStatus": "candidate",
      "quantumClass": "post_quantum",
      "generationPolicy": "experimental",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:kem:ntru:ntru-prime",
      "name": "NTRU Prime",
      "kind": "kem",
      "family": "NTRU",
      "specificationStatus": "research/deployed",
      "securityStatus": "candidate",
      "quantumClass": "post_quantum",
      "generationPolicy": "experimental",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:kem:ntru-hrss:ntru-hrss",
      "name": "NTRU-HRSS",
      "kind": "kem",
      "family": "NTRU-HRSS",
      "specificationStatus": "historical/deployed",
      "securityStatus": "not-current-standard",
      "quantumClass": "post_quantum",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:kem:ntruencrypt:ntruencrypt",
      "name": "NTRUEncrypt",
      "kind": "kem",
      "family": "NTRUEncrypt",
      "specificationStatus": "historical",
      "securityStatus": "legacy-PQC",
      "quantumClass": "post_quantum",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:kem:newhope:newhope",
      "name": "NewHope",
      "kind": "kem",
      "family": "NewHope",
      "specificationStatus": "historical-PQC",
      "securityStatus": "candidate-not-current",
      "quantumClass": "post_quantum",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:kem:rollo:rollo",
      "name": "ROLLO",
      "kind": "kem",
      "family": "ROLLO",
      "specificationStatus": "historical-PQC",
      "securityStatus": "candidate-not-current",
      "quantumClass": "post_quantum",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:kem:rqc:rqc",
      "name": "RQC",
      "kind": "kem",
      "family": "RQC",
      "specificationStatus": "historical-PQC",
      "securityStatus": "candidate-not-current",
      "quantumClass": "post_quantum",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:kem:round5:round5",
      "name": "Round5",
      "kind": "kem",
      "family": "Round5",
      "specificationStatus": "historical-PQC",
      "securityStatus": "candidate-not-current",
      "quantumClass": "post_quantum",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:kem:sike:sike",
      "name": "SIKE",
      "kind": "kem",
      "family": "SIKE",
      "specificationStatus": "broken-PQC",
      "securityStatus": "BROKEN_BY_CLASSICAL_CRYPTANALYSIS",
      "quantumClass": "post_quantum",
      "generationPolicy": "deny",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:kem:saber:saber",
      "name": "Saber",
      "kind": "kem",
      "family": "Saber",
      "specificationStatus": "NIST-finalist",
      "securityStatus": "candidate-not-selected",
      "quantumClass": "post_quantum",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:kem:threebears:threebears",
      "name": "ThreeBears",
      "kind": "kem",
      "family": "ThreeBears",
      "specificationStatus": "historical-PQC",
      "securityStatus": "candidate-not-current",
      "quantumClass": "post_quantum",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:key-agreement:ecdh:ecdh",
      "name": "ECDH",
      "kind": "key-agreement",
      "family": "ECDH",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-with-approved-curves",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:key-agreement:finite-field-diffie-hellman:finite-field-diffie-hellman",
      "name": "Finite-field Diffie-Hellman",
      "kind": "key-agreement",
      "family": "Finite-field Diffie-Hellman",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-with-approved-groups",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:key-agreement:gost:gost-vko-256",
      "name": "GOST VKO 256",
      "kind": "key-agreement",
      "family": "GOST",
      "specificationStatus": "national-standard",
      "securityStatus": "jurisdiction/profile-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:key-agreement:gost:gost-vko-512",
      "name": "GOST VKO 512",
      "kind": "key-agreement",
      "family": "GOST",
      "specificationStatus": "national-standard",
      "securityStatus": "jurisdiction/profile-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:key-agreement:gost-vko:gost-vko",
      "name": "GOST VKO",
      "kind": "key-agreement",
      "family": "GOST VKO",
      "specificationStatus": "national-standard",
      "securityStatus": "accepted-national-profile",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:key-agreement:sm2:sm2-key-exchange",
      "name": "SM2 key exchange",
      "kind": "key-agreement",
      "family": "SM2",
      "specificationStatus": "national-standard",
      "securityStatus": "jurisdiction/profile-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:key-agreement:sm2-key-exchange:sm2-key-exchange",
      "name": "SM2 key exchange",
      "kind": "key-agreement",
      "family": "SM2 key exchange",
      "specificationStatus": "national-standard",
      "securityStatus": "accepted-national-profile",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:key-agreement:x25519:x25519",
      "name": "X25519",
      "kind": "key-agreement",
      "family": "X25519",
      "specificationStatus": "RFC-standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:key-agreement:x448:x448",
      "name": "X448",
      "kind": "key-agreement",
      "family": "X448",
      "specificationStatus": "RFC-standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:key-wrap:aes-kw:aes-128-kw",
      "name": "AES-128-KW",
      "kind": "key-wrap",
      "family": "AES-KW",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-38F / RFC 3394",
      "references": [
        "NIST SP 800-38F",
        "RFC 3394"
      ],
      "parameters": {
        "keyBits": 128
      }
    },
    {
      "id": "pb:key-wrap:aes-kw:aes-192-kw",
      "name": "AES-192-KW",
      "kind": "key-wrap",
      "family": "AES-KW",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-38F / RFC 3394",
      "references": [
        "NIST SP 800-38F",
        "RFC 3394"
      ],
      "parameters": {
        "keyBits": 192
      }
    },
    {
      "id": "pb:key-wrap:aes-kw:aes-256-kw",
      "name": "AES-256-KW",
      "kind": "key-wrap",
      "family": "AES-KW",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-38F / RFC 3394",
      "references": [
        "NIST SP 800-38F",
        "RFC 3394"
      ],
      "parameters": {
        "keyBits": 256
      }
    },
    {
      "id": "pb:key-wrap:aes-kwp:aes-128-kwp",
      "name": "AES-128-KWP",
      "kind": "key-wrap",
      "family": "AES-KWP",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-38F / RFC 5649",
      "references": [
        "NIST SP 800-38F",
        "RFC 5649"
      ],
      "parameters": {
        "keyBits": 128
      }
    },
    {
      "id": "pb:key-wrap:aes-kwp:aes-192-kwp",
      "name": "AES-192-KWP",
      "kind": "key-wrap",
      "family": "AES-KWP",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-38F / RFC 5649",
      "references": [
        "NIST SP 800-38F",
        "RFC 5649"
      ],
      "parameters": {
        "keyBits": 192
      }
    },
    {
      "id": "pb:key-wrap:aes-kwp:aes-256-kwp",
      "name": "AES-256-KWP",
      "kind": "key-wrap",
      "family": "AES-KWP",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-38F / RFC 5649",
      "references": [
        "NIST SP 800-38F",
        "RFC 5649"
      ],
      "parameters": {
        "keyBits": 256
      }
    },
    {
      "id": "pb:legacy-public-key:ansi-x9-31-rsa-signatures:ansi-x9-31-rsa-signatures",
      "name": "ANSI X9.31 RSA signatures",
      "kind": "legacy-public-key",
      "family": "ANSI X9.31 RSA signatures",
      "specificationStatus": "historical",
      "securityStatus": "legacy/withdrawn",
      "quantumClass": "classical",
      "generationPolicy": "deny",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous"
      ]
    },
    {
      "id": "pb:legacy-public-key:chor-rivest-knapsack:chor-rivest-knapsack",
      "name": "Chor-Rivest knapsack",
      "kind": "legacy-public-key",
      "family": "Chor-Rivest knapsack",
      "specificationStatus": "historical",
      "securityStatus": "broken/obsolete",
      "quantumClass": "classical",
      "generationPolicy": "deny",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous"
      ]
    },
    {
      "id": "pb:legacy-public-key:iso-iec-9796-1-signatures:iso-iec-9796-1-signatures",
      "name": "ISO/IEC 9796-1 signatures",
      "kind": "legacy-public-key",
      "family": "ISO/IEC 9796-1 signatures",
      "specificationStatus": "historical",
      "securityStatus": "broken/withdrawn",
      "quantumClass": "classical",
      "generationPolicy": "deny",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous"
      ]
    },
    {
      "id": "pb:legacy-public-key:merkle-hellman-knapsack:merkle-hellman-knapsack",
      "name": "Merkle-Hellman knapsack",
      "kind": "legacy-public-key",
      "family": "Merkle-Hellman knapsack",
      "specificationStatus": "historical",
      "securityStatus": "broken",
      "quantumClass": "classical",
      "generationPolicy": "deny",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous"
      ]
    },
    {
      "id": "pb:legacy-public-key:rabin-encryption-without-modern-encoding:rabin-encryption-without-modern-encoding",
      "name": "Rabin encryption without modern encoding",
      "kind": "legacy-public-key",
      "family": "Rabin encryption without modern encoding",
      "specificationStatus": "historical",
      "securityStatus": "malleable/ambiguous-roots",
      "quantumClass": "classical",
      "generationPolicy": "deny",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous"
      ]
    },
    {
      "id": "pb:legacy-public-key:textbook-elgamal:textbook-elgamal",
      "name": "Textbook ElGamal",
      "kind": "legacy-public-key",
      "family": "Textbook ElGamal",
      "specificationStatus": "historical",
      "securityStatus": "malleable",
      "quantumClass": "classical",
      "generationPolicy": "deny",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous"
      ]
    },
    {
      "id": "pb:legacy-public-key:textbook-rsa:textbook-rsa",
      "name": "Textbook RSA",
      "kind": "legacy-public-key",
      "family": "Textbook RSA",
      "specificationStatus": "historical",
      "securityStatus": "deterministic-and-malleable",
      "quantumClass": "classical",
      "generationPolicy": "deny",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous"
      ]
    },
    {
      "id": "pb:mac:cmac:aes-cmac-128",
      "name": "AES-CMAC-128",
      "kind": "mac",
      "family": "CMAC",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-38B",
      "references": [
        "NIST SP 800-38B"
      ],
      "parameters": {
        "keyBits": 128
      }
    },
    {
      "id": "pb:mac:cmac:aes-cmac-192",
      "name": "AES-CMAC-192",
      "kind": "mac",
      "family": "CMAC",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-38B",
      "references": [
        "NIST SP 800-38B"
      ],
      "parameters": {
        "keyBits": 192
      }
    },
    {
      "id": "pb:mac:cmac:aes-cmac-256",
      "name": "AES-CMAC-256",
      "kind": "mac",
      "family": "CMAC",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-38B",
      "references": [
        "NIST SP 800-38B"
      ],
      "parameters": {
        "keyBits": 256
      }
    },
    {
      "id": "pb:mac:gmac:aes-gmac-128",
      "name": "AES-GMAC-128",
      "kind": "mac",
      "family": "GMAC",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-if-nonce-rules-held",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-38D",
      "references": [
        "NIST SP 800-38D"
      ],
      "parameters": {
        "keyBits": 128
      }
    },
    {
      "id": "pb:mac:gmac:aes-gmac-192",
      "name": "AES-GMAC-192",
      "kind": "mac",
      "family": "GMAC",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-if-nonce-rules-held",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-38D",
      "references": [
        "NIST SP 800-38D"
      ],
      "parameters": {
        "keyBits": 192
      }
    },
    {
      "id": "pb:mac:gmac:aes-gmac-256",
      "name": "AES-GMAC-256",
      "kind": "mac",
      "family": "GMAC",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-if-nonce-rules-held",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-38D",
      "references": [
        "NIST SP 800-38D"
      ],
      "parameters": {
        "keyBits": 256
      }
    },
    {
      "id": "pb:mac:hmac:hmac-sha-1",
      "name": "HMAC-SHA-1",
      "kind": "mac",
      "family": "HMAC",
      "specificationStatus": "standardized",
      "securityStatus": "legacy",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 198-1 / RFC 2104",
      "references": [
        "FIPS 198-1",
        "RFC 2104"
      ]
    },
    {
      "id": "pb:mac:hmac:hmac-sha-224",
      "name": "HMAC-SHA-224",
      "kind": "mac",
      "family": "HMAC",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 198-1 / RFC 2104",
      "references": [
        "FIPS 198-1",
        "RFC 2104"
      ]
    },
    {
      "id": "pb:mac:hmac:hmac-sha-256",
      "name": "HMAC-SHA-256",
      "kind": "mac",
      "family": "HMAC",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 198-1 / RFC 2104",
      "references": [
        "FIPS 198-1",
        "RFC 2104"
      ]
    },
    {
      "id": "pb:mac:hmac:hmac-sha-384",
      "name": "HMAC-SHA-384",
      "kind": "mac",
      "family": "HMAC",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 198-1 / RFC 2104",
      "references": [
        "FIPS 198-1",
        "RFC 2104"
      ]
    },
    {
      "id": "pb:mac:hmac:hmac-sha-512",
      "name": "HMAC-SHA-512",
      "kind": "mac",
      "family": "HMAC",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 198-1 / RFC 2104",
      "references": [
        "FIPS 198-1",
        "RFC 2104"
      ]
    },
    {
      "id": "pb:mac:hmac:hmac-sha3-224",
      "name": "HMAC-SHA3-224",
      "kind": "mac",
      "family": "HMAC",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 198-1 / RFC 2104",
      "references": [
        "FIPS 198-1",
        "RFC 2104"
      ]
    },
    {
      "id": "pb:mac:hmac:hmac-sha3-256",
      "name": "HMAC-SHA3-256",
      "kind": "mac",
      "family": "HMAC",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 198-1 / RFC 2104",
      "references": [
        "FIPS 198-1",
        "RFC 2104"
      ]
    },
    {
      "id": "pb:mac:hmac:hmac-sha3-384",
      "name": "HMAC-SHA3-384",
      "kind": "mac",
      "family": "HMAC",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 198-1 / RFC 2104",
      "references": [
        "FIPS 198-1",
        "RFC 2104"
      ]
    },
    {
      "id": "pb:mac:hmac:hmac-sha3-512",
      "name": "HMAC-SHA3-512",
      "kind": "mac",
      "family": "HMAC",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 198-1 / RFC 2104",
      "references": [
        "FIPS 198-1",
        "RFC 2104"
      ]
    },
    {
      "id": "pb:mac:mac:cbc-mac",
      "name": "CBC-MAC",
      "kind": "mac",
      "family": "MAC",
      "specificationStatus": "RFC-or-published",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:mac:mac:omac1",
      "name": "OMAC1",
      "kind": "mac",
      "family": "MAC",
      "specificationStatus": "RFC-or-published",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:mac:mac:omac2",
      "name": "OMAC2",
      "kind": "mac",
      "family": "MAC",
      "specificationStatus": "RFC-or-published",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:mac:mac:pmac",
      "name": "PMAC",
      "kind": "mac",
      "family": "MAC",
      "specificationStatus": "RFC-or-published",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:mac:mac:pelican-mac",
      "name": "Pelican-MAC",
      "kind": "mac",
      "family": "MAC",
      "specificationStatus": "RFC-or-published",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:mac:mac:poly1305",
      "name": "Poly1305",
      "kind": "mac",
      "family": "MAC",
      "specificationStatus": "RFC-or-published",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:mac:mac:siphash-2-4",
      "name": "SipHash-2-4",
      "kind": "mac",
      "family": "MAC",
      "specificationStatus": "RFC-or-published",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:mac:mac:umac-128",
      "name": "UMAC-128",
      "kind": "mac",
      "family": "MAC",
      "specificationStatus": "RFC-or-published",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:mac:mac:umac-32",
      "name": "UMAC-32",
      "kind": "mac",
      "family": "MAC",
      "specificationStatus": "RFC-or-published",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:mac:mac:umac-64",
      "name": "UMAC-64",
      "kind": "mac",
      "family": "MAC",
      "specificationStatus": "RFC-or-published",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:mac:mac:umac-96",
      "name": "UMAC-96",
      "kind": "mac",
      "family": "MAC",
      "specificationStatus": "RFC-or-published",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:mac:mac:vmac",
      "name": "VMAC",
      "kind": "mac",
      "family": "MAC",
      "specificationStatus": "RFC-or-published",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:mac:mac:xcbc-mac",
      "name": "XCBC-MAC",
      "kind": "mac",
      "family": "MAC",
      "specificationStatus": "RFC-or-published",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:mac:legacy-mac:hmac-md5",
      "name": "HMAC-MD5",
      "kind": "mac",
      "family": "legacy-MAC",
      "specificationStatus": "obsolete",
      "securityStatus": "weak-or-obsolete",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous"
      ]
    },
    {
      "id": "pb:mac:legacy-mac:md5-mac",
      "name": "MD5-MAC",
      "kind": "mac",
      "family": "legacy-MAC",
      "specificationStatus": "obsolete",
      "securityStatus": "weak-or-obsolete",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "tags": [
        "dangerous"
      ]
    },
    {
      "id": "pb:mac-or-prf:kmac:kmac128",
      "name": "KMAC128",
      "kind": "mac-or-prf",
      "family": "KMAC",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-185",
      "references": [
        "NIST SP 800-185"
      ]
    },
    {
      "id": "pb:mac-or-prf:kmac:kmac256",
      "name": "KMAC256",
      "kind": "mac-or-prf",
      "family": "KMAC",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-185",
      "references": [
        "NIST SP 800-185"
      ]
    },
    {
      "id": "pb:mode:aes:aes-xts",
      "name": "AES-XTS",
      "kind": "mode",
      "family": "AES",
      "specificationStatus": "standardized",
      "securityStatus": "storage-confidentiality-only",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "NIST SP 800-38E"
      ]
    },
    {
      "id": "pb:mode:ascon:ascon-aead128",
      "name": "Ascon-AEAD128",
      "kind": "mode",
      "family": "Ascon",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "NIST SP 800-232"
      ]
    },
    {
      "id": "pb:mode:chacha20:chacha20-poly1305",
      "name": "ChaCha20-Poly1305",
      "kind": "mode",
      "family": "ChaCha20",
      "specificationStatus": "standardized-RFC",
      "securityStatus": "accepted-if-nonce-unique",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "RFC 8439"
      ]
    },
    {
      "id": "pb:mode:ff1:ff1",
      "name": "FF1",
      "kind": "mode",
      "family": "FF1",
      "specificationStatus": "standardized",
      "securityStatus": "format-preserving-encryption",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "NIST SP 800-38G"
      ]
    },
    {
      "id": "pb:mode:ff3:ff3-1",
      "name": "FF3-1",
      "kind": "mode",
      "family": "FF3",
      "specificationStatus": "standardized",
      "securityStatus": "format-preserving-encryption",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "NIST SP 800-38G Rev.1"
      ]
    },
    {
      "id": "pb:mode:xchacha20:xchacha20-poly1305",
      "name": "XChaCha20-Poly1305",
      "kind": "mode",
      "family": "XChaCha20",
      "specificationStatus": "deployed",
      "securityStatus": "accepted-if-nonce-unique",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:openpgp-algorithm:openpgp:openpgp-3des",
      "name": "OpenPGP 3DES",
      "kind": "openpgp-algorithm",
      "family": "OpenPGP",
      "specificationStatus": "legacy",
      "securityStatus": "inherits-primitive",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 9580 and registries",
      "references": [
        "RFC 9580"
      ]
    },
    {
      "id": "pb:openpgp-algorithm:openpgp:openpgp-aes-128",
      "name": "OpenPGP AES-128",
      "kind": "openpgp-algorithm",
      "family": "OpenPGP",
      "specificationStatus": "current",
      "securityStatus": "inherits-primitive",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 9580 and registries",
      "references": [
        "RFC 9580"
      ]
    },
    {
      "id": "pb:openpgp-algorithm:openpgp:openpgp-aes-192",
      "name": "OpenPGP AES-192",
      "kind": "openpgp-algorithm",
      "family": "OpenPGP",
      "specificationStatus": "current",
      "securityStatus": "inherits-primitive",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 9580 and registries",
      "references": [
        "RFC 9580"
      ]
    },
    {
      "id": "pb:openpgp-algorithm:openpgp:openpgp-aes-256",
      "name": "OpenPGP AES-256",
      "kind": "openpgp-algorithm",
      "family": "OpenPGP",
      "specificationStatus": "current",
      "securityStatus": "inherits-primitive",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 9580 and registries",
      "references": [
        "RFC 9580"
      ]
    },
    {
      "id": "pb:openpgp-algorithm:openpgp:openpgp-camellia-128",
      "name": "OpenPGP Camellia-128",
      "kind": "openpgp-algorithm",
      "family": "OpenPGP",
      "specificationStatus": "optional",
      "securityStatus": "inherits-primitive",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 9580 and registries",
      "references": [
        "RFC 9580"
      ]
    },
    {
      "id": "pb:openpgp-algorithm:openpgp:openpgp-camellia-192",
      "name": "OpenPGP Camellia-192",
      "kind": "openpgp-algorithm",
      "family": "OpenPGP",
      "specificationStatus": "optional",
      "securityStatus": "inherits-primitive",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 9580 and registries",
      "references": [
        "RFC 9580"
      ]
    },
    {
      "id": "pb:openpgp-algorithm:openpgp:openpgp-camellia-256",
      "name": "OpenPGP Camellia-256",
      "kind": "openpgp-algorithm",
      "family": "OpenPGP",
      "specificationStatus": "optional",
      "securityStatus": "inherits-primitive",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 9580 and registries",
      "references": [
        "RFC 9580"
      ]
    },
    {
      "id": "pb:openpgp-algorithm:openpgp:openpgp-dsa",
      "name": "OpenPGP DSA",
      "kind": "openpgp-algorithm",
      "family": "OpenPGP",
      "specificationStatus": "legacy",
      "securityStatus": "inherits-primitive",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 9580 and registries",
      "references": [
        "RFC 9580"
      ]
    },
    {
      "id": "pb:openpgp-algorithm:openpgp:openpgp-ecdh",
      "name": "OpenPGP ECDH",
      "kind": "openpgp-algorithm",
      "family": "OpenPGP",
      "specificationStatus": "current",
      "securityStatus": "inherits-primitive",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 9580 and registries",
      "references": [
        "RFC 9580"
      ]
    },
    {
      "id": "pb:openpgp-algorithm:openpgp:openpgp-ecdsa",
      "name": "OpenPGP ECDSA",
      "kind": "openpgp-algorithm",
      "family": "OpenPGP",
      "specificationStatus": "current",
      "securityStatus": "inherits-primitive",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 9580 and registries",
      "references": [
        "RFC 9580"
      ]
    },
    {
      "id": "pb:openpgp-algorithm:openpgp:openpgp-ed25519",
      "name": "OpenPGP Ed25519",
      "kind": "openpgp-algorithm",
      "family": "OpenPGP",
      "specificationStatus": "current",
      "securityStatus": "inherits-primitive",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 9580 and registries",
      "references": [
        "RFC 9580"
      ]
    },
    {
      "id": "pb:openpgp-algorithm:openpgp:openpgp-eddsa-legacy-encoding",
      "name": "OpenPGP EdDSA legacy encoding",
      "kind": "openpgp-algorithm",
      "family": "OpenPGP",
      "specificationStatus": "legacy",
      "securityStatus": "inherits-primitive",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 9580 and registries",
      "references": [
        "RFC 9580"
      ]
    },
    {
      "id": "pb:openpgp-algorithm:openpgp:openpgp-elgamal-encrypt-only",
      "name": "OpenPGP ElGamal Encrypt-Only",
      "kind": "openpgp-algorithm",
      "family": "OpenPGP",
      "specificationStatus": "legacy",
      "securityStatus": "inherits-primitive",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 9580 and registries",
      "references": [
        "RFC 9580"
      ]
    },
    {
      "id": "pb:openpgp-algorithm:openpgp:openpgp-rsa",
      "name": "OpenPGP RSA",
      "kind": "openpgp-algorithm",
      "family": "OpenPGP",
      "specificationStatus": "current/legacy",
      "securityStatus": "inherits-primitive",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 9580 and registries",
      "references": [
        "RFC 9580"
      ]
    },
    {
      "id": "pb:openpgp-algorithm:openpgp:openpgp-sha-1",
      "name": "OpenPGP SHA-1",
      "kind": "openpgp-algorithm",
      "family": "OpenPGP",
      "specificationStatus": "legacy",
      "securityStatus": "inherits-primitive",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 9580 and registries",
      "references": [
        "RFC 9580"
      ]
    },
    {
      "id": "pb:openpgp-algorithm:openpgp:openpgp-sha-256",
      "name": "OpenPGP SHA-256",
      "kind": "openpgp-algorithm",
      "family": "OpenPGP",
      "specificationStatus": "current",
      "securityStatus": "inherits-primitive",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 9580 and registries",
      "references": [
        "RFC 9580"
      ]
    },
    {
      "id": "pb:openpgp-algorithm:openpgp:openpgp-sha-384",
      "name": "OpenPGP SHA-384",
      "kind": "openpgp-algorithm",
      "family": "OpenPGP",
      "specificationStatus": "current",
      "securityStatus": "inherits-primitive",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 9580 and registries",
      "references": [
        "RFC 9580"
      ]
    },
    {
      "id": "pb:openpgp-algorithm:openpgp:openpgp-sha-512",
      "name": "OpenPGP SHA-512",
      "kind": "openpgp-algorithm",
      "family": "OpenPGP",
      "specificationStatus": "current",
      "securityStatus": "inherits-primitive",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 9580 and registries",
      "references": [
        "RFC 9580"
      ]
    },
    {
      "id": "pb:openpgp-algorithm:openpgp:openpgp-sha3-256",
      "name": "OpenPGP SHA3-256",
      "kind": "openpgp-algorithm",
      "family": "OpenPGP",
      "specificationStatus": "current/new",
      "securityStatus": "inherits-primitive",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 9580 and registries",
      "references": [
        "RFC 9580"
      ]
    },
    {
      "id": "pb:openpgp-algorithm:openpgp:openpgp-sha3-512",
      "name": "OpenPGP SHA3-512",
      "kind": "openpgp-algorithm",
      "family": "OpenPGP",
      "specificationStatus": "current/new",
      "securityStatus": "inherits-primitive",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 9580 and registries",
      "references": [
        "RFC 9580"
      ]
    },
    {
      "id": "pb:openpgp-algorithm:openpgp:openpgp-x25519",
      "name": "OpenPGP X25519",
      "kind": "openpgp-algorithm",
      "family": "OpenPGP",
      "specificationStatus": "current",
      "securityStatus": "inherits-primitive",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 9580 and registries",
      "references": [
        "RFC 9580"
      ]
    },
    {
      "id": "pb:oprf:oprf:oprf",
      "name": "OPRF",
      "kind": "oprf",
      "family": "OPRF",
      "specificationStatus": "standardized-RFC",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 9497",
      "references": [
        "RFC 9497"
      ]
    },
    {
      "id": "pb:oprf:poprf:poprf",
      "name": "POPRF",
      "kind": "oprf",
      "family": "POPRF",
      "specificationStatus": "standardized-RFC",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 9497",
      "references": [
        "RFC 9497"
      ]
    },
    {
      "id": "pb:oprf:voprf:voprf",
      "name": "VOPRF",
      "kind": "oprf",
      "family": "VOPRF",
      "specificationStatus": "standardized-RFC",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 9497",
      "references": [
        "RFC 9497"
      ]
    },
    {
      "id": "pb:pake:cpace:cpace",
      "name": "CPace",
      "kind": "pake",
      "family": "CPace",
      "specificationStatus": "published/standardized-profile",
      "securityStatus": "accepted-or-context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:pake:j-pake:j-pake",
      "name": "J-PAKE",
      "kind": "pake",
      "family": "J-PAKE",
      "specificationStatus": "standardized/deployed",
      "securityStatus": "accepted-or-context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:pake:opaque:opaque",
      "name": "OPAQUE",
      "kind": "pake",
      "family": "OPAQUE",
      "specificationStatus": "standardized-RFC",
      "securityStatus": "accepted-or-context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "RFC 9807"
      ]
    },
    {
      "id": "pb:pake:spake2:spake2",
      "name": "SPAKE2",
      "kind": "pake",
      "family": "SPAKE2",
      "specificationStatus": "standardized-RFC",
      "securityStatus": "accepted-or-context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "RFC 9382"
      ]
    },
    {
      "id": "pb:pake:spake2:spake2:451",
      "name": "SPAKE2+",
      "kind": "pake",
      "family": "SPAKE2+",
      "specificationStatus": "standardized/deployed",
      "securityStatus": "accepted-or-context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:pake:speke:speke",
      "name": "SPEKE",
      "kind": "pake",
      "family": "SPEKE",
      "specificationStatus": "published/deployed",
      "securityStatus": "accepted-or-context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:pake:srp-6a:srp-6a",
      "name": "SRP-6a",
      "kind": "pake",
      "family": "SRP-6a",
      "specificationStatus": "RFC/deployed",
      "securityStatus": "accepted-or-context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "RFC 5054"
      ]
    },
    {
      "id": "pb:password-kdf:argon2d:argon2d",
      "name": "Argon2d",
      "kind": "password-kdf",
      "family": "Argon2d",
      "specificationStatus": "RFC-standardized",
      "securityStatus": "accepted-or-context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "RFC 9106"
      ]
    },
    {
      "id": "pb:password-kdf:argon2i:argon2i",
      "name": "Argon2i",
      "kind": "password-kdf",
      "family": "Argon2i",
      "specificationStatus": "RFC-standardized",
      "securityStatus": "accepted-or-context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "RFC 9106"
      ]
    },
    {
      "id": "pb:password-kdf:argon2id:argon2id",
      "name": "Argon2id",
      "kind": "password-kdf",
      "family": "Argon2id",
      "specificationStatus": "RFC-standardized",
      "securityStatus": "accepted-or-context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "RFC 9106"
      ]
    },
    {
      "id": "pb:password-kdf:balloon-hashing:balloon-hashing",
      "name": "Balloon Hashing",
      "kind": "password-kdf",
      "family": "Balloon Hashing",
      "specificationStatus": "published",
      "securityStatus": "accepted-or-context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "experimental",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:password-kdf:catena:catena",
      "name": "Catena",
      "kind": "password-kdf",
      "family": "Catena",
      "specificationStatus": "published",
      "securityStatus": "accepted-or-context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "research",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:password-kdf:lyra2:lyra2",
      "name": "Lyra2",
      "kind": "password-kdf",
      "family": "Lyra2",
      "specificationStatus": "published",
      "securityStatus": "accepted-or-context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "research",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:password-kdf:pbkdf2:pbkdf2-hmac-sha1",
      "name": "PBKDF2-HMAC-SHA1",
      "kind": "password-kdf",
      "family": "PBKDF2",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-with-sufficient-cost; not-memory-hard",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "PKCS #5 / NIST SP 800-132",
      "references": [
        "NIST SP 800-132"
      ]
    },
    {
      "id": "pb:password-kdf:pbkdf2:pbkdf2-hmac-sha256",
      "name": "PBKDF2-HMAC-SHA256",
      "kind": "password-kdf",
      "family": "PBKDF2",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-with-sufficient-cost; not-memory-hard",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "PKCS #5 / NIST SP 800-132",
      "references": [
        "NIST SP 800-132"
      ]
    },
    {
      "id": "pb:password-kdf:pbkdf2:pbkdf2-hmac-sha384",
      "name": "PBKDF2-HMAC-SHA384",
      "kind": "password-kdf",
      "family": "PBKDF2",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-with-sufficient-cost; not-memory-hard",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "PKCS #5 / NIST SP 800-132",
      "references": [
        "NIST SP 800-132"
      ]
    },
    {
      "id": "pb:password-kdf:pbkdf2:pbkdf2-hmac-sha512",
      "name": "PBKDF2-HMAC-SHA512",
      "kind": "password-kdf",
      "family": "PBKDF2",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-with-sufficient-cost; not-memory-hard",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "PKCS #5 / NIST SP 800-132",
      "references": [
        "NIST SP 800-132"
      ]
    },
    {
      "id": "pb:password-kdf:bcrypt:bcrypt",
      "name": "bcrypt",
      "kind": "password-kdf",
      "family": "bcrypt",
      "specificationStatus": "published",
      "securityStatus": "accepted-or-context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:password-kdf:scrypt:scrypt",
      "name": "scrypt",
      "kind": "password-kdf",
      "family": "scrypt",
      "specificationStatus": "RFC-standardized",
      "securityStatus": "accepted-or-context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "RFC 7914"
      ]
    },
    {
      "id": "pb:password-kdf:yescrypt:yescrypt",
      "name": "yescrypt",
      "kind": "password-kdf",
      "family": "yescrypt",
      "specificationStatus": "published",
      "securityStatus": "accepted-or-context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:polynomial-commitment:ipa-polynomial-commitment:ipa-polynomial-commitment",
      "name": "IPA polynomial commitment",
      "kind": "polynomial-commitment",
      "family": "IPA polynomial commitment",
      "specificationStatus": "deployed",
      "securityStatus": "assumption-and-instantiation-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:polynomial-commitment:kzg-polynomial-commitment:kzg-polynomial-commitment",
      "name": "KZG polynomial commitment",
      "kind": "polynomial-commitment",
      "family": "KZG polynomial commitment",
      "specificationStatus": "deployed",
      "securityStatus": "assumption-and-instantiation-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:public-key-encryption:sm2:sm2-encryption",
      "name": "SM2 encryption",
      "kind": "public-key-encryption",
      "family": "SM2",
      "specificationStatus": "national-standard",
      "securityStatus": "jurisdiction/profile-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:public-key-primitive:rsa:rsadp",
      "name": "RSADP",
      "kind": "public-key-primitive",
      "family": "RSA",
      "specificationStatus": "standardized",
      "securityStatus": "primitive-only; padding required",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "RFC 8017"
      ]
    },
    {
      "id": "pb:public-key-primitive:rsa:rsaep",
      "name": "RSAEP",
      "kind": "public-key-primitive",
      "family": "RSA",
      "specificationStatus": "standardized",
      "securityStatus": "primitive-only; padding required",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "RFC 8017"
      ]
    },
    {
      "id": "pb:public-key-primitive:rsa:rsaes-oaep",
      "name": "RSAES-OAEP",
      "kind": "public-key-primitive",
      "family": "RSA",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-with-modern-parameters",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "RFC 8017"
      ]
    },
    {
      "id": "pb:public-key-primitive:rsa:rsaes-pkcs1-v1-5",
      "name": "RSAES-PKCS1-v1_5",
      "kind": "public-key-primitive",
      "family": "RSA",
      "specificationStatus": "legacy",
      "securityStatus": "padding-oracle-risk",
      "quantumClass": "classical",
      "generationPolicy": "decrypt-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "RFC 8017"
      ]
    },
    {
      "id": "pb:public-key-primitive:rsa:rsassa-pkcs1-v1-5",
      "name": "RSASSA-PKCS1-v1_5",
      "kind": "public-key-primitive",
      "family": "RSA",
      "specificationStatus": "standardized-legacy",
      "securityStatus": "legacy",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "RFC 8017"
      ]
    },
    {
      "id": "pb:public-key-primitive:rsa:rsassa-pss",
      "name": "RSASSA-PSS",
      "kind": "public-key-primitive",
      "family": "RSA",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "RFC 8017"
      ]
    },
    {
      "id": "pb:public-key-primitive:rsa:raw-rsa",
      "name": "Raw RSA",
      "kind": "public-key-primitive",
      "family": "RSA",
      "specificationStatus": "dangerous",
      "securityStatus": "insecure-as-standalone",
      "quantumClass": "classical",
      "generationPolicy": "deny",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "RFC 8017"
      ]
    },
    {
      "id": "pb:quantum-cryptanalysis:brassard-h-yer-tapp-collision-algorithm:brassard-h-yer-tapp-collision-algorithm",
      "name": "Brassard-Høyer-Tapp collision algorithm",
      "kind": "quantum-cryptanalysis",
      "family": "Brassard-Høyer-Tapp collision algorithm",
      "specificationStatus": "known-quantum-algorithm",
      "securityStatus": "quantum-collision-search",
      "quantumClass": "quantum_attack",
      "generationPolicy": "analysis-only",
      "implementationStatus": "SIMULATION_OR_ANALYSIS_ONLY"
    },
    {
      "id": "pb:quantum-cryptanalysis:grover-s-algorithm:grover-s-algorithm",
      "name": "Grover's algorithm",
      "kind": "quantum-cryptanalysis",
      "family": "Grover's algorithm",
      "specificationStatus": "known-quantum-algorithm",
      "securityStatus": "quadratic-generic-search-speedup; reduces brute-force security exponent",
      "quantumClass": "quantum_attack",
      "generationPolicy": "analysis-only",
      "implementationStatus": "SIMULATION_OR_ANALYSIS_ONLY"
    },
    {
      "id": "pb:quantum-cryptanalysis:shor-s-algorithm:shor-s-algorithm",
      "name": "Shor's algorithm",
      "kind": "quantum-cryptanalysis",
      "family": "Shor's algorithm",
      "specificationStatus": "known-quantum-algorithm",
      "securityStatus": "breaks-integer-factorization-and-discrete-log-public-key-families",
      "quantumClass": "quantum_attack",
      "generationPolicy": "analysis-only",
      "implementationStatus": "SIMULATION_OR_ANALYSIS_ONLY"
    },
    {
      "id": "pb:quantum-cryptanalysis:simon-s-algorithm:simon-s-algorithm",
      "name": "Simon's algorithm",
      "kind": "quantum-cryptanalysis",
      "family": "Simon's algorithm",
      "specificationStatus": "known-quantum-algorithm",
      "securityStatus": "breaks-certain-hidden-xor-structure/construction-models",
      "quantumClass": "quantum_attack",
      "generationPolicy": "analysis-only",
      "implementationStatus": "SIMULATION_OR_ANALYSIS_ONLY"
    },
    {
      "id": "pb:quantum-cryptography:b92:b92",
      "name": "B92",
      "kind": "quantum-cryptography",
      "family": "B92",
      "specificationStatus": "QKD",
      "securityStatus": "physics-and-implementation-dependent",
      "quantumClass": "quantum_native",
      "generationPolicy": "metadata-only",
      "implementationStatus": "NONCLASSICAL_HARDWARE_REQUIRED"
    },
    {
      "id": "pb:quantum-cryptography:bb84:bb84",
      "name": "BB84",
      "kind": "quantum-cryptography",
      "family": "BB84",
      "specificationStatus": "foundational-QKD",
      "securityStatus": "physics-and-implementation-dependent",
      "quantumClass": "quantum_native",
      "generationPolicy": "metadata-only",
      "implementationStatus": "NONCLASSICAL_HARDWARE_REQUIRED"
    },
    {
      "id": "pb:quantum-cryptography:bbm92:bbm92",
      "name": "BBM92",
      "kind": "quantum-cryptography",
      "family": "BBM92",
      "specificationStatus": "entanglement-based-QKD",
      "securityStatus": "physics-and-implementation-dependent",
      "quantumClass": "quantum_native",
      "generationPolicy": "metadata-only",
      "implementationStatus": "NONCLASSICAL_HARDWARE_REQUIRED"
    },
    {
      "id": "pb:quantum-cryptography:cow-qkd:cow-qkd",
      "name": "COW-QKD",
      "kind": "quantum-cryptography",
      "family": "COW-QKD",
      "specificationStatus": "QKD",
      "securityStatus": "physics-and-implementation-dependent",
      "quantumClass": "quantum_native",
      "generationPolicy": "metadata-only",
      "implementationStatus": "NONCLASSICAL_HARDWARE_REQUIRED"
    },
    {
      "id": "pb:quantum-cryptography:continuous-variable-qkd:continuous-variable-qkd",
      "name": "Continuous-Variable QKD",
      "kind": "quantum-cryptography",
      "family": "Continuous-Variable QKD",
      "specificationStatus": "QKD-family",
      "securityStatus": "physics-and-implementation-dependent",
      "quantumClass": "quantum_native",
      "generationPolicy": "metadata-only",
      "implementationStatus": "NONCLASSICAL_HARDWARE_REQUIRED"
    },
    {
      "id": "pb:quantum-cryptography:dps-qkd:dps-qkd",
      "name": "DPS-QKD",
      "kind": "quantum-cryptography",
      "family": "DPS-QKD",
      "specificationStatus": "QKD",
      "securityStatus": "physics-and-implementation-dependent",
      "quantumClass": "quantum_native",
      "generationPolicy": "metadata-only",
      "implementationStatus": "NONCLASSICAL_HARDWARE_REQUIRED"
    },
    {
      "id": "pb:quantum-cryptography:decoy-state-bb84:decoy-state-bb84",
      "name": "Decoy-state BB84",
      "kind": "quantum-cryptography",
      "family": "Decoy-state BB84",
      "specificationStatus": "QKD",
      "securityStatus": "physics-and-implementation-dependent",
      "quantumClass": "quantum_native",
      "generationPolicy": "metadata-only",
      "implementationStatus": "NONCLASSICAL_HARDWARE_REQUIRED"
    },
    {
      "id": "pb:quantum-cryptography:device-independent-qkd:device-independent-qkd",
      "name": "Device-Independent QKD",
      "kind": "quantum-cryptography",
      "family": "Device-Independent QKD",
      "specificationStatus": "QKD-family",
      "securityStatus": "physics-and-implementation-dependent",
      "quantumClass": "quantum_native",
      "generationPolicy": "metadata-only",
      "implementationStatus": "NONCLASSICAL_HARDWARE_REQUIRED"
    },
    {
      "id": "pb:quantum-cryptography:e91:e91",
      "name": "E91",
      "kind": "quantum-cryptography",
      "family": "E91",
      "specificationStatus": "entanglement-based-QKD",
      "securityStatus": "physics-and-implementation-dependent",
      "quantumClass": "quantum_native",
      "generationPolicy": "metadata-only",
      "implementationStatus": "NONCLASSICAL_HARDWARE_REQUIRED"
    },
    {
      "id": "pb:quantum-cryptography:mdi-qkd:mdi-qkd",
      "name": "MDI-QKD",
      "kind": "quantum-cryptography",
      "family": "MDI-QKD",
      "specificationStatus": "measurement-device-independent-QKD",
      "securityStatus": "physics-and-implementation-dependent",
      "quantumClass": "quantum_native",
      "generationPolicy": "metadata-only",
      "implementationStatus": "NONCLASSICAL_HARDWARE_REQUIRED"
    },
    {
      "id": "pb:quantum-cryptography:quantum-digital-signatures:quantum-digital-signatures",
      "name": "Quantum Digital Signatures",
      "kind": "quantum-cryptography",
      "family": "Quantum Digital Signatures",
      "specificationStatus": "quantum-signature-family",
      "securityStatus": "physics-and-implementation-dependent",
      "quantumClass": "quantum_native",
      "generationPolicy": "metadata-only",
      "implementationStatus": "NONCLASSICAL_HARDWARE_REQUIRED"
    },
    {
      "id": "pb:quantum-cryptography:quantum-one-time-pad:quantum-one-time-pad",
      "name": "Quantum One-Time Pad",
      "kind": "quantum-cryptography",
      "family": "Quantum One-Time Pad",
      "specificationStatus": "quantum-encryption",
      "securityStatus": "physics-and-implementation-dependent",
      "quantumClass": "quantum_native",
      "generationPolicy": "metadata-only",
      "implementationStatus": "NONCLASSICAL_HARDWARE_REQUIRED"
    },
    {
      "id": "pb:quantum-cryptography:quantum-random-number-generation:quantum-random-number-generation",
      "name": "Quantum Random Number Generation",
      "kind": "quantum-cryptography",
      "family": "Quantum Random Number Generation",
      "specificationStatus": "quantum-rng-family",
      "securityStatus": "physics-and-implementation-dependent",
      "quantumClass": "quantum_native",
      "generationPolicy": "metadata-only",
      "implementationStatus": "NONCLASSICAL_HARDWARE_REQUIRED"
    },
    {
      "id": "pb:quantum-cryptography:sarg04:sarg04",
      "name": "SARG04",
      "kind": "quantum-cryptography",
      "family": "SARG04",
      "specificationStatus": "QKD",
      "securityStatus": "physics-and-implementation-dependent",
      "quantumClass": "quantum_native",
      "generationPolicy": "metadata-only",
      "implementationStatus": "NONCLASSICAL_HARDWARE_REQUIRED"
    },
    {
      "id": "pb:quantum-cryptography:six-state-qkd:six-state-qkd",
      "name": "Six-state QKD",
      "kind": "quantum-cryptography",
      "family": "Six-state QKD",
      "specificationStatus": "QKD",
      "securityStatus": "physics-and-implementation-dependent",
      "quantumClass": "quantum_native",
      "generationPolicy": "metadata-only",
      "implementationStatus": "NONCLASSICAL_HARDWARE_REQUIRED"
    },
    {
      "id": "pb:quantum-cryptography:twin-field-qkd:twin-field-qkd",
      "name": "Twin-Field QKD",
      "kind": "quantum-cryptography",
      "family": "Twin-Field QKD",
      "specificationStatus": "QKD",
      "securityStatus": "physics-and-implementation-dependent",
      "quantumClass": "quantum_native",
      "generationPolicy": "metadata-only",
      "implementationStatus": "NONCLASSICAL_HARDWARE_REQUIRED"
    },
    {
      "id": "pb:signature:bip340:bip340-schnorr-secp256k1",
      "name": "BIP340 Schnorr/secp256k1",
      "kind": "signature",
      "family": "BIP340",
      "specificationStatus": "deployed-standard",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:signature:bls:bls-signature",
      "name": "BLS signature",
      "kind": "signature",
      "family": "BLS",
      "specificationStatus": "IETF/CFRG-profiled",
      "securityStatus": "pairing-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:signature:crystals:crystals-dilithium",
      "name": "CRYSTALS-Dilithium",
      "kind": "signature",
      "family": "CRYSTALS",
      "specificationStatus": "superseded-by-ML-DSA",
      "securityStatus": "pre-standard lineage",
      "quantumClass": "post_quantum",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:signature:dsa:dsa",
      "name": "DSA",
      "kind": "signature",
      "family": "DSA",
      "specificationStatus": "FIPS legacy",
      "securityStatus": "legacy/verification-only-under-current-NIST",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:signature:dilithium:dilithium-aes",
      "name": "Dilithium-AES",
      "kind": "signature",
      "family": "Dilithium",
      "specificationStatus": "pre-standard-variant",
      "securityStatus": "not-FIPS-204",
      "quantumClass": "post_quantum",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:signature:ecdsa:ecdsa",
      "name": "ECDSA",
      "kind": "signature",
      "family": "ECDSA",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-with-correct-nonce",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:signature:ed25519:ed25519",
      "name": "Ed25519",
      "kind": "signature",
      "family": "Ed25519",
      "specificationStatus": "RFC/FIPS-recognized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:signature:ed448:ed448",
      "name": "Ed448",
      "kind": "signature",
      "family": "Ed448",
      "specificationStatus": "RFC/FIPS-recognized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:signature:eddsa:eddsa",
      "name": "EdDSA",
      "kind": "signature",
      "family": "EdDSA",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:signature:elgamal:elgamal-encryption",
      "name": "ElGamal encryption",
      "kind": "signature",
      "family": "ElGamal",
      "specificationStatus": "published",
      "securityStatus": "malleable-without-transform",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:signature:elgamal:elgamal-signature",
      "name": "ElGamal signature",
      "kind": "signature",
      "family": "ElGamal",
      "specificationStatus": "published",
      "securityStatus": "legacy",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:signature:fn-dsa:fn-dsa-falcon",
      "name": "FN-DSA/FALCON",
      "kind": "signature",
      "family": "FN-DSA",
      "specificationStatus": "selected-not-final",
      "securityStatus": "candidate-under-standardization",
      "quantumClass": "post_quantum",
      "generationPolicy": "experimental",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "NIST PQC project"
      ],
      "notes": "NIST-selected signature family intended for FIPS 206; final standard must be ingested before ACTIVE."
    },
    {
      "id": "pb:signature:falcon:falcon-1024",
      "name": "Falcon-1024",
      "kind": "signature",
      "family": "Falcon",
      "specificationStatus": "selected/pre-FIPS206",
      "securityStatus": "candidate-under-standardization",
      "quantumClass": "post_quantum",
      "generationPolicy": "experimental",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:signature:falcon:falcon-512",
      "name": "Falcon-512",
      "kind": "signature",
      "family": "Falcon",
      "specificationStatus": "selected/pre-FIPS206",
      "securityStatus": "candidate-under-standardization",
      "quantumClass": "post_quantum",
      "generationPolicy": "experimental",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:signature:gost:gost-r-34-10-2001",
      "name": "GOST R 34.10-2001",
      "kind": "signature",
      "family": "GOST",
      "specificationStatus": "legacy-national-standard",
      "securityStatus": "jurisdiction/profile-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:signature:gost:gost-r-34-10-2012-signature",
      "name": "GOST R 34.10-2012 signature",
      "kind": "signature",
      "family": "GOST",
      "specificationStatus": "national-standard",
      "securityStatus": "accepted-national-profile",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:signature:gost:gost-r-34-10-2012-256",
      "name": "GOST R 34.10-2012-256",
      "kind": "signature",
      "family": "GOST",
      "specificationStatus": "national-standard",
      "securityStatus": "jurisdiction/profile-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:signature:gost:gost-r-34-10-2012-512",
      "name": "GOST R 34.10-2012-512",
      "kind": "signature",
      "family": "GOST",
      "specificationStatus": "national-standard",
      "securityStatus": "jurisdiction/profile-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:signature:gemss:gemss",
      "name": "GeMSS",
      "kind": "signature",
      "family": "GeMSS",
      "specificationStatus": "NIST-candidate",
      "securityStatus": "candidate-not-selected",
      "quantumClass": "post_quantum",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:signature:gravity:gravity-sphincs",
      "name": "Gravity-SPHINCS",
      "kind": "signature",
      "family": "Gravity",
      "specificationStatus": "historical-hash-signature",
      "securityStatus": "superseded",
      "quantumClass": "post_quantum",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:signature:luov:luov",
      "name": "LUOV",
      "kind": "signature",
      "family": "LUOV",
      "specificationStatus": "historical-PQC",
      "securityStatus": "candidate-not-current",
      "quantumClass": "post_quantum",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:signature:ml-dsa:ml-dsa-44",
      "name": "ML-DSA-44",
      "kind": "signature",
      "family": "ML-DSA",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-current-standard",
      "quantumClass": "post_quantum",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 204",
      "references": [
        "FIPS 204"
      ],
      "parameters": {
        "nistCategory": 2
      }
    },
    {
      "id": "pb:signature:ml-dsa:ml-dsa-65",
      "name": "ML-DSA-65",
      "kind": "signature",
      "family": "ML-DSA",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-current-standard",
      "quantumClass": "post_quantum",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 204",
      "references": [
        "FIPS 204"
      ],
      "parameters": {
        "nistCategory": 3
      }
    },
    {
      "id": "pb:signature:ml-dsa:ml-dsa-87",
      "name": "ML-DSA-87",
      "kind": "signature",
      "family": "ML-DSA",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-current-standard",
      "quantumClass": "post_quantum",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 204",
      "references": [
        "FIPS 204"
      ],
      "parameters": {
        "nistCategory": 5
      }
    },
    {
      "id": "pb:signature:mqdss:mqdss",
      "name": "MQDSS",
      "kind": "signature",
      "family": "MQDSS",
      "specificationStatus": "historical-PQC",
      "securityStatus": "candidate-not-current",
      "quantumClass": "post_quantum",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:signature:picnic:picnic",
      "name": "Picnic",
      "kind": "signature",
      "family": "Picnic",
      "specificationStatus": "NIST-alternate/history",
      "securityStatus": "candidate-not-selected",
      "quantumClass": "post_quantum",
      "generationPolicy": "experimental",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:signature:rainbow:rainbow",
      "name": "Rainbow",
      "kind": "signature",
      "family": "Rainbow",
      "specificationStatus": "broken-PQC",
      "securityStatus": "BROKEN_BY_CLASSICAL_CRYPTANALYSIS",
      "quantumClass": "post_quantum",
      "generationPolicy": "deny",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:signature:slh-dsa:slh-dsa-sha2-128f",
      "name": "SLH-DSA-SHA2-128f",
      "kind": "signature",
      "family": "SLH-DSA",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-current-standard",
      "quantumClass": "post_quantum",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 205",
      "references": [
        "FIPS 205"
      ],
      "parameters": {
        "nistCategory": 1,
        "optimization": "fast-signing"
      }
    },
    {
      "id": "pb:signature:slh-dsa:slh-dsa-sha2-128s",
      "name": "SLH-DSA-SHA2-128s",
      "kind": "signature",
      "family": "SLH-DSA",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-current-standard",
      "quantumClass": "post_quantum",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 205",
      "references": [
        "FIPS 205"
      ],
      "parameters": {
        "nistCategory": 1,
        "optimization": "small-signature"
      }
    },
    {
      "id": "pb:signature:slh-dsa:slh-dsa-sha2-192f",
      "name": "SLH-DSA-SHA2-192f",
      "kind": "signature",
      "family": "SLH-DSA",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-current-standard",
      "quantumClass": "post_quantum",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 205",
      "references": [
        "FIPS 205"
      ],
      "parameters": {
        "nistCategory": 3,
        "optimization": "fast-signing"
      }
    },
    {
      "id": "pb:signature:slh-dsa:slh-dsa-sha2-192s",
      "name": "SLH-DSA-SHA2-192s",
      "kind": "signature",
      "family": "SLH-DSA",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-current-standard",
      "quantumClass": "post_quantum",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 205",
      "references": [
        "FIPS 205"
      ],
      "parameters": {
        "nistCategory": 3,
        "optimization": "small-signature"
      }
    },
    {
      "id": "pb:signature:slh-dsa:slh-dsa-sha2-256f",
      "name": "SLH-DSA-SHA2-256f",
      "kind": "signature",
      "family": "SLH-DSA",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-current-standard",
      "quantumClass": "post_quantum",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 205",
      "references": [
        "FIPS 205"
      ],
      "parameters": {
        "nistCategory": 5,
        "optimization": "fast-signing"
      }
    },
    {
      "id": "pb:signature:slh-dsa:slh-dsa-sha2-256s",
      "name": "SLH-DSA-SHA2-256s",
      "kind": "signature",
      "family": "SLH-DSA",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-current-standard",
      "quantumClass": "post_quantum",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 205",
      "references": [
        "FIPS 205"
      ],
      "parameters": {
        "nistCategory": 5,
        "optimization": "small-signature"
      }
    },
    {
      "id": "pb:signature:slh-dsa:slh-dsa-shake-128f",
      "name": "SLH-DSA-SHAKE-128f",
      "kind": "signature",
      "family": "SLH-DSA",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-current-standard",
      "quantumClass": "post_quantum",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 205",
      "references": [
        "FIPS 205"
      ],
      "parameters": {
        "nistCategory": 1,
        "optimization": "fast-signing"
      }
    },
    {
      "id": "pb:signature:slh-dsa:slh-dsa-shake-128s",
      "name": "SLH-DSA-SHAKE-128s",
      "kind": "signature",
      "family": "SLH-DSA",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-current-standard",
      "quantumClass": "post_quantum",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 205",
      "references": [
        "FIPS 205"
      ],
      "parameters": {
        "nistCategory": 1,
        "optimization": "small-signature"
      }
    },
    {
      "id": "pb:signature:slh-dsa:slh-dsa-shake-192f",
      "name": "SLH-DSA-SHAKE-192f",
      "kind": "signature",
      "family": "SLH-DSA",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-current-standard",
      "quantumClass": "post_quantum",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 205",
      "references": [
        "FIPS 205"
      ],
      "parameters": {
        "nistCategory": 3,
        "optimization": "fast-signing"
      }
    },
    {
      "id": "pb:signature:slh-dsa:slh-dsa-shake-192s",
      "name": "SLH-DSA-SHAKE-192s",
      "kind": "signature",
      "family": "SLH-DSA",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-current-standard",
      "quantumClass": "post_quantum",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 205",
      "references": [
        "FIPS 205"
      ],
      "parameters": {
        "nistCategory": 3,
        "optimization": "small-signature"
      }
    },
    {
      "id": "pb:signature:slh-dsa:slh-dsa-shake-256f",
      "name": "SLH-DSA-SHAKE-256f",
      "kind": "signature",
      "family": "SLH-DSA",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-current-standard",
      "quantumClass": "post_quantum",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 205",
      "references": [
        "FIPS 205"
      ],
      "parameters": {
        "nistCategory": 5,
        "optimization": "fast-signing"
      }
    },
    {
      "id": "pb:signature:slh-dsa:slh-dsa-shake-256s",
      "name": "SLH-DSA-SHAKE-256s",
      "kind": "signature",
      "family": "SLH-DSA",
      "specificationStatus": "standardized",
      "securityStatus": "accepted-current-standard",
      "quantumClass": "post_quantum",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 205",
      "references": [
        "FIPS 205"
      ],
      "parameters": {
        "nistCategory": 5,
        "optimization": "small-signature"
      }
    },
    {
      "id": "pb:signature:sm2:sm2-signature",
      "name": "SM2 signature",
      "kind": "signature",
      "family": "SM2",
      "specificationStatus": "national-standard",
      "securityStatus": "accepted-national-profile",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:signature:sm2:sm2-signature:638",
      "name": "SM2 signature",
      "kind": "signature",
      "family": "SM2",
      "specificationStatus": "national-standard",
      "securityStatus": "jurisdiction/profile-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:signature:sphincs:sphincs-256",
      "name": "SPHINCS-256",
      "kind": "signature",
      "family": "SPHINCS",
      "specificationStatus": "historical-hash-signature",
      "securityStatus": "superseded",
      "quantumClass": "post_quantum",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:signature:sphincs:sphincs",
      "name": "SPHINCS+",
      "kind": "signature",
      "family": "SPHINCS+",
      "specificationStatus": "superseded-by-SLH-DSA",
      "securityStatus": "pre-standard lineage",
      "quantumClass": "post_quantum",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:signature:schnorr:schnorr-signature",
      "name": "Schnorr signature",
      "kind": "signature",
      "family": "Schnorr",
      "specificationStatus": "published",
      "securityStatus": "accepted-when-instantiated-correctly",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:signature:qtesla:qtesla",
      "name": "qTESLA",
      "kind": "signature",
      "family": "qTESLA",
      "specificationStatus": "historical-PQC",
      "securityStatus": "candidate-not-current",
      "quantumClass": "post_quantum",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:stateful-hash-signature:hss:hss",
      "name": "HSS",
      "kind": "stateful-hash-signature",
      "family": "HSS",
      "specificationStatus": "standardized",
      "securityStatus": "post-quantum-with-strict-state-management",
      "quantumClass": "post_quantum",
      "generationPolicy": "restricted",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-208 / RFC family",
      "tags": [
        "stateful",
        "operational-hazard"
      ]
    },
    {
      "id": "pb:stateful-hash-signature:lms:lms",
      "name": "LMS",
      "kind": "stateful-hash-signature",
      "family": "LMS",
      "specificationStatus": "standardized",
      "securityStatus": "post-quantum-with-strict-state-management",
      "quantumClass": "post_quantum",
      "generationPolicy": "restricted",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-208 / RFC family",
      "tags": [
        "stateful",
        "operational-hazard"
      ]
    },
    {
      "id": "pb:stateful-hash-signature:xmss:xmss",
      "name": "XMSS",
      "kind": "stateful-hash-signature",
      "family": "XMSS",
      "specificationStatus": "standardized",
      "securityStatus": "post-quantum-with-strict-state-management",
      "quantumClass": "post_quantum",
      "generationPolicy": "restricted",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-208 / RFC family",
      "tags": [
        "stateful",
        "operational-hazard"
      ]
    },
    {
      "id": "pb:stateful-hash-signature:xmss-mt:xmss-mt",
      "name": "XMSS-MT",
      "kind": "stateful-hash-signature",
      "family": "XMSS-MT",
      "specificationStatus": "standardized",
      "securityStatus": "post-quantum-with-strict-state-management",
      "quantumClass": "post_quantum",
      "generationPolicy": "restricted",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-208 / RFC family",
      "tags": [
        "stateful",
        "operational-hazard"
      ]
    },
    {
      "id": "pb:stream-cipher:a5:a5-1",
      "name": "A5/1",
      "kind": "stream-cipher",
      "family": "A5",
      "specificationStatus": "obsolete-telecom",
      "securityStatus": "broken",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:stream-cipher:a5:a5-2",
      "name": "A5/2",
      "kind": "stream-cipher",
      "family": "A5",
      "specificationStatus": "obsolete-telecom",
      "securityStatus": "broken",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:stream-cipher:chacha20:chacha20",
      "name": "ChaCha20",
      "kind": "stream-cipher",
      "family": "ChaCha20",
      "specificationStatus": "RFC-standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:stream-cipher:decim:decim",
      "name": "DECIM",
      "kind": "stream-cipher",
      "family": "DECIM",
      "specificationStatus": "historical/research",
      "securityStatus": "not-primary-modern-choice",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:stream-cipher:dragon:dragon",
      "name": "Dragon",
      "kind": "stream-cipher",
      "family": "Dragon",
      "specificationStatus": "historical/research",
      "securityStatus": "not-primary-modern-choice",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:stream-cipher:e0:e0",
      "name": "E0",
      "kind": "stream-cipher",
      "family": "E0",
      "specificationStatus": "obsolete-wireless",
      "securityStatus": "broken-or-weak",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:stream-cipher:f-fcsr-h:f-fcsr-h",
      "name": "F-FCSR-H",
      "kind": "stream-cipher",
      "family": "F-FCSR-H",
      "specificationStatus": "historical/research",
      "securityStatus": "not-primary-modern-choice",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:stream-cipher:grain-v1:grain-v1",
      "name": "Grain v1",
      "kind": "stream-cipher",
      "family": "Grain v1",
      "specificationStatus": "historical/research",
      "securityStatus": "not-primary-modern-choice",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:stream-cipher:grain-128aeadv2:grain-128aeadv2",
      "name": "Grain-128AEADv2",
      "kind": "stream-cipher",
      "family": "Grain-128AEADv2",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:stream-cipher:grain-128a:grain-128a",
      "name": "Grain-128a",
      "kind": "stream-cipher",
      "family": "Grain-128a",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:stream-cipher:hc-128:hc-128",
      "name": "HC-128",
      "kind": "stream-cipher",
      "family": "HC-128",
      "specificationStatus": "published",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:stream-cipher:hc-256:hc-256",
      "name": "HC-256",
      "kind": "stream-cipher",
      "family": "HC-256",
      "specificationStatus": "published",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:stream-cipher:lex:lex",
      "name": "LEX",
      "kind": "stream-cipher",
      "family": "LEX",
      "specificationStatus": "historical/research",
      "securityStatus": "not-primary-modern-choice",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:stream-cipher:mickey-2-0:mickey-2-0",
      "name": "MICKEY 2.0",
      "kind": "stream-cipher",
      "family": "MICKEY 2.0",
      "specificationStatus": "historical/research",
      "securityStatus": "not-primary-modern-choice",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:stream-cipher:mugi:mugi",
      "name": "MUGI",
      "kind": "stream-cipher",
      "family": "MUGI",
      "specificationStatus": "historical/research",
      "securityStatus": "not-primary-modern-choice",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:stream-cipher:panama-stream:panama-stream",
      "name": "Panama-stream",
      "kind": "stream-cipher",
      "family": "Panama-stream",
      "specificationStatus": "historical/research",
      "securityStatus": "not-primary-modern-choice",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:stream-cipher:phelix:phelix",
      "name": "Phelix",
      "kind": "stream-cipher",
      "family": "Phelix",
      "specificationStatus": "historical/research",
      "securityStatus": "not-primary-modern-choice",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:stream-cipher:py:py",
      "name": "Py",
      "kind": "stream-cipher",
      "family": "Py",
      "specificationStatus": "historical/research",
      "securityStatus": "not-primary-modern-choice",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:stream-cipher:rc4:rc4",
      "name": "RC4",
      "kind": "stream-cipher",
      "family": "RC4",
      "specificationStatus": "obsolete",
      "securityStatus": "broken/biases",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:stream-cipher:rabbit:rabbit",
      "name": "Rabbit",
      "kind": "stream-cipher",
      "family": "Rabbit",
      "specificationStatus": "RFC-standardized",
      "securityStatus": "legacy",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:stream-cipher:snow-2-0:snow-2-0",
      "name": "SNOW 2.0",
      "kind": "stream-cipher",
      "family": "SNOW 2.0",
      "specificationStatus": "telecom-standard",
      "securityStatus": "legacy",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:stream-cipher:snow-3g:snow-3g",
      "name": "SNOW 3G",
      "kind": "stream-cipher",
      "family": "SNOW 3G",
      "specificationStatus": "telecom-standard",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:stream-cipher:sosemanuk:sosemanuk",
      "name": "SOSEMANUK",
      "kind": "stream-cipher",
      "family": "SOSEMANUK",
      "specificationStatus": "historical/research",
      "securityStatus": "not-primary-modern-choice",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:stream-cipher:salsa20:salsa20-12",
      "name": "Salsa20/12",
      "kind": "stream-cipher",
      "family": "Salsa20",
      "specificationStatus": "published",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:stream-cipher:salsa20:salsa20-20",
      "name": "Salsa20/20",
      "kind": "stream-cipher",
      "family": "Salsa20",
      "specificationStatus": "published",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:stream-cipher:trivium:trivium",
      "name": "Trivium",
      "kind": "stream-cipher",
      "family": "Trivium",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:stream-cipher:xchacha20:xchacha20",
      "name": "XChaCha20",
      "kind": "stream-cipher",
      "family": "XChaCha20",
      "specificationStatus": "published/deployed",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:stream-cipher:zuc-128:zuc-128",
      "name": "ZUC-128",
      "kind": "stream-cipher",
      "family": "ZUC-128",
      "specificationStatus": "telecom-standard",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:stream-cipher:zuc-256:zuc-256",
      "name": "ZUC-256",
      "kind": "stream-cipher",
      "family": "ZUC-256",
      "specificationStatus": "telecom-standard",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:threshold-or-secret-sharing:blakley-secret-sharing:blakley-secret-sharing",
      "name": "Blakley Secret Sharing",
      "kind": "threshold-or-secret-sharing",
      "family": "Blakley Secret Sharing",
      "specificationStatus": "published",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "metadata-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:threshold-or-secret-sharing:frost-ed25519:frost-ed25519",
      "name": "FROST Ed25519",
      "kind": "threshold-or-secret-sharing",
      "family": "FROST Ed25519",
      "specificationStatus": "standardized-RFC",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:threshold-or-secret-sharing:frost-ed448:frost-ed448",
      "name": "FROST Ed448",
      "kind": "threshold-or-secret-sharing",
      "family": "FROST Ed448",
      "specificationStatus": "standardized-RFC",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:threshold-or-secret-sharing:feldman-vss:feldman-vss",
      "name": "Feldman VSS",
      "kind": "threshold-or-secret-sharing",
      "family": "Feldman VSS",
      "specificationStatus": "published",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:threshold-or-secret-sharing:musig2:musig2",
      "name": "MuSig2",
      "kind": "threshold-or-secret-sharing",
      "family": "MuSig2",
      "specificationStatus": "standardized/deployed",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:threshold-or-secret-sharing:pedersen-vss:pedersen-vss",
      "name": "Pedersen VSS",
      "kind": "threshold-or-secret-sharing",
      "family": "Pedersen VSS",
      "specificationStatus": "published",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:threshold-or-secret-sharing:shamir-secret-sharing:shamir-secret-sharing",
      "name": "Shamir Secret Sharing",
      "kind": "threshold-or-secret-sharing",
      "family": "Shamir Secret Sharing",
      "specificationStatus": "published",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:threshold-or-secret-sharing:threshold-ecdsa:threshold-ecdsa",
      "name": "Threshold ECDSA",
      "kind": "threshold-or-secret-sharing",
      "family": "Threshold ECDSA",
      "specificationStatus": "published/deployed",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:threshold-or-secret-sharing:threshold-rsa:threshold-rsa",
      "name": "Threshold RSA",
      "kind": "threshold-or-secret-sharing",
      "family": "Threshold RSA",
      "specificationStatus": "published",
      "securityStatus": "context-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:tls-cipher-suite:tls-1-3:tls-aes-128-ccm-8-sha256",
      "name": "TLS_AES_128_CCM_8_SHA256",
      "kind": "tls-cipher-suite",
      "family": "TLS 1.3",
      "specificationStatus": "registered",
      "securityStatus": "modern-if-protocol-rules-held",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA TLS / RFC 8446-family",
      "references": [
        "IANA TLS Parameters"
      ],
      "parameters": {
        "ianaValue": "0x1305",
        "hkdfHash": "SHA-256"
      }
    },
    {
      "id": "pb:tls-cipher-suite:tls-1-3:tls-aes-128-ccm-sha256",
      "name": "TLS_AES_128_CCM_SHA256",
      "kind": "tls-cipher-suite",
      "family": "TLS 1.3",
      "specificationStatus": "registered",
      "securityStatus": "modern-if-protocol-rules-held",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA TLS / RFC 8446-family",
      "references": [
        "IANA TLS Parameters"
      ],
      "parameters": {
        "ianaValue": "0x1304",
        "hkdfHash": "SHA-256"
      }
    },
    {
      "id": "pb:tls-cipher-suite:tls-1-3:tls-aes-128-gcm-sha256",
      "name": "TLS_AES_128_GCM_SHA256",
      "kind": "tls-cipher-suite",
      "family": "TLS 1.3",
      "specificationStatus": "registered",
      "securityStatus": "modern-if-protocol-rules-held",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA TLS / RFC 8446-family",
      "references": [
        "IANA TLS Parameters"
      ],
      "parameters": {
        "ianaValue": "0x1301",
        "hkdfHash": "SHA-256"
      }
    },
    {
      "id": "pb:tls-cipher-suite:tls-1-3:tls-aes-256-gcm-sha384",
      "name": "TLS_AES_256_GCM_SHA384",
      "kind": "tls-cipher-suite",
      "family": "TLS 1.3",
      "specificationStatus": "registered",
      "securityStatus": "modern-if-protocol-rules-held",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA TLS / RFC 8446-family",
      "references": [
        "IANA TLS Parameters"
      ],
      "parameters": {
        "ianaValue": "0x1302",
        "hkdfHash": "SHA-384"
      }
    },
    {
      "id": "pb:tls-cipher-suite:tls-1-3:tls-chacha20-poly1305-sha256",
      "name": "TLS_CHACHA20_POLY1305_SHA256",
      "kind": "tls-cipher-suite",
      "family": "TLS 1.3",
      "specificationStatus": "registered",
      "securityStatus": "modern-if-protocol-rules-held",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "IANA TLS / RFC 8446-family",
      "references": [
        "IANA TLS Parameters"
      ],
      "parameters": {
        "ianaValue": "0x1303",
        "hkdfHash": "SHA-256"
      }
    },
    {
      "id": "pb:tls-cipher-suite:tls-1-2:tls-ecdhe-ecdsa-with-aes-128-gcm-sha256",
      "name": "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256",
      "kind": "tls-cipher-suite",
      "family": "TLS <=1.2",
      "specificationStatus": "registered/historical",
      "securityStatus": "TLS1.2-modern-legacy",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "IANA TLS Parameters"
      ]
    },
    {
      "id": "pb:tls-cipher-suite:tls-1-2:tls-ecdhe-ecdsa-with-chacha20-poly1305-sha256",
      "name": "TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256",
      "kind": "tls-cipher-suite",
      "family": "TLS <=1.2",
      "specificationStatus": "registered/historical",
      "securityStatus": "TLS1.2-modern-legacy",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "IANA TLS Parameters"
      ]
    },
    {
      "id": "pb:tls-cipher-suite:tls-1-2:tls-ecdhe-rsa-with-aes-128-gcm-sha256",
      "name": "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256",
      "kind": "tls-cipher-suite",
      "family": "TLS <=1.2",
      "specificationStatus": "registered/historical",
      "securityStatus": "TLS1.2-modern-legacy",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "IANA TLS Parameters"
      ]
    },
    {
      "id": "pb:tls-cipher-suite:tls-1-2:tls-ecdhe-rsa-with-chacha20-poly1305-sha256",
      "name": "TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256",
      "kind": "tls-cipher-suite",
      "family": "TLS <=1.2",
      "specificationStatus": "registered/historical",
      "securityStatus": "TLS1.2-modern-legacy",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "IANA TLS Parameters"
      ]
    },
    {
      "id": "pb:tls-cipher-suite:tls-1-2:tls-rsa-with-3des-ede-cbc-sha",
      "name": "TLS_RSA_WITH_3DES_EDE_CBC_SHA",
      "kind": "tls-cipher-suite",
      "family": "TLS <=1.2",
      "specificationStatus": "registered/historical",
      "securityStatus": "obsolete",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "IANA TLS Parameters"
      ]
    },
    {
      "id": "pb:tls-cipher-suite:tls-1-2:tls-rsa-with-aes-128-cbc-sha",
      "name": "TLS_RSA_WITH_AES_128_CBC_SHA",
      "kind": "tls-cipher-suite",
      "family": "TLS <=1.2",
      "specificationStatus": "registered/historical",
      "securityStatus": "legacy/no-forward-secrecy",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "IANA TLS Parameters"
      ]
    },
    {
      "id": "pb:tls-cipher-suite:tls-1-2:tls-rsa-with-rc4-128-sha",
      "name": "TLS_RSA_WITH_RC4_128_SHA",
      "kind": "tls-cipher-suite",
      "family": "TLS <=1.2",
      "specificationStatus": "registered/historical",
      "securityStatus": "broken/obsolete",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "IANA TLS Parameters"
      ]
    },
    {
      "id": "pb:tls-signature-scheme:tls-signaturescheme:ecdsa-secp256r1-sha256",
      "name": "ecdsa_secp256r1_sha256",
      "kind": "tls-signature-scheme",
      "family": "TLS SignatureScheme",
      "specificationStatus": "IANA-registered",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "IANA TLS Parameters"
      ],
      "parameters": {
        "ianaValue": "0x0403"
      }
    },
    {
      "id": "pb:tls-signature-scheme:tls-signaturescheme:ecdsa-secp384r1-sha384",
      "name": "ecdsa_secp384r1_sha384",
      "kind": "tls-signature-scheme",
      "family": "TLS SignatureScheme",
      "specificationStatus": "IANA-registered",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "IANA TLS Parameters"
      ],
      "parameters": {
        "ianaValue": "0x0503"
      }
    },
    {
      "id": "pb:tls-signature-scheme:tls-signaturescheme:ecdsa-secp521r1-sha512",
      "name": "ecdsa_secp521r1_sha512",
      "kind": "tls-signature-scheme",
      "family": "TLS SignatureScheme",
      "specificationStatus": "IANA-registered",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "IANA TLS Parameters"
      ],
      "parameters": {
        "ianaValue": "0x0603"
      }
    },
    {
      "id": "pb:tls-signature-scheme:tls-signaturescheme:ecdsa-sha1",
      "name": "ecdsa_sha1",
      "kind": "tls-signature-scheme",
      "family": "TLS SignatureScheme",
      "specificationStatus": "IANA-registered",
      "securityStatus": "deprecated",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "IANA TLS Parameters"
      ],
      "parameters": {
        "ianaValue": "0x0203"
      }
    },
    {
      "id": "pb:tls-signature-scheme:tls-signaturescheme:ed25519",
      "name": "ed25519",
      "kind": "tls-signature-scheme",
      "family": "TLS SignatureScheme",
      "specificationStatus": "IANA-registered",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "IANA TLS Parameters"
      ],
      "parameters": {
        "ianaValue": "0x0807"
      }
    },
    {
      "id": "pb:tls-signature-scheme:tls-signaturescheme:ed448",
      "name": "ed448",
      "kind": "tls-signature-scheme",
      "family": "TLS SignatureScheme",
      "specificationStatus": "IANA-registered",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "IANA TLS Parameters"
      ],
      "parameters": {
        "ianaValue": "0x0808"
      }
    },
    {
      "id": "pb:tls-signature-scheme:tls-signaturescheme:rsa-pkcs1-sha1",
      "name": "rsa_pkcs1_sha1",
      "kind": "tls-signature-scheme",
      "family": "TLS SignatureScheme",
      "specificationStatus": "IANA-registered",
      "securityStatus": "deprecated",
      "quantumClass": "classical",
      "generationPolicy": "verify-only",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "IANA TLS Parameters"
      ],
      "parameters": {
        "ianaValue": "0x0201"
      }
    },
    {
      "id": "pb:tls-signature-scheme:tls-signaturescheme:rsa-pss-pss-sha256",
      "name": "rsa_pss_pss_sha256",
      "kind": "tls-signature-scheme",
      "family": "TLS SignatureScheme",
      "specificationStatus": "IANA-registered",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "IANA TLS Parameters"
      ],
      "parameters": {
        "ianaValue": "0x0809"
      }
    },
    {
      "id": "pb:tls-signature-scheme:tls-signaturescheme:rsa-pss-pss-sha384",
      "name": "rsa_pss_pss_sha384",
      "kind": "tls-signature-scheme",
      "family": "TLS SignatureScheme",
      "specificationStatus": "IANA-registered",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "IANA TLS Parameters"
      ],
      "parameters": {
        "ianaValue": "0x080A"
      }
    },
    {
      "id": "pb:tls-signature-scheme:tls-signaturescheme:rsa-pss-pss-sha512",
      "name": "rsa_pss_pss_sha512",
      "kind": "tls-signature-scheme",
      "family": "TLS SignatureScheme",
      "specificationStatus": "IANA-registered",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "IANA TLS Parameters"
      ],
      "parameters": {
        "ianaValue": "0x080B"
      }
    },
    {
      "id": "pb:tls-signature-scheme:tls-signaturescheme:rsa-pss-rsae-sha256",
      "name": "rsa_pss_rsae_sha256",
      "kind": "tls-signature-scheme",
      "family": "TLS SignatureScheme",
      "specificationStatus": "IANA-registered",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "IANA TLS Parameters"
      ],
      "parameters": {
        "ianaValue": "0x0804"
      }
    },
    {
      "id": "pb:tls-signature-scheme:tls-signaturescheme:rsa-pss-rsae-sha384",
      "name": "rsa_pss_rsae_sha384",
      "kind": "tls-signature-scheme",
      "family": "TLS SignatureScheme",
      "specificationStatus": "IANA-registered",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "IANA TLS Parameters"
      ],
      "parameters": {
        "ianaValue": "0x0805"
      }
    },
    {
      "id": "pb:tls-signature-scheme:tls-signaturescheme:rsa-pss-rsae-sha512",
      "name": "rsa_pss_rsae_sha512",
      "kind": "tls-signature-scheme",
      "family": "TLS SignatureScheme",
      "specificationStatus": "IANA-registered",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "IANA TLS Parameters"
      ],
      "parameters": {
        "ianaValue": "0x0806"
      }
    },
    {
      "id": "pb:transform:fiat-shamir-transform:fiat-shamir-transform",
      "name": "Fiat-Shamir transform",
      "kind": "transform",
      "family": "Fiat-Shamir transform",
      "specificationStatus": "published",
      "securityStatus": "assumption-and-instantiation-dependent",
      "quantumClass": "classical",
      "generationPolicy": "context-only",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:transparent-proof-family:stark:stark",
      "name": "STARK",
      "kind": "transparent-proof-family",
      "family": "STARK",
      "specificationStatus": "published/deployed",
      "securityStatus": "assumption-and-instantiation-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:vrf:ecvrf:ecvrf-edwards25519-sha512-ell2",
      "name": "ECVRF-EDWARDS25519-SHA512-ELL2",
      "kind": "vrf",
      "family": "ECVRF",
      "specificationStatus": "standardized-RFC",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 9381",
      "references": [
        "RFC 9381"
      ]
    },
    {
      "id": "pb:vrf:ecvrf:ecvrf-edwards25519-sha512-tai",
      "name": "ECVRF-EDWARDS25519-SHA512-TAI",
      "kind": "vrf",
      "family": "ECVRF",
      "specificationStatus": "standardized-RFC",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 9381",
      "references": [
        "RFC 9381"
      ]
    },
    {
      "id": "pb:vrf:ecvrf:ecvrf-p256-sha256-sswu",
      "name": "ECVRF-P256-SHA256-SSWU",
      "kind": "vrf",
      "family": "ECVRF",
      "specificationStatus": "standardized-RFC",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 9381",
      "references": [
        "RFC 9381"
      ]
    },
    {
      "id": "pb:vrf:ecvrf:ecvrf-p256-sha256-tai",
      "name": "ECVRF-P256-SHA256-TAI",
      "kind": "vrf",
      "family": "ECVRF",
      "specificationStatus": "standardized-RFC",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "RFC 9381",
      "references": [
        "RFC 9381"
      ]
    },
    {
      "id": "pb:xof:ascon:ascon-cxof128",
      "name": "Ascon-CXOF128",
      "kind": "xof",
      "family": "Ascon",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-232",
      "references": [
        "NIST SP 800-232"
      ],
      "parameters": {
        "securityStrengthBits": 128
      }
    },
    {
      "id": "pb:xof:ascon:ascon-xof128",
      "name": "Ascon-XOF128",
      "kind": "xof",
      "family": "Ascon",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "NIST SP 800-232",
      "references": [
        "NIST SP 800-232"
      ],
      "parameters": {
        "securityStrengthBits": 128
      }
    },
    {
      "id": "pb:xof:keccak-derived:kangarootwelve",
      "name": "KangarooTwelve",
      "kind": "xof",
      "family": "Keccak-derived",
      "specificationStatus": "standard-or-RFC",
      "securityStatus": "accepted-or-research",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "RFC 9861"
      ],
      "parameters": {
        "securityStrengthBits": 128
      }
    },
    {
      "id": "pb:xof:keccak-derived:marsupilamifourteen",
      "name": "MarsupilamiFourteen",
      "kind": "xof",
      "family": "Keccak-derived",
      "specificationStatus": "research",
      "securityStatus": "accepted-or-research",
      "quantumClass": "classical",
      "generationPolicy": "experimental",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "parameters": {
        "securityStrengthBits": 256
      }
    },
    {
      "id": "pb:xof:keccak-derived:turboshake128",
      "name": "TurboSHAKE128",
      "kind": "xof",
      "family": "Keccak-derived",
      "specificationStatus": "standard-or-RFC",
      "securityStatus": "accepted-or-research",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "RFC 9861"
      ],
      "parameters": {
        "securityStrengthBits": 128
      }
    },
    {
      "id": "pb:xof:keccak-derived:turboshake256",
      "name": "TurboSHAKE256",
      "kind": "xof",
      "family": "Keccak-derived",
      "specificationStatus": "standard-or-RFC",
      "securityStatus": "accepted-or-research",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "references": [
        "RFC 9861"
      ],
      "parameters": {
        "securityStrengthBits": 256
      }
    },
    {
      "id": "pb:xof:shake:shake128",
      "name": "SHAKE128",
      "kind": "xof",
      "family": "SHAKE",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 202",
      "references": [
        "FIPS 202"
      ],
      "parameters": {
        "securityStrengthBits": 128
      }
    },
    {
      "id": "pb:xof:shake:shake256",
      "name": "SHAKE256",
      "kind": "xof",
      "family": "SHAKE",
      "specificationStatus": "standardized",
      "securityStatus": "accepted",
      "quantumClass": "classical",
      "generationPolicy": "allow",
      "implementationStatus": "UNVERIFIED_IN_PB",
      "spec": "FIPS 202",
      "references": [
        "FIPS 202"
      ],
      "parameters": {
        "securityStrengthBits": 256
      }
    },
    {
      "id": "pb:zero-knowledge-proof:bulletproofs:bulletproofs",
      "name": "Bulletproofs",
      "kind": "zero-knowledge-proof",
      "family": "Bulletproofs",
      "specificationStatus": "published/deployed",
      "securityStatus": "assumption-and-instantiation-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:zk-proof-system:groth16:groth16",
      "name": "Groth16",
      "kind": "zk-proof-system",
      "family": "Groth16",
      "specificationStatus": "published/deployed",
      "securityStatus": "assumption-and-instantiation-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:zk-proof-system:halo-halo2-ipa:halo-halo2-ipa",
      "name": "Halo/Halo2 IPA",
      "kind": "zk-proof-system",
      "family": "Halo/Halo2 IPA",
      "specificationStatus": "published/deployed",
      "securityStatus": "assumption-and-instantiation-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    },
    {
      "id": "pb:zk-proof-system:plonk:plonk",
      "name": "PLONK",
      "kind": "zk-proof-system",
      "family": "PLONK",
      "specificationStatus": "published/deployed",
      "securityStatus": "assumption-and-instantiation-dependent",
      "quantumClass": "classical",
      "generationPolicy": "compat",
      "implementationStatus": "UNVERIFIED_IN_PB"
    }
  ]
});


export const PB_CRYPTO_BY_ID = Object.freeze(
  Object.fromEntries(PB_CRYPTO_REGISTRY.algorithms.map(x => [x.id, x]))
);

export function cryptoById(id) {
  return PB_CRYPTO_BY_ID[id] ?? null;
}

export function cryptoSearch(query) {
  const q = String(query).toLowerCase();
  return PB_CRYPTO_REGISTRY.algorithms.filter(x =>
    x.id.toLowerCase().includes(q) ||
    x.name.toLowerCase().includes(q) ||
    x.family.toLowerCase().includes(q) ||
    (x.aliases ?? []).some(a => String(a).toLowerCase().includes(q))
  );
}

export function cryptoByKind(kind) {
  return PB_CRYPTO_REGISTRY.algorithms.filter(x => x.kind === kind);
}

export function cryptoAllowedForGeneration() {
  return PB_CRYPTO_REGISTRY.algorithms.filter(x => x.generationPolicy === "allow");
}

export function assertRegistryIntegrity() {
  const ids = new Set();
  for (const x of PB_CRYPTO_REGISTRY.algorithms) {
    if (!x.id || !x.name || !x.kind || !x.family) throw new Error("Malformed crypto registry entry");
    if (ids.has(x.id)) throw new Error(`Duplicate crypto registry id: ${x.id}`);
    ids.add(x.id);
  }
  return true;
}
