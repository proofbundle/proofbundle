Definition x := 1.
