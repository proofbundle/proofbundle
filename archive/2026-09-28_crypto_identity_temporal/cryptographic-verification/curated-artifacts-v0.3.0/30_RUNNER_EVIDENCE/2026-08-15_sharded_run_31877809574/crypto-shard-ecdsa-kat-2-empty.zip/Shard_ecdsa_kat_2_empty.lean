import Std
import ECDSAP256

namespace ProofBundle.Crypto.ECDSAP256

def priv_kat_2_empty : Nat := 0x6884f77d3e9098b773d660dd4a4f297b29805739db772a334f209db13c035de6

/-- Vector `kat_2_empty` — message (ground truth, hex in the JSON). -/
def msg_kat_2_empty : ByteArray := ByteArray.mk #[]

/-- Vector `kat_2_empty` — RFC 6979 section 3.2 deterministic nonce recovery:
`rfc6979K priv msg` reproduces the ground-truth `k`. -/
theorem kat_kat_2_empty_nonce :
    rfc6979K priv_kat_2_empty msg_kat_2_empty = 0xac1e330cda30645827868935362388ea2614b7b4338525b17603346d6ce2da7d := by native_decide

/-- Vector `kat_2_empty` — FIPS 186-5 section 6.4.1 signature generation:
`ecdsaSign priv msg = (r, s)` with `r = 0xbac017cbdf65e2c96dded840a9103770236dc4cd733d64b664264cdfd675205c`
and `s = 0xafd5e0057affb675b1d88a42cba0cb2f81d6e549c191e60478ae12dc7950b952`. -/
theorem kat_kat_2_empty_sign :
    ecdsaSign priv_kat_2_empty msg_kat_2_empty = (0xbac017cbdf65e2c96dded840a9103770236dc4cd733d64b664264cdfd675205c, 0xafd5e0057affb675b1d88a42cba0cb2f81d6e549c191e60478ae12dc7950b952) := by native_decide

/-- Vector `kat_2_empty` — FIPS 186-5 section 6.4.4 verification accepts the
fresh signature under the ground-truth public key. -/
theorem kat_kat_2_empty_verify :
    ecdsaVerify (Point.affine 0x8687c1b7cc9e108f61c91886d4bdedb2d0803e68db540c7ee2ce8e2991edfa89 0xf1fc0fbcefa2decac587b31e72fb14cdfa2ca808af700f80037562a64905a6b9) msg_kat_2_empty
      0xbac017cbdf65e2c96dded840a9103770236dc4cd733d64b664264cdfd675205c 0xafd5e0057affb675b1d88a42cba0cb2f81d6e549c191e60478ae12dc7950b952 = true := by native_decide

/-- Vector `kat_2_empty` — public-key derivation: `priv·G` is the ground-truth
public key 0x8687c1b7cc9e108f61c91886d4bdedb2d0803e68db540c7ee2ce8e2991edfa89 / 0xf1fc0fbcefa2decac587b31e72fb14cdfa2ca808af700f80037562a64905a6b9. -/
theorem kat_kat_2_empty_pubkey :
    pointMul basePoint priv_kat_2_empty =
      Point.affine 0x8687c1b7cc9e108f61c91886d4bdedb2d0803e68db540c7ee2ce8e2991edfa89 0xf1fc0fbcefa2decac587b31e72fb14cdfa2ca808af700f80037562a64905a6b9 := by native_decide

/-- Vector `kat_2_empty` — the ground-truth public key passes the FIPS 186-5
section 5.6.2.3 full validation procedure, and the full pipeline
accepts the signature. -/
theorem kat_kat_2_empty_verify_full :
    ecdsaVerifyFull (Point.affine 0x8687c1b7cc9e108f61c91886d4bdedb2d0803e68db540c7ee2ce8e2991edfa89 0xf1fc0fbcefa2decac587b31e72fb14cdfa2ca808af700f80037562a64905a6b9) msg_kat_2_empty
      0xbac017cbdf65e2c96dded840a9103770236dc4cd733d64b664264cdfd675205c 0xafd5e0057affb675b1d88a42cba0cb2f81d6e549c191e60478ae12dc7950b952 = true := by native_decide

/-- Vector `kat_2_msg` — private key (ground truth). -/

end ProofBundle.Crypto.ECDSAP256
