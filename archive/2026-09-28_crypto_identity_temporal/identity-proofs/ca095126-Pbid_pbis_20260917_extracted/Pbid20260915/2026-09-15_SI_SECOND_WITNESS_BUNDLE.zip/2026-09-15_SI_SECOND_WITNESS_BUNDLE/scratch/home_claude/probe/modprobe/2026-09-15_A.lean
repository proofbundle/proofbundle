def aValue : Bool := true
