import Std
import ECDSAP256

namespace ProofBundle.Crypto.ECDSAP256

def priv_kat_1_msg : Nat := 0x39c82bd578436d01e3074d1c9817b1cb020fd333978045da39ec9495fb383360

/-- Vector `kat_1_msg` — message (ground truth, hex in the JSON). -/
def msg_kat_1_msg : ByteArray := ByteArray.mk #[0x00]

/-- Vector `kat_1_msg` — RFC 6979 section 3.2 deterministic nonce recovery:
`rfc6979K priv msg` reproduces the ground-truth `k`. -/
theorem kat_kat_1_msg_nonce :
    rfc6979K priv_kat_1_msg msg_kat_1_msg = 0xbc995b457cc872e5eac6640b6706cdc9ecf4d7805b8a2fdc260f541b12138f09 := by native_decide

/-- Vector `kat_1_msg` — FIPS 186-5 section 6.4.1 signature generation:
`ecdsaSign priv msg = (r, s)` with `r = 0xef5a672bcc27db3052407f3e6d61a5e4d2ba7dc9578bd28c3b155931dc1e3883`
and `s = 0xa97e4b723bb8c8ca90280bc1a81de2b14ed680920ca8da6d21f3b6fb8ea8a5ea`. -/
theorem kat_kat_1_msg_sign :
    ecdsaSign priv_kat_1_msg msg_kat_1_msg = (0xef5a672bcc27db3052407f3e6d61a5e4d2ba7dc9578bd28c3b155931dc1e3883, 0xa97e4b723bb8c8ca90280bc1a81de2b14ed680920ca8da6d21f3b6fb8ea8a5ea) := by native_decide

/-- Vector `kat_1_msg` — FIPS 186-5 section 6.4.4 verification accepts the
fresh signature under the ground-truth public key. -/
theorem kat_kat_1_msg_verify :
    ecdsaVerify (Point.affine 0xbbcc2bf06cd5102ff518fa9ebe734d1646a4f0ce47efb945499b2be42d486291 0xcbf00bb9a65930170bd98127208c6f193a56563ece78bdc37284c9091f065c72) msg_kat_1_msg
      0xef5a672bcc27db3052407f3e6d61a5e4d2ba7dc9578bd28c3b155931dc1e3883 0xa97e4b723bb8c8ca90280bc1a81de2b14ed680920ca8da6d21f3b6fb8ea8a5ea = true := by native_decide

/-- Vector `kat_1_msg` — public-key derivation: `priv·G` is the ground-truth
public key 0xbbcc2bf06cd5102ff518fa9ebe734d1646a4f0ce47efb945499b2be42d486291 / 0xcbf00bb9a65930170bd98127208c6f193a56563ece78bdc37284c9091f065c72. -/
theorem kat_kat_1_msg_pubkey :
    pointMul basePoint priv_kat_1_msg =
      Point.affine 0xbbcc2bf06cd5102ff518fa9ebe734d1646a4f0ce47efb945499b2be42d486291 0xcbf00bb9a65930170bd98127208c6f193a56563ece78bdc37284c9091f065c72 := by native_decide

/-- Vector `kat_1_msg` — the ground-truth public key passes the FIPS 186-5
section 5.6.2.3 full validation procedure, and the full pipeline
accepts the signature. -/
theorem kat_kat_1_msg_verify_full :
    ecdsaVerifyFull (Point.affine 0xbbcc2bf06cd5102ff518fa9ebe734d1646a4f0ce47efb945499b2be42d486291 0xcbf00bb9a65930170bd98127208c6f193a56563ece78bdc37284c9091f065c72) msg_kat_1_msg
      0xef5a672bcc27db3052407f3e6d61a5e4d2ba7dc9578bd28c3b155931dc1e3883 0xa97e4b723bb8c8ca90280bc1a81de2b14ed680920ca8da6d21f3b6fb8ea8a5ea = true := by native_decide

/-- Vector `kat_2_empty` — private key (ground truth). -/

end ProofBundle.Crypto.ECDSAP256
