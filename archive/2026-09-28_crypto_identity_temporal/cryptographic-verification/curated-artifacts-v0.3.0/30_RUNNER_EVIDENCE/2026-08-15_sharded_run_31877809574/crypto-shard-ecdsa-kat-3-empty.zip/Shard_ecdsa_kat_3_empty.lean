import Std
import ECDSAP256

namespace ProofBundle.Crypto.ECDSAP256

def priv_kat_3_empty : Nat := 0xb6ab6057d4911fd0912ed386f5529b78475c60ebe40a6ca00d487b86c90bfa44

/-- Vector `kat_3_empty` — message (ground truth, hex in the JSON). -/
def msg_kat_3_empty : ByteArray := ByteArray.mk #[]

/-- Vector `kat_3_empty` — RFC 6979 section 3.2 deterministic nonce recovery:
`rfc6979K priv msg` reproduces the ground-truth `k`. -/
theorem kat_kat_3_empty_nonce :
    rfc6979K priv_kat_3_empty msg_kat_3_empty = 0x6c92acc08af029a20b8129b3718fc671a1920a9597206d52cc4431ce96a84b26 := by native_decide

/-- Vector `kat_3_empty` — FIPS 186-5 section 6.4.1 signature generation:
`ecdsaSign priv msg = (r, s)` with `r = 0x62317deabda139f8aee3bcca39ee51d8afc2c6a9ac17170fa87e4b99f7ab2dcb`
and `s = 0x250015c493852dc3ea6a8dfa82b3e6e3d23288a14f7dfb9a9f2720f4ba37b4b6`. -/
theorem kat_kat_3_empty_sign :
    ecdsaSign priv_kat_3_empty msg_kat_3_empty = (0x62317deabda139f8aee3bcca39ee51d8afc2c6a9ac17170fa87e4b99f7ab2dcb, 0x250015c493852dc3ea6a8dfa82b3e6e3d23288a14f7dfb9a9f2720f4ba37b4b6) := by native_decide

/-- Vector `kat_3_empty` — FIPS 186-5 section 6.4.4 verification accepts the
fresh signature under the ground-truth public key. -/
theorem kat_kat_3_empty_verify :
    ecdsaVerify (Point.affine 0x8af4e1ee8a431ac672d3fad290ab73774a5e7ebed047551ffab5c82f0f54d91c 0x6a16c0aad11d9e0f925b13d3e3f318cf023e03284de795913cc65ae3f1cec38f) msg_kat_3_empty
      0x62317deabda139f8aee3bcca39ee51d8afc2c6a9ac17170fa87e4b99f7ab2dcb 0x250015c493852dc3ea6a8dfa82b3e6e3d23288a14f7dfb9a9f2720f4ba37b4b6 = true := by native_decide

/-- Vector `kat_3_empty` — public-key derivation: `priv·G` is the ground-truth
public key 0x8af4e1ee8a431ac672d3fad290ab73774a5e7ebed047551ffab5c82f0f54d91c / 0x6a16c0aad11d9e0f925b13d3e3f318cf023e03284de795913cc65ae3f1cec38f. -/
theorem kat_kat_3_empty_pubkey :
    pointMul basePoint priv_kat_3_empty =
      Point.affine 0x8af4e1ee8a431ac672d3fad290ab73774a5e7ebed047551ffab5c82f0f54d91c 0x6a16c0aad11d9e0f925b13d3e3f318cf023e03284de795913cc65ae3f1cec38f := by native_decide

/-- Vector `kat_3_empty` — the ground-truth public key passes the FIPS 186-5
section 5.6.2.3 full validation procedure, and the full pipeline
accepts the signature. -/
theorem kat_kat_3_empty_verify_full :
    ecdsaVerifyFull (Point.affine 0x8af4e1ee8a431ac672d3fad290ab73774a5e7ebed047551ffab5c82f0f54d91c 0x6a16c0aad11d9e0f925b13d3e3f318cf023e03284de795913cc65ae3f1cec38f) msg_kat_3_empty
      0x62317deabda139f8aee3bcca39ee51d8afc2c6a9ac17170fa87e4b99f7ab2dcb 0x250015c493852dc3ea6a8dfa82b3e6e3d23288a14f7dfb9a9f2720f4ba37b4b6 = true := by native_decide

/-- Vector `kat_3_msg` — private key (ground truth). -/

end ProofBundle.Crypto.ECDSAP256
