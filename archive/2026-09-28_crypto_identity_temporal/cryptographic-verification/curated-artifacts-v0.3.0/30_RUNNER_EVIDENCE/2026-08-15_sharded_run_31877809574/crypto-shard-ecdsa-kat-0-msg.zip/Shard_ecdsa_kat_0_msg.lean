import Std
import ECDSAP256

namespace ProofBundle.Crypto.ECDSAP256

def priv_kat_0_msg : Nat := 0x7a083a580e618c8d21c8b9a24fa5a52bfae8f2490a75152a63d36eb7250a5f52

/-- Vector `kat_0_msg` — message (ground truth, hex in the JSON). -/
def msg_kat_0_msg : ByteArray := ByteArray.mk #[0x61, 0x62, 0x63]

/-- Vector `kat_0_msg` — RFC 6979 section 3.2 deterministic nonce recovery:
`rfc6979K priv msg` reproduces the ground-truth `k`. -/
theorem kat_kat_0_msg_nonce :
    rfc6979K priv_kat_0_msg msg_kat_0_msg = 0x4d75d064bb2ce80e039b78788d8ed52cf74a04861440fad10f3f0c3dc5df488e := by native_decide

/-- Vector `kat_0_msg` — FIPS 186-5 section 6.4.1 signature generation:
`ecdsaSign priv msg = (r, s)` with `r = 0xe3087afd1470fd1db5c63c735f509eb06bafb399c805f506908319e9aab81407`
and `s = 0xcbf1e0a1241d47736db4ff09539caf0309b0b6bdd67ab6e8fca484e683c7e666`. -/
theorem kat_kat_0_msg_sign :
    ecdsaSign priv_kat_0_msg msg_kat_0_msg = (0xe3087afd1470fd1db5c63c735f509eb06bafb399c805f506908319e9aab81407, 0xcbf1e0a1241d47736db4ff09539caf0309b0b6bdd67ab6e8fca484e683c7e666) := by native_decide

/-- Vector `kat_0_msg` — FIPS 186-5 section 6.4.4 verification accepts the
fresh signature under the ground-truth public key. -/
theorem kat_kat_0_msg_verify :
    ecdsaVerify (Point.affine 0xf839cbb33743702a05c3c4b394c0f2ad813a2e51801bf68ac9bc884fb987541c 0x5a2360547558b03a662421c13e13b97e9d202c26b96681b6206215786e839163) msg_kat_0_msg
      0xe3087afd1470fd1db5c63c735f509eb06bafb399c805f506908319e9aab81407 0xcbf1e0a1241d47736db4ff09539caf0309b0b6bdd67ab6e8fca484e683c7e666 = true := by native_decide

/-- Vector `kat_0_msg` — public-key derivation: `priv·G` is the ground-truth
public key 0xf839cbb33743702a05c3c4b394c0f2ad813a2e51801bf68ac9bc884fb987541c / 0x5a2360547558b03a662421c13e13b97e9d202c26b96681b6206215786e839163. -/
theorem kat_kat_0_msg_pubkey :
    pointMul basePoint priv_kat_0_msg =
      Point.affine 0xf839cbb33743702a05c3c4b394c0f2ad813a2e51801bf68ac9bc884fb987541c 0x5a2360547558b03a662421c13e13b97e9d202c26b96681b6206215786e839163 := by native_decide

/-- Vector `kat_0_msg` — the ground-truth public key passes the FIPS 186-5
section 5.6.2.3 full validation procedure, and the full pipeline
accepts the signature. -/
theorem kat_kat_0_msg_verify_full :
    ecdsaVerifyFull (Point.affine 0xf839cbb33743702a05c3c4b394c0f2ad813a2e51801bf68ac9bc884fb987541c 0x5a2360547558b03a662421c13e13b97e9d202c26b96681b6206215786e839163) msg_kat_0_msg
      0xe3087afd1470fd1db5c63c735f509eb06bafb399c805f506908319e9aab81407 0xcbf1e0a1241d47736db4ff09539caf0309b0b6bdd67ab6e8fca484e683c7e666 = true := by native_decide

/-- Vector `kat_1_empty` — private key (ground truth). -/

end ProofBundle.Crypto.ECDSAP256
