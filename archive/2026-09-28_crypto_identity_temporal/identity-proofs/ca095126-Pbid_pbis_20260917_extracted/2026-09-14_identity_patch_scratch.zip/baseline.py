import asyncio, json, sys
from playwright.async_api import async_playwright

URL = sys.argv[1]
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch()
        pg = await b.new_page()
        errs = []
        pg.on("pageerror", lambda e: errs.append("pageerror: " + str(e)))
        pg.on("console", lambda m: errs.append("console." + m.type + ": " + m.text) if m.type in ("error","warning") else None)
        await pg.goto(URL)
        await pg.wait_for_function("Array.isArray(window.PB_SELFTEST)", timeout=120000)
        st = await pg.evaluate("window.PB_SELFTEST")
        fails = [r for r in st if not r["ok"]]
        print("SELFTEST", sum(1 for r in st if r["ok"]), "/", len(st))
        for f in fails: print("  FAIL", f["name"], f["note"][:200])
        # full live conformance matrix, all digests x all sig algs
        res = await pg.evaluate("""async () => {
          let pass=0, fail=0; const bad=[];
          for (const d of PB_DIGESTS) for (const s of PB_SIGS) {
            let cases;
            try { cases = await buildRunnerCases(d.id, s.id); }
            catch (e) { fail += 10; bad.push(d.id+'x'+s.id+' seal: '+e.message); continue; }
            for (const c of cases) {
              const { outcome } = await verifyCore(c.bundle, c.opts);
              if (outcome === c.expected) pass++; else { fail++; bad.push(d.id+'x'+s.id+' '+c.expected+'->'+outcome); }
            }
          }
          return { pass, fail, bad: bad.slice(0,20) };
        }""")
        print("CONFORMANCE", json.dumps(res))
        # verify-report round-trip through JSON (what a downloaded report goes through)
        rep = await pg.evaluate("""async () => {
          const key = await sigKeygen('Ed25519');
          const subj = await sealCore(runnerBaseBundle(), 'SHA3-256', 'Ed25519', key);
          const v = await verifyCore(subj, { context: RUNNER_CTX_OK });
          const r = await buildVerifyReport(subj, v.outcome, v.trace, 'SHA3-256', 'Ed25519', key, Date.now());
          const inMem = (await verifyCore(r, {})).outcome;
          const viaJson = (await verifyCore(JSON.parse(JSON.stringify(r)), {})).outcome;
          return { inMem, viaJson, firstTraceEntry: JSON.stringify(r.payload.trace[0]), traceKeys: Object.keys(v.trace[0]) };
        }""")
        print("VERIFY-REPORT", json.dumps(rep))
        print("ERRORS", len(errs))
        for e in errs[:15]: print("  ", e[:200])
        await b.close()
asyncio.run(main())
