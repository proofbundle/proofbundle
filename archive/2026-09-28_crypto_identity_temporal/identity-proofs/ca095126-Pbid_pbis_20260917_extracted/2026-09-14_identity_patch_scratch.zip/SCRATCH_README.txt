2026-09-14 identity patch — scratch, kept for provenance
patch/apply.py      applies the patch; reads patch/module.js from its own folder; every anchor must match exactly once
                    usage: python3 patch/apply.py proofbundle_txt.html out.html
patch/module.js     identity module source as inserted (edit E3); includes the pending/body fix
baseline.py         first baseline run against the unmodified upload
kat.py              isolates the Ed25519 KAT argument-order fault
run_all.sh          starts the local server and harness in one process (the split version kept dying)
scratch/keyring.json, scratch/registry.pb.json
                    produced by the UI test run. The private keys are throwaway test keys generated
                    in headless Chromium. Do not use them for anything.
Not included: the log of the first harness run (5/53 failing). It was overwritten by the rerun.
