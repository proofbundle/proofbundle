import Std
import ECDSAP256

namespace ProofBundle.Crypto.ECDSAP256

def priv_kat_1_empty : Nat := 0x39c82bd578436d01e3074d1c9817b1cb020fd333978045da39ec9495fb383360

/-- Vector `kat_1_empty` — message (ground truth, hex in the JSON). -/
def msg_kat_1_empty : ByteArray := ByteArray.mk #[]

/-- Vector `kat_1_empty` — RFC 6979 section 3.2 deterministic nonce recovery:
`rfc6979K priv msg` reproduces the ground-truth `k`. -/
theorem kat_kat_1_empty_nonce :
    rfc6979K priv_kat_1_empty msg_kat_1_empty = 0x431b4af646e83f4fb44f9567ffa45e6c29152887f3a1f0cbc5c11d17e7d96ac2 := by native_decide

/-- Vector `kat_1_empty` — FIPS 186-5 section 6.4.1 signature generation:
`ecdsaSign priv msg = (r, s)` with `r = 0x926a96b79dbcbf6a45dfa34e19e4f937fcf8dd97e87f330fda1ad48374f1a9f0`
and `s = 0x97f2a9c669f413630b4fcf2778811c582ed5a469004067f946ece31ee1df52a3`. -/
theorem kat_kat_1_empty_sign :
    ecdsaSign priv_kat_1_empty msg_kat_1_empty = (0x926a96b79dbcbf6a45dfa34e19e4f937fcf8dd97e87f330fda1ad48374f1a9f0, 0x97f2a9c669f413630b4fcf2778811c582ed5a469004067f946ece31ee1df52a3) := by native_decide

/-- Vector `kat_1_empty` — FIPS 186-5 section 6.4.4 verification accepts the
fresh signature under the ground-truth public key. -/
theorem kat_kat_1_empty_verify :
    ecdsaVerify (Point.affine 0xbbcc2bf06cd5102ff518fa9ebe734d1646a4f0ce47efb945499b2be42d486291 0xcbf00bb9a65930170bd98127208c6f193a56563ece78bdc37284c9091f065c72) msg_kat_1_empty
      0x926a96b79dbcbf6a45dfa34e19e4f937fcf8dd97e87f330fda1ad48374f1a9f0 0x97f2a9c669f413630b4fcf2778811c582ed5a469004067f946ece31ee1df52a3 = true := by native_decide

/-- Vector `kat_1_empty` — public-key derivation: `priv·G` is the ground-truth
public key 0xbbcc2bf06cd5102ff518fa9ebe734d1646a4f0ce47efb945499b2be42d486291 / 0xcbf00bb9a65930170bd98127208c6f193a56563ece78bdc37284c9091f065c72. -/
theorem kat_kat_1_empty_pubkey :
    pointMul basePoint priv_kat_1_empty =
      Point.affine 0xbbcc2bf06cd5102ff518fa9ebe734d1646a4f0ce47efb945499b2be42d486291 0xcbf00bb9a65930170bd98127208c6f193a56563ece78bdc37284c9091f065c72 := by native_decide

/-- Vector `kat_1_empty` — the ground-truth public key passes the FIPS 186-5
section 5.6.2.3 full validation procedure, and the full pipeline
accepts the signature. -/
theorem kat_kat_1_empty_verify_full :
    ecdsaVerifyFull (Point.affine 0xbbcc2bf06cd5102ff518fa9ebe734d1646a4f0ce47efb945499b2be42d486291 0xcbf00bb9a65930170bd98127208c6f193a56563ece78bdc37284c9091f065c72) msg_kat_1_empty
      0x926a96b79dbcbf6a45dfa34e19e4f937fcf8dd97e87f330fda1ad48374f1a9f0 0x97f2a9c669f413630b4fcf2778811c582ed5a469004067f946ece31ee1df52a3 = true := by native_decide

/-- Vector `kat_1_msg` — private key (ground truth). -/

end ProofBundle.Crypto.ECDSAP256
