import Std
import ECDSAP256

namespace ProofBundle.Crypto.ECDSAP256

def priv_kat_0_empty : Nat := 0x7a083a580e618c8d21c8b9a24fa5a52bfae8f2490a75152a63d36eb7250a5f52

/-- Vector `kat_0_empty` — message (ground truth, hex in the JSON). -/
def msg_kat_0_empty : ByteArray := ByteArray.mk #[]

/-- Vector `kat_0_empty` — RFC 6979 section 3.2 deterministic nonce recovery:
`rfc6979K priv msg` reproduces the ground-truth `k`. -/
theorem kat_kat_0_empty_nonce :
    rfc6979K priv_kat_0_empty msg_kat_0_empty = 0xe959d49f8d73e7fb283f6611a43408791837e47bf25af629633dd8bc35398980 := by native_decide

/-- Vector `kat_0_empty` — FIPS 186-5 section 6.4.1 signature generation:
`ecdsaSign priv msg = (r, s)` with `r = 0xd3cb108e02fc4842b51d8afa14b1c3c73e6528f1c6102ae5c6238a5a2efa2c58`
and `s = 0x4c641a9fa2cecf284d99385b41b48bc356568dc0c16b902ce193ff111bca657f`. -/
theorem kat_kat_0_empty_sign :
    ecdsaSign priv_kat_0_empty msg_kat_0_empty = (0xd3cb108e02fc4842b51d8afa14b1c3c73e6528f1c6102ae5c6238a5a2efa2c58, 0x4c641a9fa2cecf284d99385b41b48bc356568dc0c16b902ce193ff111bca657f) := by native_decide

/-- Vector `kat_0_empty` — FIPS 186-5 section 6.4.4 verification accepts the
fresh signature under the ground-truth public key. -/
theorem kat_kat_0_empty_verify :
    ecdsaVerify (Point.affine 0xf839cbb33743702a05c3c4b394c0f2ad813a2e51801bf68ac9bc884fb987541c 0x5a2360547558b03a662421c13e13b97e9d202c26b96681b6206215786e839163) msg_kat_0_empty
      0xd3cb108e02fc4842b51d8afa14b1c3c73e6528f1c6102ae5c6238a5a2efa2c58 0x4c641a9fa2cecf284d99385b41b48bc356568dc0c16b902ce193ff111bca657f = true := by native_decide

/-- Vector `kat_0_empty` — public-key derivation: `priv·G` is the ground-truth
public key 0xf839cbb33743702a05c3c4b394c0f2ad813a2e51801bf68ac9bc884fb987541c / 0x5a2360547558b03a662421c13e13b97e9d202c26b96681b6206215786e839163. -/
theorem kat_kat_0_empty_pubkey :
    pointMul basePoint priv_kat_0_empty =
      Point.affine 0xf839cbb33743702a05c3c4b394c0f2ad813a2e51801bf68ac9bc884fb987541c 0x5a2360547558b03a662421c13e13b97e9d202c26b96681b6206215786e839163 := by native_decide

/-- Vector `kat_0_empty` — the ground-truth public key passes the FIPS 186-5
section 5.6.2.3 full validation procedure, and the full pipeline
accepts the signature. -/
theorem kat_kat_0_empty_verify_full :
    ecdsaVerifyFull (Point.affine 0xf839cbb33743702a05c3c4b394c0f2ad813a2e51801bf68ac9bc884fb987541c 0x5a2360547558b03a662421c13e13b97e9d202c26b96681b6206215786e839163) msg_kat_0_empty
      0xd3cb108e02fc4842b51d8afa14b1c3c73e6528f1c6102ae5c6238a5a2efa2c58 0x4c641a9fa2cecf284d99385b41b48bc356568dc0c16b902ce193ff111bca657f = true := by native_decide

/-- Vector `kat_0_msg` — private key (ground truth). -/

end ProofBundle.Crypto.ECDSAP256
