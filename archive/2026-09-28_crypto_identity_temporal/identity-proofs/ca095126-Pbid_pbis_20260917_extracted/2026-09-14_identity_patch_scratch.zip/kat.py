import asyncio, json
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(); pg = await b.new_page()
        await pg.goto("http://127.0.0.1:8765/orig.html")
        await pg.wait_for_function("Array.isArray(window.PB_SELFTEST)", timeout=120000)
        r = await pg.evaluate("""async () => {
          const h2b = h => { const u = new Uint8Array(h.length/2); for (let i=0;i<u.length;i++) u[i]=parseInt(h.substr(2*i,2),16); return u; };
          const sig = h2b('e5564300c360ac729086e2cc806e828a84877f1eb8e5d974d873e065224901555fb8821590a33bacc61e39701cf9b46bd25bf5f0595bbe24655141438e7a100b');
          const pub = h2b('d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a');
          const msg = new Uint8Array(0);
          let a, c;
          try { a = await _ed.verify(msg, sig, pub); } catch (e) { a = 'throw: ' + e.message; }
          try { c = await _ed.verify(sig, msg, pub); } catch (e) { c = 'throw: ' + e.message; }
          return { order_msg_sig_pub_as_in_selftest: a, order_sig_msg_pub_as_in_wrapper: c,
                   poisoned: _edFallback.poisoned === true, verifySrc: String(PBED25519.verify).slice(0, 160) };
        }""")
        print(json.dumps(r, indent=1)); await b.close()
asyncio.run(main())
