#!/usr/bin/env python3
"""Apply the 2026-09-14 model-identity patch to proofbundle_txt.html.
Every edit is an exact-string replacement whose anchor must occur exactly once;
any drift in the input file aborts instead of guessing."""
import sys, pathlib

src_path, dst_path = sys.argv[1], sys.argv[2]
here = pathlib.Path(__file__).parent
raw = pathlib.Path(src_path).read_bytes()
assert raw.startswith(b'\xef\xbb\xbf'), 'expected UTF-8 BOM'
text = raw.decode('utf-8')
edits = []

def rep(label, old, new):
    global text
    n = text.count(old)
    if n != 1:
        sys.exit(f'ABORT [{label}]: anchor found {n} times, expected 1')
    text = text.replace(old, new, 1)
    edits.append(label)

# E1 — seal panel: optional identity selector
rep('E1 seal panel identity selector',
'''    <input type="text" id="seal-parent" placeholder="pb-… of an already-sealed bundle" autocomplete="off">
  </div>
''',
'''    <input type="text" id="seal-parent" placeholder="pb-… of an already-sealed bundle" autocomplete="off">
  </div>

  <!-- identity patch 2026-09-14 -->
  <div class="form-row">
    <label class="label" for="seal-identity">Seal as model identity (optional: uses that identity's key and writes meta.signer; manage identities under History)</label>
    <select id="seal-identity"><option value="">None: use the key below</option></select>
  </div>
''')

# E2 — ledger panel: identity card before the sealed-archive section
rep('E2 ledger panel identity card',
'''  <hr>
  <div class="form-row">
    <label class="label">Sealed archive — the whole state as one bundle</label>''',
'''  <!-- identity patch 2026-09-14 -->
  <div class="card" style="margin-bottom:20px" id="id-panel">
    <div class="card-title">Model identities</div>
    <div class="card-desc">One signing key per model name. A bundle sealed under an identity carries the name and the key's SHA-256 inside the signed bytes.
      That shows which key signed. It does not show who holds the key: you do. A name is checked only against a registry you seal and a verifier pins.
      Private keys stay in this tab until you export the keyring.</div>
    <div class="form-grid" style="grid-template-columns:2fr 1fr auto">
      <div><label class="label" for="id-new-name">Model name</label>
        <input type="text" id="id-new-name" placeholder="anthropic/claude-opus-5" autocomplete="off" spellcheck="false"></div>
      <div><label class="label" for="id-new-alg">Key type</label><select id="id-new-alg"></select></div>
      <div><button class="btn btn-secondary" id="id-create-btn" onclick="idCreateUI()">Create identity</button></div>
    </div>
    <div id="id-list" style="margin:10px 0"></div>
    <div class="btn-row">
      <button class="btn btn-secondary btn-sm" onclick="idExportKeyringUI()">↓ Export keyring</button>
      <button class="btn btn-secondary btn-sm" onclick="document.getElementById('id-keyring-file').click()">Import keyring</button>
      <input type="file" id="id-keyring-file" accept=".json,application/json" style="display:none" onchange="idImportKeyringUI(this)">
    </div>
    <label class="label" for="id-operator">Seal a registry of the names above with an operator identity</label>
    <div class="form-grid" style="grid-template-columns:1fr auto">
      <select id="id-operator"></select>
      <button class="btn btn-secondary btn-sm" onclick="idBuildRegistryUI()">↓ Seal registry</button>
    </div>
    <label class="label" for="id-registry-file" style="margin-top:12px">Check signer names with a registry: file, plus the full 64-character key SHA-256 of whoever sealed it</label>
    <input type="file" id="id-registry-file" accept=".json,application/json">
    <input type="text" id="id-registry-pin" placeholder="64-character SHA-256 of the registry signer's public key" autocomplete="off" spellcheck="false" style="margin-top:6px">
    <div class="btn-row" style="margin-top:6px">
      <button class="btn btn-secondary btn-sm" onclick="idLoadRegistryUI()">Load and pin registry</button>
      <button class="btn btn-secondary btn-sm" onclick="idClearRegistryUI()">Stop using registry</button>
    </div>
    <div id="id-registry-status" class="algo-note"></div>
  </div>

  <hr>
  <div class="form-row">
    <label class="label">Sealed archive — the whole state as one bundle</label>''')

# E3 — identity module after the key-custody section
module = (here / 'module.js').read_text(encoding='utf-8')
rep('E3 identity module',
'''\n/* ── verification certificate ───────────────────────────────────── */\n''',
module + '''\n/* ── verification certificate ───────────────────────────────────── */\n''')

# E4 — verifyCore step 4b: declared signer key must be the key that verified
rep('E4 verifyCore 4b signer key check',
'''  } catch (e) {
    return fail('INVALID-SIGNATURE', 'Signature verification', 'error: ' + e.message);
  }

  const leaves = [canonicalJSON(bundle.hdr), canonicalJSON(bundle.meta), canonicalJSON(bundle.payload || {})];''',
'''  } catch (e) {
    return fail('INVALID-SIGNATURE', 'Signature verification', 'error: ' + e.message);
  }

  /* 4b — signer identity (identity patch 2026-09-14). The declared signer key must be
     the key that verified the signature: pubOverride when given, else the envelope key.
     Name resolution against a registry is step 7b. */
  let idPending = null;
  if (bundle.meta.signer !== undefined) {
    const effPub = legacy ? (o.pubOverride || bundle.sig.pub) : (o.pubOverride || bundle.seal.pub_b64u);
    const ic = await idCheckSigner(bundle.meta.signer, effPub, sigAlg);
    if (ic.fail) return fail(ic.fail, 'Signer identity', ic.body);
    step('Signer identity', ic.body);
  }

  const leaves = [canonicalJSON(bundle.hdr), canonicalJSON(bundle.meta), canonicalJSON(bundle.payload || {})];''')

# E5 — verifyCore step 7b: resolve the name against a pinned registry
rep('E5 verifyCore 7b name resolution',
'''    step('Policy check', 'required side attestations present ✓');
  }

  /* 8 — boundary */''',
'''    step('Policy check', 'required side attestations present ✓');
  }

  /* 7b — signer name (identity patch 2026-09-14). A failed lookup ends here; an
     unchecked name is held until after the boundary so it cannot mask OUT-OF-BOUNDS. */
  if (bundle.meta.signer !== undefined) {
    const nr = idResolve(bundle.meta.signer, o.registry);
    if (nr.fail) return fail(nr.fail, 'Signer name', nr.body);
    if (nr.pending) idPending = nr.body; else step('Signer name', nr.body);
  }

  /* 8 — boundary */''')

# E6 — verifyCore end: unchecked name downgrades VERIFIED to MISSING-SIDE-INFO
rep('E6 verifyCore unchecked name',
'''  step('Boundary evaluation', bodyParts || 'no predicates', outcome === 'VERIFIED' ? null : outcome);
  return { outcome, trace };
}''',
'''  step('Boundary evaluation', bodyParts || 'no predicates', outcome === 'VERIFIED' ? null : outcome);
  if (outcome === 'VERIFIED' && idPending) return fail('MISSING-SIDE-INFO', 'Signer name', idPending);
  return { outcome, trace };
}''')

# E7 — sealBundle: identity key selection
rep('E7 sealBundle identity key',
'''  const digestAlg = document.getElementById('seal-digestalg').value;
  const sigAlg = document.getElementById('seal-sigalg').value;
  const privInput = document.getElementById('seal-privkey').value.trim();
  let key;
  if (_currentKey && _currentKey.alg === sigAlg && (!privInput || privInput === _currentKey.priv)) {''',
'''  const digestAlg = document.getElementById('seal-digestalg').value;
  let sigAlg = document.getElementById('seal-sigalg').value;
  const privInput = document.getElementById('seal-privkey').value.trim();
  /* identity patch 2026-09-14: optional "Seal as model identity" */
  const idSel = document.getElementById('seal-identity');
  const idName = idSel ? idSel.value : '';
  if (!idName && bundle && bundle.meta && bundle.meta.signer !== undefined) {
    notifyError('meta.signer is written by identity sealing. Pick the identity under "Seal as model identity", or delete meta.signer from the JSON.');
    return;
  }
  let key;
  if (idName) {
    try { key = await idKey(idCheckName(idName)); }
    catch (e) { notifyError('Identity seal failed: ' + e.message); return; }
    if (key.alg !== sigAlg) {
      sigAlg = key.alg;
      document.getElementById('seal-sigalg').value = sigAlg;
      flashToast(`Signature algorithm set to ${sigAlg} to match the identity's key.`);
    }
  } else if (_currentKey && _currentKey.alg === sigAlg && (!privInput || privInput === _currentKey.priv)) {''')

# E8 — sealBundle: stamp meta.signer before sealing
rep('E8 sealBundle stamp signer',
'''  if (parentId) bundle.meta.refs = [{ parent_id: parentId }];
  try {
    await sealCore(bundle, digestAlg, sigAlg, key);''',
'''  if (parentId) bundle.meta.refs = [{ parent_id: parentId }];
  if (idName) bundle.meta.signer = idSignerBlock(idGet(idName));
  try {
    await sealCore(bundle, digestAlg, sigAlg, key);''')

# E9 — Verify tab uses the pinned registry
rep('E9 verifyBundle registry option',
'''  const { outcome, trace } = await verifyCore(bundle, { context, bundles: bundlesAll,
    maxDepth: depth, pubOverride, now: nowOpt });''',
'''  const { outcome, trace } = await verifyCore(bundle, { context, bundles: bundlesAll,
    maxDepth: depth, pubOverride, now: nowOpt, registry: idActiveRegistry || undefined });''')

# E10 — store checks use the pinned registry
rep('E10 storeVerify registry option',
'''  const { outcome } = await verifyCore(e.bundle, { bundles: storeMap(), maxDepth: 8 });''',
'''  const { outcome } = await verifyCore(e.bundle, { bundles: storeMap(), maxDepth: 8, registry: idActiveRegistry || undefined });''')

# E11 — boot: restore identities, wire panel
rep('E11 init restore',
'''  restoreState();
  renderDomains();''',
'''  restoreState();
  idRestore();
  renderDomains();''')
rep('E12 init panel',
'''  renderLedgerPanel();
  initSyncUI();''',
'''  renderLedgerPanel();
  idInitUI();
  initSyncUI();''')

# E13 — boot self-tests for identity binding
rep('E13 self-tests',
'''  /* baseline digest sanity check (post-registry, pre-render) */''',
'''    /* model identity (identity patch 2026-09-14): name bound to key inside the signed bytes */
    const idOpK = await sigKeygen('Ed25519'), idMK = await sigKeygen('Ed25519'), idXK = await sigKeygen('Ed25519');
    const idOp = await idMakeRecord('operator/self-test', idOpK);
    const idM = await idMakeRecord('vendor/model-a', idMK);
    const idX = await idMakeRecord('vendor/model-a', idXK);
    const idReg = await idLoadRegistry(await idSealRegistry(idOp, idOpK, [idM]), [idOp.key_sha256]);
    const idOut = async (b, r) => (await verifyCore(b, r ? { registry: r } : {})).outcome;
    const idB = await idSealAttest(idM, idMK, { claim: 'self-test' });
    T('identity: listed name + its key → VERIFIED', eq(await idOut(idB, idReg), 'VERIFIED'));
    T('identity: no registry → MISSING-SIDE-INFO (name unchecked)', eq(await idOut(idB), 'MISSING-SIDE-INFO'));
    T('identity: JSON round-trip → VERIFIED', eq(await idOut(JSON.parse(JSON.stringify(idB)), idReg), 'VERIFIED'));
    T('identity: declared key ≠ signing key → INVALID-SIGNATURE', eq(await idOut(await idSealAttest(idM, idXK, { claim: 'borrowed' }), idReg), 'INVALID-SIGNATURE'));
    T('identity: same name, unlisted key → INVALID-SIGNATURE', eq(await idOut(await idSealAttest(idX, idXK, { claim: 'impersonation' }), idReg), 'INVALID-SIGNATURE'));
    T('identity: name not in registry → POLICY-DENIED', eq(await idOut(await idSealAttest(await idMakeRecord('vendor/unlisted', idXK), idXK, {}), idReg), 'POLICY-DENIED'));
    const idEd = JSON.parse(JSON.stringify(idB)); idEd.meta.signer.model = 'vendor/model-b';
    T('identity: name edited after sealing → INVALID-SIGNATURE', eq(await idOut(idEd, idReg), 'INVALID-SIGNATURE'));
    let idPinErr = '';
    try { await idLoadRegistry(await idSealRegistry(idOp, idOpK, [idM]), [idM.key_sha256]); } catch (e) { idPinErr = e.message; }
    T('identity: registry sealed by an unpinned key is refused', idPinErr.includes('not pinned'));
    T('identity: hand-built registry object ignored → MISSING-SIDE-INFO',
      eq(await idOut(idB, { bundle_id: 'x', signer_key_sha256: idOp.key_sha256, count: 1, entries: new Map([['vendor/model-a', [{ sig_alg: 'Ed25519', key_sha256: idM.key_sha256 }]]]) }), 'MISSING-SIDE-INFO'));

  /* baseline digest sanity check (post-registry, pre-render) */''')

out = text.encode('utf-8')
if not out.startswith(b'\xef\xbb\xbf'):
    out = b'\xef\xbb\xbf' + out
pathlib.Path(dst_path).write_bytes(out)
print(f'applied {len(edits)} edits:')
for e in edits: print('  ' + e)
