import Std
import ECDSAP256

namespace ProofBundle.Crypto.ECDSAP256

def priv_kat_2_msg : Nat := 0x6884f77d3e9098b773d660dd4a4f297b29805739db772a334f209db13c035de6

/-- Vector `kat_2_msg` — message (ground truth, hex in the JSON). -/
def msg_kat_2_msg : ByteArray := ByteArray.mk #[0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f, 0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3a, 0x3b, 0x3c, 0x3d, 0x3e, 0x3f]

/-- Vector `kat_2_msg` — RFC 6979 section 3.2 deterministic nonce recovery:
`rfc6979K priv msg` reproduces the ground-truth `k`. -/
theorem kat_kat_2_msg_nonce :
    rfc6979K priv_kat_2_msg msg_kat_2_msg = 0xe5991b4761aec252bf58d23a798052b9e45f7a33ec51ac5804ae5a33e0bfbff8 := by native_decide

/-- Vector `kat_2_msg` — FIPS 186-5 section 6.4.1 signature generation:
`ecdsaSign priv msg = (r, s)` with `r = 0x3ca606521d9fbbc7b06092d3847a3100bff508e9972d08563bf9a10c615c9cad`
and `s = 0xed60a7491ecf40115aca684279a264e228bfce015cca0a4031c326be3001a70f`. -/
theorem kat_kat_2_msg_sign :
    ecdsaSign priv_kat_2_msg msg_kat_2_msg = (0x3ca606521d9fbbc7b06092d3847a3100bff508e9972d08563bf9a10c615c9cad, 0xed60a7491ecf40115aca684279a264e228bfce015cca0a4031c326be3001a70f) := by native_decide

/-- Vector `kat_2_msg` — FIPS 186-5 section 6.4.4 verification accepts the
fresh signature under the ground-truth public key. -/
theorem kat_kat_2_msg_verify :
    ecdsaVerify (Point.affine 0x8687c1b7cc9e108f61c91886d4bdedb2d0803e68db540c7ee2ce8e2991edfa89 0xf1fc0fbcefa2decac587b31e72fb14cdfa2ca808af700f80037562a64905a6b9) msg_kat_2_msg
      0x3ca606521d9fbbc7b06092d3847a3100bff508e9972d08563bf9a10c615c9cad 0xed60a7491ecf40115aca684279a264e228bfce015cca0a4031c326be3001a70f = true := by native_decide

/-- Vector `kat_2_msg` — public-key derivation: `priv·G` is the ground-truth
public key 0x8687c1b7cc9e108f61c91886d4bdedb2d0803e68db540c7ee2ce8e2991edfa89 / 0xf1fc0fbcefa2decac587b31e72fb14cdfa2ca808af700f80037562a64905a6b9. -/
theorem kat_kat_2_msg_pubkey :
    pointMul basePoint priv_kat_2_msg =
      Point.affine 0x8687c1b7cc9e108f61c91886d4bdedb2d0803e68db540c7ee2ce8e2991edfa89 0xf1fc0fbcefa2decac587b31e72fb14cdfa2ca808af700f80037562a64905a6b9 := by native_decide

/-- Vector `kat_2_msg` — the ground-truth public key passes the FIPS 186-5
section 5.6.2.3 full validation procedure, and the full pipeline
accepts the signature. -/
theorem kat_kat_2_msg_verify_full :
    ecdsaVerifyFull (Point.affine 0x8687c1b7cc9e108f61c91886d4bdedb2d0803e68db540c7ee2ce8e2991edfa89 0xf1fc0fbcefa2decac587b31e72fb14cdfa2ca808af700f80037562a64905a6b9) msg_kat_2_msg
      0x3ca606521d9fbbc7b06092d3847a3100bff508e9972d08563bf9a10c615c9cad 0xed60a7491ecf40115aca684279a264e228bfce015cca0a4031c326be3001a70f = true := by native_decide

/-- Vector `kat_3_empty` — private key (ground truth). -/

end ProofBundle.Crypto.ECDSAP256
