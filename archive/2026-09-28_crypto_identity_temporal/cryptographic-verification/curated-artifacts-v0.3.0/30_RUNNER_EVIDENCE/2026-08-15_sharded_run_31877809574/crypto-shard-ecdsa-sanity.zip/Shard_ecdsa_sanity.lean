import Std
import ECDSAP256

namespace ProofBundle.Crypto.ECDSAP256

/-!
## Part 1: SHA-256 known-answer tests (FIPS 180-4 appendix D)
-/

/-- FIPS 180-4 SHA-256 example 1: the empty string. -/
theorem sha256_kat_empty :
    sha256Hex "" =
      "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855" := by
  native_decide

/-- FIPS 180-4 SHA-256 example 2: the one-block message "abc". -/
theorem sha256_kat_abc :
    sha256Hex "abc" =
      "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad" := by
  native_decide

/-- The digest of "abc" as a `ByteArray` equality, pinning the byte-level
output (not only the hex rendering). -/
theorem sha256_kat_abc_bytes :
    sha256 "abc".toUTF8 =
      ByteArray.mk #[0xba, 0x78, 0x16, 0xbf, 0x8f, 0x01, 0xcf, 0xea,
                    0x41, 0x41, 0x40, 0xde, 0x5d, 0xae, 0x22, 0x23,
                    0xb0, 0x03, 0x61, 0xa3, 0x96, 0x17, 0x7a, 0x9c,
                    0xb4, 0x10, 0xff, 0x61, 0xf2, 0x00, 0x15, 0xad] := by
  native_decide

/-!
## Part 2: HMAC-SHA-256 known-answer test (RFC 4231 test case 1)
-/

/-- RFC 4231 HMAC-SHA-256 test case 1: key = 0x0b repeated 20 times
(shorter than the block size, exercising zero-padding), data = "Hi
There". -/
theorem hmac_sha256_rfc4231_tc1 :
    hexEncode (hmacSha256
      (ByteArray.mk #[0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b,
                     0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b,
                     0x0b, 0x0b, 0x0b, 0x0b])
      "Hi There".toUTF8) =
      "b0344c61d8db38535ca8afceaf0bf12b881dc200c9833da726e9376c2e32cff7" := by
  native_decide

/-!
## Part 3: group sanity theorems
-/

/-- The base point G lies on the P-256 curve (FIPS 186-4 D.1.2.3). -/
theorem basePoint_onCurve : onCurve Gx Gy = true := by native_decide

/-- The base point has order `n`: `n·G` is the point at infinity
(FIPS 186-4 D.1.2.3, ground truth `curve.n`). -/
theorem basePoint_order : pointMul basePoint n = Point.infinity := by
  native_decide

/-- Consequently `(n + 1)·G = G`, a cross-check of the group law. -/
theorem basePoint_order_plus_one :
    pointMul basePoint (n + 1) = basePoint := by native_decide

/-- The base point is valid per the FIPS 186-5 section 5.6.2.3 full
public-key validation procedure. -/
theorem basePoint_validates : validatePublicKey basePoint = true := by
  native_decide

/-- The point at infinity is rejected by public-key validation. -/
theorem infinity_not_valid : validatePublicKey Point.infinity = false := by
  native_decide

/-- `n` is odd, so the low-s threshold `⌊n/2⌋` is exact. -/
theorem n_odd : n % 2 = 1 := by native_decide

end ProofBundle.Crypto.ECDSAP256
